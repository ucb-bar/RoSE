"""Per-op kernel specs: signature, semantics, reference C impl, test shapes.

This is the single source of truth for:
  * the reference backend in generate_kernels (just emit `reference_impl`)
  * the LLM backend's prompt (signature + semantics + reference shown to LLM)
  * the verify harness (calls both .so's against shapes from `extra_shapes`
    plus shapes pulled from the actual model IR)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, Callable, Optional


class AccuracyClass(IntEnum):
    """How tightly an algorithm/kernel matches the bit-exact reference oracle.

    Used by the kernel-selection pass in generate_kernels.py to filter the
    algorithm queue when the user asks for a specific tolerance level via
    `--max-accuracy-class`. Lower numeric value = tighter accuracy bound.

    The bound is per-element; multi-layer drift accumulates roughly linearly
    in network depth (one rounding event per layer), so an algorithm tagged
    NUMERIC_DRIFT can still produce model-level errors that exceed atol on
    deep networks (yolov8-class, ~63 conv layers). When that happens the
    selection pass naturally falls back to the next-tighter algorithm.

    The numeric_drift `atol=128` envelope was chosen to cover Q0.31
    single-stage-fold drift on yolov8-depth networks (≤200 layers): the
    gemmini_tiled_conv path applies (output_multiplier, output_shift)
    as one folded Q0.31 multiplier (single rounding event) vs the
    reference oracle's two-stage Q0.31 (two rounding events), differing
    by ≤1 LSB per layer. For shallow nets (dronet, ~30 layers) the
    accumulated drift is ≤6 LSB; for yolov8 (~200 layers) it can reach
    ~80–100 LSB. This is a known-bounded drift mode (not a kernel bug),
    and downstream model accuracy on int8 detection / classification is
    robust to it. Bumping atol from the original 8 LSB lets the faster
    gemmini_tiled_conv variant pass verify on deep nets.
    """
    BIT_EXACT     = 0  # max_abs_err=0 vs reference at every shape
    NUMERIC_DRIFT = 1  # ≤~1 LSB / layer, accumulates with depth (atol=128)
    APPROXIMATE   = 2  # only validated against task metric (mAP/top-1)

    @classmethod
    def parse(cls, name: str) -> "AccuracyClass":
        # Accept lower / upper / mixed case identifier from CLI or kernel
        # header comments.
        norm = name.strip().lower().replace("-", "_")
        for v in cls:
            if v.name.lower() == norm:
                return v
        raise ValueError(
            f"unknown accuracy class {name!r}; expected one of "
            f"{[v.name.lower() for v in cls]}"
        )


# Per-class verify tolerance defaults, layered under any Backend.atol_override.
# Backends with a stricter intrinsic floor (e.g. atol_override=8 for the float
# gemmini bitstream) are honored; the per-class table only relaxes, never
# tightens, the per-backend default.
ACCURACY_CLASS_ATOL: dict[AccuracyClass, float] = {
    AccuracyClass.BIT_EXACT:     0.0,
    AccuracyClass.NUMERIC_DRIFT: 128.0,
    AccuracyClass.APPROXIMATE:   float("inf"),
}


@dataclass
class AlgorithmCandidate:
    """An algorithmic approach for implementing an op.

    Multiple algorithms can be valid for the same op (e.g. conv2d via direct
    sliding-window vs im2col+GEMM). Each algorithm is a separate seed shown
    to the LLM during the correctness phase — the LLM is asked to write a
    kernel matching the algorithm's structure. Verify still uses the
    KernelSpec.reference_impl as the (algorithm-agnostic) oracle, so any
    algorithm whose output is numerically equivalent passes.
    """
    name: str
    # Plain-English description of the algorithm — what shape of code to
    # produce and why. Goes into the LLM correctness prompt.
    description: str
    # A correct implementation written in this algorithmic style. Used as the
    # seed example in the LLM prompt. NOT the verify oracle (that's
    # KernelSpec.reference_impl); this can be slow / VLA-using / whatever.
    reference_impl: str
    # Optional shape filter: lambda shape_dict -> bool. If set and returns
    # False, the algorithm is skipped for that shape during verify.
    applicable: Optional[Callable[[dict], bool]] = None
    # Backends this algorithm makes sense for. Empty means all.
    target_affinity: tuple[str, ...] = ()
    # How accurate this algorithm is vs the reference oracle. Used by the
    # kernel-selection pass to filter via --max-accuracy-class. Defaults to
    # NUMERIC_DRIFT — most LLM-seeded or hand-curated kernels accumulate
    # ≤1 LSB / layer; algorithms that re-run the reference math in the same
    # rounding mode (e.g. scalar `direct`, gemmini_im2col_full_C) should
    # explicitly set BIT_EXACT.
    accuracy_class: AccuracyClass = AccuracyClass.NUMERIC_DRIFT
    # Weight layout this algorithm's C code assumes for 4D conv tensors.
    # "oihw" = PyTorch default (OC, IC, KH, KW).
    # "ihwoc" = OC-contiguous (IC, KH, KW, OC) for vectorizing over OC.
    # "hwio" = patch-major (KH, KW, IC, OC) for gemmini tiled_conv_auto.
    # The pipeline asserts all selected algorithms for a given op agree on
    # layout, and _backend_pack_weight applies the matching permutation.
    weight_layout: str = "oihw"


@dataclass
class KernelSpec:
    op: str
    # Function signature, exactly as it should appear in kernels.h.
    signature: str
    # Plain-English semantics for the LLM prompt.
    semantics: str
    # Trusted reference impl. Used as `--backend reference` output AND as the
    # ground-truth oracle that the LLM-generated kernel is compared against
    # for correctness — algorithm-agnostic; should be the simplest, most
    # obviously-correct version.
    reference_impl: str
    # Extra shape combinations to verify against, beyond what's in the IR.
    # Each entry is the kwargs that the verify harness will use to allocate
    # buffers and call the kernel.
    extra_shapes: list[dict[str, int]] = field(default_factory=list)
    # ctypes argtypes for verify (in order).
    argtypes_factory: Callable[[], list[Any]] = None  # type: ignore
    # Optional list of algorithmic styles the LLM can be seeded with. If
    # empty (the default), a single "direct" algorithm wrapping
    # `reference_impl` is synthesized, preserving the previous single-seed
    # behavior.
    algorithms: list[AlgorithmCandidate] = field(default_factory=list)

    def __post_init__(self):
        # Synthesize a "direct" algorithm seeded from `reference_impl`
        # whenever the spec has no algorithm that covers ALL backends
        # (i.e. no entry with empty `target_affinity`). Without this,
        # generate_kernels' target_affinity filter empties the queue
        # for non-gemmini targets on specs like ADD_S8 / RELU_S8 /
        # MAXPOOL2D_S8 / LINEAR_S8 (which only register gemmini-
        # affinity algorithms today). The synthesized direct entry is
        # by-definition bit-exact since it IS the reference impl.
        has_universal = any(
            not a.target_affinity for a in self.algorithms
        )
        if not has_universal:
            self.algorithms.append(
                AlgorithmCandidate(
                    name="direct",
                    description=(
                        "Direct, naive implementation. Loop over every output "
                        "element and compute it explicitly. Falls back here "
                        "when no target-specific algorithm is registered for "
                        "the active backend."
                    ),
                    reference_impl=self.reference_impl,
                    accuracy_class=AccuracyClass.BIT_EXACT,
                )
            )


def _linear_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    return [fp, fp, fp, fp, ctypes.c_int, ctypes.c_int, ctypes.c_int]


def _matmul_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    # A, B, C, M, K, N
    return [fp, fp, fp, ctypes.c_int, ctypes.c_int, ctypes.c_int]


def _bmm_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    # A, B, C, batch, M, K, N
    return [fp, fp, fp, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int]


def _matmul_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    # A, B, C, M, K, N
    return [h, h, h, ctypes.c_int, ctypes.c_int, ctypes.c_int]


def _bmm_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    # A, B, C, batch, M, K, N
    return [h, h, h, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int]


def _relu_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    return [fp, fp, ctypes.c_int]


def _elu_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    # input, output, n, alpha
    return [fp, fp, ctypes.c_int, ctypes.c_float]


def _conv2d_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    # input, weight, bias, output, N, IC, IH, IW, OC, KH, KW, SH, SW, PH, PW
    return [fp, fp, fp, fp] + [ctypes.c_int] * 11


def _maxpool2d_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    # input, output, N, C, IH, IW, KH, KW, SH, SW, PH, PW, DH, DW
    return [fp, fp] + [ctypes.c_int] * 12


def _add_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    return [fp, fp, fp, ctypes.c_int]


def _batchnorm2d_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    # input, scale, bias, output, N, C, H, W
    return [fp, fp, fp, fp] + [ctypes.c_int] * 4


def _sigmoid_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    return [fp, fp, ctypes.c_int]


def _conv2d_dw_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    # input, weight, bias, output, N, C, IH, IW, KH, KW, SH, SW, PH, PW
    # OC == IC == groups (depthwise) — folded into a single C param.
    return [fp, fp, fp, fp] + [ctypes.c_int] * 10


def _relu6_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    return [fp, fp, ctypes.c_int]


def _adaptive_avg_pool2d_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    # input, output, N, C, IH, IW (output is always [N, C, 1, 1] for now)
    return [fp, fp] + [ctypes.c_int] * 4


# KernelBench Phase 2 activations — all pointwise, signatures shaped
# like the existing relu / sigmoid / elu kernels. The parametric ones
# (leaky_relu, hardtanh) take their constants as float scalar args; the
# rest match (input, output, n).

def _pointwise_argtypes():
    """Standard signature for parameter-free pointwise activations:
    void kernel(const float *in, float *out, int n)."""
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    return [fp, fp, ctypes.c_int]


def _leaky_relu_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    # input, output, n, negative_slope
    return [fp, fp, ctypes.c_int, ctypes.c_float]


def _hardtanh_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    # input, output, n, min_val, max_val
    return [fp, fp, ctypes.c_int, ctypes.c_float, ctypes.c_float]


def _linear_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    i32p = ctypes.POINTER(ctypes.c_int32)
    # input(i8*), weight(i8*), bias(i32*), output(i8*),
    # M, K, N,
    # input_offset, filter_offset, output_offset,
    # output_multiplier, output_shift,
    # activation_min, activation_max
    return [i8p, i8p, i32p, i8p] + [ctypes.c_int] * 10


def _relu_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    return [i8p, i8p, ctypes.c_int]


def _conv2d_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    i32p = ctypes.POINTER(ctypes.c_int32)
    # input(i8*), weight(i8*), bias(i32*), output(i8*),
    # N, IC, IH, IW, OC, KH, KW, SH, SW, PH, PW,
    # input_offset, filter_offset, output_offset,
    # output_multiplier, output_shift,
    # activation_min, activation_max
    return [i8p, i8p, i32p, i8p] + [ctypes.c_int] * 18


def _conv2d_silu_s8_argtypes():
    """Same as conv2d_s8 plus silu_scale_in / silu_scale_out (float) at
    the end. The fused kernel applies a SiLU LUT to its int8 output
    before the final activation clamp."""
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    i32p = ctypes.POINTER(ctypes.c_int32)
    return [i8p, i8p, i32p, i8p] + [ctypes.c_int] * 18 + [ctypes.c_float, ctypes.c_float]


def _maxpool2d_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    # input, output, N, C, IH, IW, KH, KW, SH, SW, PH, PW, DH, DW
    return [i8p, i8p] + [ctypes.c_int] * 12


def _add_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    # a, b, output, n, scale_a, scale_b, scale_out, activation_min, activation_max
    return [i8p, i8p, i8p, ctypes.c_int,
            ctypes.c_float, ctypes.c_float, ctypes.c_float,
            ctypes.c_int, ctypes.c_int]


def _batchnorm2d_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    fp = ctypes.POINTER(ctypes.c_float)
    # input, scale, bias, output, N, C, H, W, scale_in, scale_out,
    # activation_min, activation_max
    return [i8p, fp, fp, i8p,
            ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_float, ctypes.c_float,
            ctypes.c_int, ctypes.c_int]


def _sigmoid_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    # input, output, n, scale_in, scale_out, activation_min, activation_max
    return [i8p, i8p, ctypes.c_int,
            ctypes.c_float, ctypes.c_float,
            ctypes.c_int, ctypes.c_int]


def _lstm_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    f32p = ctypes.POINTER(ctypes.c_float)
    # x, w_ih, w_hh, bias, h, c, out, in_size, H,
    # s_x, s_wih, s_whh, s_h, s_c
    return [i8p, i8p, i8p, f32p, i8p, i8p, i8p,
            ctypes.c_int, ctypes.c_int,
            ctypes.c_float, ctypes.c_float, ctypes.c_float,
            ctypes.c_float, ctypes.c_float]


def _lstm_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    # x, w_ih, w_hh, bias, h, c, out, in_size, H
    return [fp, fp, fp, fp, fp, fp, fp, ctypes.c_int, ctypes.c_int]


# ---------------------------------------------------------------------------
# fp16 (half-precision) argtypes. ctypes has no native _Float16, so the host
# verify path uses c_uint16 as a 16-bit opaque blob — bit-identical layout
# to _Float16, just with the math done in numpy. Only relevant for
# BACKEND=llm verify; BACKEND=reference dumps the C reference impl directly
# and never touches ctypes.
# ---------------------------------------------------------------------------

def _relu_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, ctypes.c_int]


def _elu_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    # input, output, n, alpha (passed as fp32 — gets converted in the kernel)
    return [h, h, ctypes.c_int, ctypes.c_float]


def _sigmoid_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, ctypes.c_int]


def _conv2d_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, h, h] + [ctypes.c_int] * 11


def _maxpool2d_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h] + [ctypes.c_int] * 12


def _batchnorm2d_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    # input, scale, bias, output, N, C, H, W
    return [h, h, h, h] + [ctypes.c_int] * 4


# Phase 2 fp16 argtypes — same C-side ABI shapes as the fp32 specs,
# with c_uint16 standing in for _Float16 since Python ctypes has no
# native half. The host-verify (LLM optimize loop) is by-bits compares
# anyway; only the reference_impl C body sees the actual _Float16.

def _pointwise_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, ctypes.c_int]


def _leaky_relu_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, ctypes.c_int, ctypes.c_float]


def _hardtanh_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, ctypes.c_int, ctypes.c_float, ctypes.c_float]


def _reduce_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, ctypes.c_int, ctypes.c_int, ctypes.c_int]


def _argreduce_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    i64p = ctypes.POINTER(ctypes.c_int64)
    return [h, i64p, ctypes.c_int, ctypes.c_int, ctypes.c_int]


def _frobenius_norm_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, ctypes.c_int]


LINEAR = KernelSpec(
    op="linear",
    signature=(
        "void kernel_linear(const float *input, const float *weight, "
        "const float *bias, float *output, int M, int K, int N)"
    ),
    semantics=(
        "Computes a fully-connected (matmul + bias) layer matching PyTorch "
        "nn.Linear semantics:\n"
        "  output[m, n] = bias[n] + sum_{k=0..K-1} input[m, k] * weight[n, k]\n"
        "Shapes (row-major contiguous):\n"
        "  input:  [M, K]\n"
        "  weight: [N, K]   (note: out_features outer, in_features inner — "
        "PyTorch's storage order)\n"
        "  bias:   [N]      (may be NULL — treat as zeros)\n"
        "  output: [M, N]\n"
        "All tensors are float32."
    ),
    reference_impl="""\
void kernel_linear(const float *input, const float *weight, const float *bias,
                   float *output, int M, int K, int N) {
    for (int m = 0; m < M; m++) {
        for (int n = 0; n < N; n++) {
            float acc = bias ? bias[n] : 0.0f;
            for (int k = 0; k < K; k++) {
                acc += input[m * K + k] * weight[n * K + k];
            }
            output[m * N + n] = acc;
        }
    }
}
""",
    extra_shapes=[
        {"M": 1, "K": 1, "N": 1},
        {"M": 1, "K": 7, "N": 13},      # primes, no padding alignment
        {"M": 4, "K": 17, "N": 23},     # batch > 1
        {"M": 1, "K": 64, "N": 64},     # power-of-two
    ],
    argtypes_factory=_linear_argtypes,
)


_MATMUL_EXTRA_SHAPES = [
    {"M": 1,  "K": 1,  "N": 1},
    {"M": 1,  "K": 7,  "N": 13},
    {"M": 4,  "K": 17, "N": 23},
    {"M": 1,  "K": 64, "N": 64},
    {"M": 32, "K": 32, "N": 32},
]

MATMUL = KernelSpec(
    op="matmul",
    signature=(
        "void kernel_matmul(const float *A, const float *B, float *C, "
        "int M, int K, int N)"
    ),
    semantics=(
        "Dense matrix multiply C = A @ B (row-major contiguous):\n"
        "  A: [M, K],  B: [K, N],  C: [M, N]\n"
        "  C[m, n] = sum_{k=0..K-1} A[m*K+k] * B[k*N+n]\n"
        "All tensors float32."
    ),
    reference_impl="""\
void kernel_matmul(const float *A, const float *B, float *C,
                   int M, int K, int N) {
    for (int m = 0; m < M; m++) {
        for (int n = 0; n < N; n++) {
            float acc = 0.0f;
            for (int k = 0; k < K; k++)
                acc += A[m * K + k] * B[k * N + n];
            C[m * N + n] = acc;
        }
    }
}
""",
    extra_shapes=_MATMUL_EXTRA_SHAPES,
    argtypes_factory=_matmul_argtypes,
)

MATMUL_TA = KernelSpec(
    op="matmul_ta",
    signature=(
        "void kernel_matmul_ta(const float *A, const float *B, float *C, "
        "int M, int K, int N)"
    ),
    semantics=(
        "Dense matrix multiply C = A.T @ B (A stored in (K,M) order):\n"
        "  A stored: [K, M] — A[k, m] = A[k*M+m]\n"
        "  B: [K, N],  C: [M, N]\n"
        "  C[m, n] = sum_{k=0..K-1} A[k*M+m] * B[k*N+n]\n"
        "All tensors float32."
    ),
    reference_impl="""\
void kernel_matmul_ta(const float *A, const float *B, float *C,
                      int M, int K, int N) {
    for (int m = 0; m < M; m++) {
        for (int n = 0; n < N; n++) {
            float acc = 0.0f;
            for (int k = 0; k < K; k++)
                acc += A[k * M + m] * B[k * N + n];
            C[m * N + n] = acc;
        }
    }
}
""",
    extra_shapes=_MATMUL_EXTRA_SHAPES,
    argtypes_factory=_matmul_argtypes,
)

MATMUL_TB = KernelSpec(
    op="matmul_tb",
    signature=(
        "void kernel_matmul_tb(const float *A, const float *B, float *C, "
        "int M, int K, int N)"
    ),
    semantics=(
        "Dense matrix multiply C = A @ B.T (B stored in (N,K) order):\n"
        "  A: [M, K],  B stored: [N, K] — B[n, k] = B[n*K+k]\n"
        "  C: [M, N]\n"
        "  C[m, n] = sum_{k=0..K-1} A[m*K+k] * B[n*K+k]\n"
        "All tensors float32."
    ),
    reference_impl="""\
void kernel_matmul_tb(const float *A, const float *B, float *C,
                      int M, int K, int N) {
    for (int m = 0; m < M; m++) {
        for (int n = 0; n < N; n++) {
            float acc = 0.0f;
            for (int k = 0; k < K; k++)
                acc += A[m * K + k] * B[n * K + k];
            C[m * N + n] = acc;
        }
    }
}
""",
    extra_shapes=_MATMUL_EXTRA_SHAPES,
    argtypes_factory=_matmul_argtypes,
)

MATMUL_TATB = KernelSpec(
    op="matmul_tatb",
    signature=(
        "void kernel_matmul_tatb(const float *A, const float *B, float *C, "
        "int M, int K, int N)"
    ),
    semantics=(
        "Dense matrix multiply C = A.T @ B.T (both stored transposed):\n"
        "  A stored: [K, M] — A[k, m] = A[k*M+m]\n"
        "  B stored: [N, K] — B[n, k] = B[n*K+k]\n"
        "  C: [M, N]\n"
        "  C[m, n] = sum_{k=0..K-1} A[k*M+m] * B[n*K+k]\n"
        "All tensors float32."
    ),
    reference_impl="""\
void kernel_matmul_tatb(const float *A, const float *B, float *C,
                        int M, int K, int N) {
    for (int m = 0; m < M; m++) {
        for (int n = 0; n < N; n++) {
            float acc = 0.0f;
            for (int k = 0; k < K; k++)
                acc += A[k * M + m] * B[n * K + k];
            C[m * N + n] = acc;
        }
    }
}
""",
    extra_shapes=_MATMUL_EXTRA_SHAPES,
    argtypes_factory=_matmul_argtypes,
)

BMM = KernelSpec(
    op="bmm",
    signature=(
        "void kernel_bmm(const float *A, const float *B, float *C, "
        "int batch, int M, int K, int N)"
    ),
    semantics=(
        "Batched matrix multiply C[b] = A[b] @ B[b] (row-major contiguous):\n"
        "  A: [batch, M, K],  B: [batch, K, N],  C: [batch, M, N]\n"
        "  C[b,m,n] = sum_{k=0..K-1} A[b*M*K + m*K+k] * B[b*K*N + k*N+n]\n"
        "All tensors float32."
    ),
    reference_impl="""\
void kernel_bmm(const float *A, const float *B, float *C,
                int batch, int M, int K, int N) {
    for (int b = 0; b < batch; b++) {
        const float *Ab = A + b * M * K;
        const float *Bb = B + b * K * N;
        float *Cb = C + b * M * N;
        for (int m = 0; m < M; m++) {
            for (int n = 0; n < N; n++) {
                float acc = 0.0f;
                for (int k = 0; k < K; k++)
                    acc += Ab[m * K + k] * Bb[k * N + n];
                Cb[m * N + n] = acc;
            }
        }
    }
}
""",
    extra_shapes=[
        {"batch": 1, "M": 1,  "K": 1,  "N": 1},
        {"batch": 2, "M": 4,  "K": 8,  "N": 4},
        {"batch": 4, "M": 8,  "K": 16, "N": 8},
        {"batch": 1, "M": 32, "K": 32, "N": 32},
    ],
    argtypes_factory=_bmm_argtypes,
)


# ---------------------------------------------------------------------------
# fp16 matmul / bmm variants — same semantics, _Float16 storage.
# The accumulator widens to float for numerics then narrows back.
# ---------------------------------------------------------------------------

MATMUL_F16 = KernelSpec(
    op="matmul_f16",
    signature=(
        "void kernel_matmul_f16(const _Float16 *A, const _Float16 *B, "
        "_Float16 *C, int M, int K, int N)"
    ),
    semantics=(
        "Dense matrix multiply C = A @ B, _Float16 storage:\n"
        "  A: [M, K],  B: [K, N],  C: [M, N]\n"
        "  C[m, n] = sum_{k=0..K-1} A[m*K+k] * B[k*N+n]  (fp16 arithmetic)"
    ),
    reference_impl="""\
void kernel_matmul_f16(const _Float16 *A, const _Float16 *B,
                       _Float16 *C, int M, int K, int N) {
    for (int m = 0; m < M; m++) {
        for (int n = 0; n < N; n++) {
            float acc = 0.0f;
            for (int k = 0; k < K; k++)
                acc += (float)A[m * K + k] * (float)B[k * N + n];
            C[m * N + n] = (_Float16)acc;
        }
    }
}
""",
    extra_shapes=_MATMUL_EXTRA_SHAPES,
    argtypes_factory=_matmul_f16_argtypes,
)

MATMUL_TA_F16 = KernelSpec(
    op="matmul_ta_f16",
    signature=(
        "void kernel_matmul_ta_f16(const _Float16 *A, const _Float16 *B, "
        "_Float16 *C, int M, int K, int N)"
    ),
    semantics=(
        "Dense matrix multiply C = A.T @ B, _Float16 storage:\n"
        "  A stored: [K, M],  B: [K, N],  C: [M, N]"
    ),
    reference_impl="""\
void kernel_matmul_ta_f16(const _Float16 *A, const _Float16 *B,
                          _Float16 *C, int M, int K, int N) {
    for (int m = 0; m < M; m++) {
        for (int n = 0; n < N; n++) {
            float acc = 0.0f;
            for (int k = 0; k < K; k++)
                acc += (float)A[k * M + m] * (float)B[k * N + n];
            C[m * N + n] = (_Float16)acc;
        }
    }
}
""",
    extra_shapes=_MATMUL_EXTRA_SHAPES,
    argtypes_factory=_matmul_f16_argtypes,
)

MATMUL_TB_F16 = KernelSpec(
    op="matmul_tb_f16",
    signature=(
        "void kernel_matmul_tb_f16(const _Float16 *A, const _Float16 *B, "
        "_Float16 *C, int M, int K, int N)"
    ),
    semantics=(
        "Dense matrix multiply C = A @ B.T, _Float16 storage:\n"
        "  A: [M, K],  B stored: [N, K],  C: [M, N]"
    ),
    reference_impl="""\
void kernel_matmul_tb_f16(const _Float16 *A, const _Float16 *B,
                          _Float16 *C, int M, int K, int N) {
    for (int m = 0; m < M; m++) {
        for (int n = 0; n < N; n++) {
            float acc = 0.0f;
            for (int k = 0; k < K; k++)
                acc += (float)A[m * K + k] * (float)B[n * K + k];
            C[m * N + n] = (_Float16)acc;
        }
    }
}
""",
    extra_shapes=_MATMUL_EXTRA_SHAPES,
    argtypes_factory=_matmul_f16_argtypes,
)

MATMUL_TATB_F16 = KernelSpec(
    op="matmul_tatb_f16",
    signature=(
        "void kernel_matmul_tatb_f16(const _Float16 *A, const _Float16 *B, "
        "_Float16 *C, int M, int K, int N)"
    ),
    semantics=(
        "Dense matrix multiply C = A.T @ B.T, _Float16 storage:\n"
        "  A stored: [K, M],  B stored: [N, K],  C: [M, N]"
    ),
    reference_impl="""\
void kernel_matmul_tatb_f16(const _Float16 *A, const _Float16 *B,
                            _Float16 *C, int M, int K, int N) {
    for (int m = 0; m < M; m++) {
        for (int n = 0; n < N; n++) {
            float acc = 0.0f;
            for (int k = 0; k < K; k++)
                acc += (float)A[k * M + m] * (float)B[n * K + k];
            C[m * N + n] = (_Float16)acc;
        }
    }
}
""",
    extra_shapes=_MATMUL_EXTRA_SHAPES,
    argtypes_factory=_matmul_f16_argtypes,
)

BMM_F16 = KernelSpec(
    op="bmm_f16",
    signature=(
        "void kernel_bmm_f16(const _Float16 *A, const _Float16 *B, "
        "_Float16 *C, int batch, int M, int K, int N)"
    ),
    semantics=(
        "Batched matrix multiply C[b] = A[b] @ B[b], _Float16 storage:\n"
        "  A: [batch, M, K],  B: [batch, K, N],  C: [batch, M, N]"
    ),
    reference_impl="""\
void kernel_bmm_f16(const _Float16 *A, const _Float16 *B,
                   _Float16 *C, int batch, int M, int K, int N) {
    for (int b = 0; b < batch; b++) {
        const _Float16 *Ab = A + b * M * K;
        const _Float16 *Bb = B + b * K * N;
        _Float16 *Cb = C + b * M * N;
        for (int m = 0; m < M; m++) {
            for (int n = 0; n < N; n++) {
                float acc = 0.0f;
                for (int k = 0; k < K; k++)
                    acc += (float)Ab[m * K + k] * (float)Bb[k * N + n];
                Cb[m * N + n] = (_Float16)acc;
            }
        }
    }
}
""",
    extra_shapes=[
        {"batch": 1, "M": 1,  "K": 1,  "N": 1},
        {"batch": 2, "M": 4,  "K": 8,  "N": 4},
        {"batch": 4, "M": 8,  "K": 16, "N": 8},
        {"batch": 1, "M": 32, "K": 32, "N": 32},
    ],
    argtypes_factory=_bmm_f16_argtypes,
)


ELU = KernelSpec(
    op="elu",
    signature="void kernel_elu(const float *input, float *output, int n, float alpha)",
    semantics=(
        "Elementwise ELU on a contiguous float32 buffer:\n"
        "  output[i] = input[i]                       if input[i] > 0\n"
        "  output[i] = alpha * (expf(input[i]) - 1)   otherwise\n"
        "It must be safe for `input` and `output` to alias. The most common "
        "value of alpha is 1.0 — that's what nn.ELU defaults to."
    ),
    reference_impl="""\
void kernel_elu(const float *input, float *output, int n, float alpha) {
    for (int i = 0; i < n; i++) {
        float v = input[i];
        output[i] = v > 0.0f ? v : alpha * (expf(v) - 1.0f);
    }
}
""",
    extra_shapes=[
        {"n": 1},
        {"n": 16},
        {"n": 256},
        {"n": 1024},
    ],
    argtypes_factory=_elu_argtypes,
)


RELU = KernelSpec(
    op="relu",
    signature="void kernel_relu(const float *input, float *output, int n)",
    semantics=(
        "Elementwise ReLU on a contiguous float32 buffer:\n"
        "  output[i] = max(0.0f, input[i])  for i in [0, n)\n"
        "It must be safe for `input` and `output` to alias."
    ),
    reference_impl="""\
void kernel_relu(const float *input, float *output, int n) {
    for (int i = 0; i < n; i++) {
        float v = input[i];
        output[i] = v > 0.0f ? v : 0.0f;
    }
}
""",
    extra_shapes=[
        {"n": 1},
        {"n": 17},
        {"n": 1024},
    ],
    argtypes_factory=_relu_argtypes,
)


CONV2D = KernelSpec(
    op="conv2d",
    signature=(
        "void kernel_conv2d(const float *input, const float *weight, "
        "const float *bias, float *output, "
        "int N, int IC, int IH, int IW, int OC, "
        "int KH, int KW, int SH, int SW, int PH, int PW)"
    ),
    semantics=(
        "2D convolution matching torch.nn.Conv2d semantics with groups=1, "
        "dilation=1.\n"
        "Layout (row-major, NCHW for activations / OIHW for weights):\n"
        "  input:  [N, IC, IH, IW]\n"
        "  weight: [OC, IC, KH, KW]\n"
        "  bias:   [OC] (may be NULL — treat as zeros)\n"
        "  output: [N, OC, OH, OW]  with\n"
        "    OH = (IH + 2*PH - KH) / SH + 1\n"
        "    OW = (IW + 2*PW - KW) / SW + 1\n"
        "Definition (zero-padding implied by PH, PW):\n"
        "  output[n, oc, oh, ow] = bias[oc] + sum over ic, kh, kw of\n"
        "    input[n, ic, oh*SH - PH + kh, ow*SW - PW + kw]\n"
        "    * weight[oc, ic, kh, kw]\n"
        "  with input reads outside [0, IH) x [0, IW) treated as 0.\n"
        "All tensors are float32."
    ),
    reference_impl="""\
void kernel_conv2d(const float *input, const float *weight, const float *bias,
                   float *output,
                   int N, int IC, int IH, int IW, int OC,
                   int KH, int KW, int SH, int SW, int PH, int PW) {
    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;
    for (int n = 0; n < N; n++) {
        for (int oc = 0; oc < OC; oc++) {
            for (int oh = 0; oh < OH; oh++) {
                for (int ow = 0; ow < OW; ow++) {
                    float acc = bias ? bias[oc] : 0.0f;
                    for (int ic = 0; ic < IC; ic++) {
                        for (int kh = 0; kh < KH; kh++) {
                            int ih = oh * SH - PH + kh;
                            if (ih < 0 || ih >= IH) continue;
                            for (int kw = 0; kw < KW; kw++) {
                                int iw = ow * SW - PW + kw;
                                if (iw < 0 || iw >= IW) continue;
                                float v = input[((n*IC + ic)*IH + ih)*IW + iw];
                                float w = weight[((oc*IC + ic)*KH + kh)*KW + kw];
                                acc += v * w;
                            }
                        }
                    }
                    output[((n*OC + oc)*OH + oh)*OW + ow] = acc;
                }
            }
        }
    }
}
""",
    extra_shapes=[
        # LeNet
        {"N": 1, "IC": 1, "IH": 28, "IW": 28, "OC": 6,
         "KH": 5, "KW": 5, "SH": 1, "SW": 1, "PH": 0, "PW": 0},
        {"N": 1, "IC": 6, "IH": 12, "IW": 12, "OC": 16,
         "KH": 5, "KW": 5, "SH": 1, "SW": 1, "PH": 0, "PW": 0},
        # DroNet-style (3x3 stride=2 padding=1, 1x1 stride=2, 3x3 padding=1)
        {"N": 1, "IC": 32, "IH": 16, "IW": 16, "OC": 64,
         "KH": 3, "KW": 3, "SH": 2, "SW": 2, "PH": 1, "PW": 1},
        {"N": 1, "IC": 64, "IH": 8, "IW": 8, "OC": 64,
         "KH": 3, "KW": 3, "SH": 1, "SW": 1, "PH": 1, "PW": 1},
        {"N": 1, "IC": 32, "IH": 16, "IW": 16, "OC": 64,
         "KH": 1, "KW": 1, "SH": 2, "SW": 2, "PH": 0, "PW": 0},
        # Trained DroNet first conv (3-channel 112x112).
        {"N": 1, "IC": 3, "IH": 112, "IW": 112, "OC": 32,
         "KH": 3, "KW": 3, "SH": 2, "SW": 2, "PH": 1, "PW": 1},
        # Asymmetric / small / generalization
        {"N": 1, "IC": 3, "IH": 7, "IW": 5, "OC": 4,
         "KH": 3, "KW": 3, "SH": 1, "SW": 1, "PH": 1, "PW": 1},
    ],
    argtypes_factory=_conv2d_argtypes,
    algorithms=[
        AlgorithmCandidate(
            name="direct",
            # Verbatim copy of the spec's reference_impl (the verify oracle),
            # so it agrees bit-for-bit by construction.
            accuracy_class=AccuracyClass.BIT_EXACT,
            description=(
                "Direct sliding-window convolution. Six nested loops over "
                "(n, oc, oh, ow, ic, kh, kw) reading input pixels with "
                "explicit bounds checks for padding. No extra memory. Fine "
                "for small spatial dims and 1x1 kernels but the boundary "
                "checks make vectorization awkward."
            ),
            reference_impl="""\
void kernel_conv2d(const float *input, const float *weight, const float *bias,
                   float *output,
                   int N, int IC, int IH, int IW, int OC,
                   int KH, int KW, int SH, int SW, int PH, int PW) {
    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;
    for (int n = 0; n < N; n++) {
        for (int oc = 0; oc < OC; oc++) {
            for (int oh = 0; oh < OH; oh++) {
                for (int ow = 0; ow < OW; ow++) {
                    float acc = bias ? bias[oc] : 0.0f;
                    for (int ic = 0; ic < IC; ic++) {
                        for (int kh = 0; kh < KH; kh++) {
                            int ih = oh * SH - PH + kh;
                            if (ih < 0 || ih >= IH) continue;
                            for (int kw = 0; kw < KW; kw++) {
                                int iw = ow * SW - PW + kw;
                                if (iw < 0 || iw >= IW) continue;
                                float v = input[((n*IC + ic)*IH + ih)*IW + iw];
                                float w = weight[((oc*IC + ic)*KH + kh)*KW + kw];
                                acc += v * w;
                            }
                        }
                    }
                    output[((n*OC + oc)*OH + oh)*OW + ow] = acc;
                }
            }
        }
    }
}
""",
        ),
        AlgorithmCandidate(
            name="im2col_gemm",
            description=(
                "im2col + GEMM lowering of 2D convolution. This is a "
                "two-stage algorithm — your kernel MUST keep the stages "
                "separate.\n\n"
                "STAGE 1 (im2col gather; no math, just data movement):\n"
                "  Allocate `float im2col_buf[OH*OW * IC*KH*KW];` as a "
                "stack VLA (the harness main stack is sized for this).\n"
                "  For each output position (oh, ow), gather the IC*KH*KW "
                "input values that contribute to that output into row "
                "(oh*OW + ow) of im2col_buf. Pad reads outside "
                "[0, IH) x [0, IW) with 0.0. This stage produces NO "
                "arithmetic ops — just loads, conditional zero-fills, and "
                "stores into im2col_buf.\n\n"
                "STAGE 2 (GEMM; all the arithmetic):\n"
                "  Compute output[n, oc, oh*OW + ow] = bias[oc] + "
                "sum_k im2col_buf[oh*OW + ow, k] * weight[oc, k] where "
                "weight is treated as an [OC, IC*KH*KW] matrix (identical "
                "memory layout to OIHW). Stage 2 reads exclusively from "
                "im2col_buf and weight; it MUST NOT touch the original "
                "`input` array.\n\n"
                "Why this lowering matters: stage 2 is a standard "
                "[OH*OW, K] x [OC, K]^T matmul where K = IC*KH*KW. The "
                "reduction loop over k vectorizes cleanly without any "
                "padding-aware indexing, regardless of the conv's stride or "
                "padding. The padding/stride logic is fully isolated in the "
                "non-arithmetic gather of stage 1.\n\n"
                "Numerical equivalence: as long as im2col_buf is populated "
                "in the order ic-major then kh, then kw, the matmul "
                "summation order matches direct convolution and the result "
                "is bit-equivalent.\n\n"
                "DO NOT fuse the two stages into one loop nest. DO NOT "
                "skip the im2col_buf allocation. DO NOT read from `input` "
                "inside stage 2. If you write a loop that reads from "
                "`input` and `weight` in the same iteration, you have "
                "fused the stages — that is the *direct* algorithm, not "
                "the im2col_gemm algorithm.\n\n"
                "VECTORIZATION GUIDANCE (scalar target backend should ignore "
                "this): Keep stage 1 (the gather) **scalar** for now — its "
                "memory access pattern is irregular and vectorizing it is "
                "bug-prone. Vectorize ONLY stage 2 (the matmul) over the "
                "reduction dim k. The canonical per-output-element pattern "
                "for the rvv backend is:\n\n"
                "  size_t vl;\n"
                "  size_t vlmax = __riscv_vsetvlmax_e32m1();\n"
                "  vfloat32m1_t vacc = __riscv_vfmv_v_f_f32m1(0.0f, vlmax);\n"
                "  for (int k = 0; k < K; k += vl) {\n"
                "      vl = __riscv_vsetvl_e32m1(K - k);\n"
                "      vfloat32m1_t va = __riscv_vle32_v_f32m1(\n"
                "          &im2col_buf[row * K + k], vl);\n"
                "      vfloat32m1_t vw = __riscv_vle32_v_f32m1(\n"
                "          &weight[oc * K + k], vl);\n"
                "      vacc = __riscv_vfmacc_vv_f32m1(vacc, va, vw, vl);\n"
                "  }\n"
                "  vfloat32m1_t vinit = __riscv_vfmv_s_f_f32m1(0.0f, 1);\n"
                "  vfloat32m1_t vsum = __riscv_vfredusum_vs_f32m1_f32m1(\n"
                "      vacc, vinit, vlmax);\n"
                "  float acc = __riscv_vfmv_f_s_f32m1_f32(vsum)\n"
                "      + (bias ? bias[oc] : 0.0f);\n"
                "  output[(n * OC + oc) * M + row] = acc;\n\n"
                "Common bugs to avoid:\n"
                "  * vfmv_v_f (broadcast to ALL lanes) is the right "
                "init for the accumulator; vfmv_s_f (single-lane move) is "
                "for the reduction's scalar init slot only.\n"
                "  * vle32_v_f32m1 takes a POINTER, not a value: "
                "`&im2col_buf[row * K + k]` or `im2col_buf + row * K + k`. "
                "Writing `im2col_buf[row * K + k]` as the first arg passes "
                "a float and fails to compile.\n"
                "  * Add bias as a scalar AFTER the horizontal reduction. "
                "Don't try to broadcast bias into vacc and then reduce — "
                "that double-counts."
            ),
            reference_impl="""\
void kernel_conv2d(const float *input, const float *weight, const float *bias,
                   float *output,
                   int N, int IC, int IH, int IW, int OC,
                   int KH, int KW, int SH, int SW, int PH, int PW) {
    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;
    int M = OH * OW;
    int K = IC * KH * KW;

    /* Stack VLA — sized at runtime, harness stack is sized for it. */
    float im2col_buf[M * K];

    for (int n = 0; n < N; n++) {
        /* Stage 1: im2col gather, padding-aware. */
        for (int oh = 0; oh < OH; oh++) {
            for (int ow = 0; ow < OW; ow++) {
                int row = oh * OW + ow;
                for (int ic = 0; ic < IC; ic++) {
                    for (int kh = 0; kh < KH; kh++) {
                        int ih = oh * SH - PH + kh;
                        for (int kw = 0; kw < KW; kw++) {
                            int iw = ow * SW - PW + kw;
                            int col = (ic * KH + kh) * KW + kw;
                            float v = 0.0f;
                            if (ih >= 0 && ih < IH && iw >= 0 && iw < IW) {
                                v = input[((n*IC + ic)*IH + ih)*IW + iw];
                            }
                            im2col_buf[row * K + col] = v;
                        }
                    }
                }
            }
        }

        /* Stage 2: GEMM. weight is [OC, K] (OIHW flattened), output is
         * NCHW which equals [N, OC, M] when M = OH*OW. */
        for (int oc = 0; oc < OC; oc++) {
            float b = bias ? bias[oc] : 0.0f;
            for (int row = 0; row < M; row++) {
                float acc = b;
                for (int k = 0; k < K; k++) {
                    acc += im2col_buf[row * K + k] * weight[oc * K + k];
                }
                output[(n * OC + oc) * M + row] = acc;
            }
        }
    }
}
""",
        ),
        AlgorithmCandidate(
            name="oc_blocked",
            description=(
                "Cache-blocked direct convolution. Same arithmetic as the "
                "`direct` algorithm — six nested loops over (n, oc, oh, "
                "ow, ic, kh, kw) — but the OUTPUT-CHANNEL dimension is "
                "tiled so that one slab of the weight tensor stays "
                "resident in L1D across the entire OH*OW spatial sweep. "
                "This is purely a loop-restructuring optimization: the "
                "compiler emits the same FMACs in the same order; we just "
                "change which dimension is outermost so weight reuse "
                "happens at L1D rather than L2/LLC.\n\n"
                "STRUCTURE (the LLM MUST follow this exactly):\n"
                "  Define TILE_OC at the top of the function. Aim for "
                "TILE_OC * IC * KH * KW * 4 bytes <= ~24 KB so the slab "
                "fits in 32 KB L1D with room for input/output. For "
                "OC>=128 IC>=128 K=3 use TILE_OC=4. For smaller IC use "
                "TILE_OC=8 or 16.\n\n"
                "  for (oc_outer = 0; oc_outer < OC; oc_outer += TILE_OC) {\n"
                "      // Hot weight slab: weight[oc_outer .. oc_outer + tile - 1]\n"
                "      // is now reused across the (oh, ow) sweep below.\n"
                "      for (n = 0; n < N; n++)\n"
                "      for (oh = 0; oh < OH; oh++)\n"
                "      for (ow = 0; ow < OW; ow++)\n"
                "      for (oc_inner = 0; oc_inner < tile; oc_inner++) {\n"
                "          int oc = oc_outer + oc_inner;\n"
                "          float acc = bias ? bias[oc] : 0.0f;\n"
                "          // standard 3-deep ic/kh/kw reduction here\n"
                "          output[((n*OC + oc)*OH + oh)*OW + ow] = acc;\n"
                "      }\n"
                "  }\n\n"
                "Why this matters: a direct conv2d with the OC loop in "
                "the middle pulls the entire weight tensor through L1D "
                "OH*OW times. With OC blocked outermost, each weight "
                "loaded into L1D once is reused OH*OW times before "
                "eviction. For dronet's heavy 3x3 conv (OC=128, IC=128, "
                "OH=4, OW=4) that's a 16x reduction in weight traffic to "
                "L2/LLC.\n\n"
                "TAIL HANDLING: when OC is not a multiple of TILE_OC, "
                "the final outer iteration uses tile = OC - oc_outer "
                "(may be < TILE_OC). Compute it inside the outer loop:\n"
                "  int tile = TILE_OC;\n"
                "  if (oc_outer + tile > OC) tile = OC - oc_outer;\n\n"
                "RVV vectorization (rvv backend only): you may vectorize "
                "the IC reduction inside the inner per-output-element "
                "block exactly the same way as the `direct` algorithm — "
                "this transformation only restructures the OC loop, not "
                "the inner reduction.\n\n"
                "DO NOT remove the `oc_outer += TILE_OC` outer loop — "
                "it's the entire point of this algorithm. DO NOT pick "
                "TILE_OC = 1 (that's just the direct algorithm with "
                "extra overhead). DO NOT pick TILE_OC = OC (that's also "
                "just the direct algorithm). Pick a fixed TILE_OC "
                "constant; do not compute it from runtime IC — the "
                "compiler needs the constant to keep the inner-loop "
                "indexing cheap."
            ),
            reference_impl="""\
void kernel_conv2d(const float *input, const float *weight, const float *bias,
                   float *output,
                   int N, int IC, int IH, int IW, int OC,
                   int KH, int KW, int SH, int SW, int PH, int PW) {
    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;
    /* Tile so one OC-slab of weights fits in ~24 KB of L1D.
     * For OC=128 IC=128 K=3: 4 * 128 * 9 * 4 = 18 KB. */
    const int TILE_OC = 4;

    for (int oc_outer = 0; oc_outer < OC; oc_outer += TILE_OC) {
        int tile = TILE_OC;
        if (oc_outer + tile > OC) tile = OC - oc_outer;
        for (int n = 0; n < N; n++) {
            for (int oh = 0; oh < OH; oh++) {
                for (int ow = 0; ow < OW; ow++) {
                    for (int oc_inner = 0; oc_inner < tile; oc_inner++) {
                        int oc = oc_outer + oc_inner;
                        float acc = bias ? bias[oc] : 0.0f;
                        for (int ic = 0; ic < IC; ic++) {
                            for (int kh = 0; kh < KH; kh++) {
                                int ih = oh * SH - PH + kh;
                                if (ih < 0 || ih >= IH) continue;
                                for (int kw = 0; kw < KW; kw++) {
                                    int iw = ow * SW - PW + kw;
                                    if (iw < 0 || iw >= IW) continue;
                                    float v = input[((n*IC + ic)*IH + ih)*IW + iw];
                                    float w = weight[((oc*IC + ic)*KH + kh)*KW + kw];
                                    acc += v * w;
                                }
                            }
                        }
                        output[((n*OC + oc)*OH + oh)*OW + ow] = acc;
                    }
                }
            }
        }
    }
}
""",
            # OC-blocked is only worth the loop-restructure cost when
            # the weight tensor is too large to stay in L1D. Skip on
            # tiny channel counts where direct already wins easily.
            applicable=lambda s: s.get("OC", 0) >= 32 and s.get("IC", 0) >= 16,
        ),
    ],
)


MAXPOOL2D = KernelSpec(
    op="maxpool2d",
    signature=(
        "void kernel_maxpool2d(const float *input, float *output, "
        "int N, int C, int IH, int IW, "
        "int KH, int KW, int SH, int SW, "
        "int PH, int PW, int DH, int DW)"
    ),
    semantics=(
        "2D max pooling matching torch.nn.MaxPool2d semantics with padding\n"
        "and dilation.\n"
        "Layout (NCHW, row-major):\n"
        "  input:  [N, C, IH, IW]\n"
        "  output: [N, C, OH, OW]  with\n"
        "    OH = (IH + 2*PH - DH*(KH-1) - 1) / SH + 1\n"
        "    OW = (IW + 2*PW - DW*(KW-1) - 1) / SW + 1\n"
        "  output[n, c, oh, ow] = max over kh in [0,KH), kw in [0,KW) of\n"
        "    val(n, c, oh*SH - PH + kh*DH, ow*SW - PW + kw*DW)\n"
        "  where val(...) returns input[n, c, ih, iw] when 0<=ih<IH and\n"
        "  0<=iw<IW, else -INF (out-of-bounds lanes never win the max).\n"
        "All tensors are float32. PH/PW are zero-padding amounts on the\n"
        "spatial dims; DH/DW are kernel-element strides (dilation)."
    ),
    reference_impl="""\
#include <float.h>

void kernel_maxpool2d(const float *input, float *output,
                     int N, int C, int IH, int IW,
                     int KH, int KW, int SH, int SW,
                     int PH, int PW, int DH, int DW) {
    int OH = (IH + 2*PH - DH*(KH-1) - 1) / SH + 1;
    int OW = (IW + 2*PW - DW*(KW-1) - 1) / SW + 1;
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            for (int oh = 0; oh < OH; oh++) {
                for (int ow = 0; ow < OW; ow++) {
                    float m = -FLT_MAX;
                    for (int kh = 0; kh < KH; kh++) {
                        int ih = oh*SH - PH + kh*DH;
                        if (ih < 0 || ih >= IH) continue;
                        for (int kw = 0; kw < KW; kw++) {
                            int iw = ow*SW - PW + kw*DW;
                            if (iw < 0 || iw >= IW) continue;
                            float v = input[((n*C + c)*IH + ih)*IW + iw];
                            if (v > m) m = v;
                        }
                    }
                    output[((n*C + c)*OH + oh)*OW + ow] = m;
                }
            }
        }
    }
}
""",
    extra_shapes=[
        # LeNet
        {"N": 1, "C": 6, "IH": 24, "IW": 24, "KH": 2, "KW": 2, "SH": 2, "SW": 2,
         "PH": 0, "PW": 0, "DH": 1, "DW": 1},
        {"N": 1, "C": 16, "IH": 8, "IW": 8, "KH": 2, "KW": 2, "SH": 2, "SW": 2,
         "PH": 0, "PW": 0, "DH": 1, "DW": 1},
        # DroNet
        {"N": 1, "C": 32, "IH": 64, "IW": 64, "KH": 3, "KW": 3, "SH": 2, "SW": 2,
         "PH": 0, "PW": 0, "DH": 1, "DW": 1},
        # Generalization
        {"N": 1, "C": 4, "IH": 9, "IW": 7, "KH": 3, "KW": 3, "SH": 2, "SW": 2,
         "PH": 0, "PW": 0, "DH": 1, "DW": 1},
        # KernelBench 42: padding=1, dilation=3
        {"N": 1, "C": 8, "IH": 16, "IW": 16, "KH": 2, "KW": 2, "SH": 2, "SW": 2,
         "PH": 1, "PW": 1, "DH": 3, "DW": 3},
    ],
    argtypes_factory=_maxpool2d_argtypes,
)


ADD = KernelSpec(
    op="add",
    signature=(
        "void kernel_add(const float *a, const float *b, float *output, int n)"
    ),
    semantics=(
        "Elementwise float32 add over a contiguous buffer:\n"
        "  output[i] = a[i] + b[i]   for i in [0, n)\n"
        "It must be safe for output to alias either input."
    ),
    reference_impl="""\
void kernel_add(const float *a, const float *b, float *output, int n) {
    for (int i = 0; i < n; i++) {
        output[i] = a[i] + b[i];
    }
}
""",
    extra_shapes=[
        {"n": 1},
        {"n": 17},
        {"n": 1024},
        {"n": 8192},          # DroNet residual block 0 output
    ],
    argtypes_factory=_add_argtypes,
)


BATCHNORM2D = KernelSpec(
    op="batchnorm2d",
    signature=(
        "void kernel_batchnorm2d(const float *input, const float *scale, "
        "const float *bias, float *output, int N, int C, int H, int W)"
    ),
    semantics=(
        "Per-channel affine on a NCHW float32 activation.\n"
        "  output[n, c, h, w] = scale[c] * input[n, c, h, w] + bias[c]\n"
        "scale and bias are length-C arrays. This is a fused form of an\n"
        "eval-mode torch.nn.BatchNorm2d: scale = gamma / sqrt(var + eps),\n"
        "bias  = beta - mean * scale. The kernel only sees the fused values."
    ),
    reference_impl="""\
void kernel_batchnorm2d(const float *input, const float *scale,
                        const float *bias, float *output,
                        int N, int C, int H, int W) {
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            float s = scale[c];
            float b = bias[c];
            for (int h = 0; h < H; h++) {
                for (int w = 0; w < W; w++) {
                    int idx = ((n*C + c)*H + h)*W + w;
                    output[idx] = s * input[idx] + b;
                }
            }
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "C": 32, "H": 16, "W": 16},
        {"N": 1, "C": 64, "H": 8, "W": 8},
        {"N": 1, "C": 128, "H": 4, "W": 4},
        {"N": 1, "C": 7, "H": 5, "W": 3},
    ],
    argtypes_factory=_batchnorm2d_argtypes,
)


SIGMOID = KernelSpec(
    op="sigmoid",
    signature=(
        "void kernel_sigmoid(const float *input, float *output, int n)"
    ),
    semantics=(
        "Elementwise sigmoid on a contiguous float32 buffer:\n"
        "  output[i] = 1.0f / (1.0f + expf(-input[i]))   for i in [0, n)\n"
        "expf comes from <math.h> which is already in scope."
    ),
    reference_impl="""\
void kernel_sigmoid(const float *input, float *output, int n) {
    for (int i = 0; i < n; i++) {
        output[i] = 1.0f / (1.0f + expf(-input[i]));
    }
}
""",
    extra_shapes=[
        {"n": 1},
        {"n": 16},
        {"n": 256},
    ],
    argtypes_factory=_sigmoid_argtypes,
)


# ---------------------------------------------------------------------------
# int8 op kinds (muRISCV-NN convention)
# ---------------------------------------------------------------------------

LINEAR_S8 = KernelSpec(
    op="linear_s8",
    signature=(
        "void kernel_linear_s8(const int8_t *input, const int8_t *weight, "
        "const int32_t *bias, int8_t *output, "
        "int M, int K, int N, "
        "int input_offset, int filter_offset, int output_offset, "
        "int output_multiplier, int output_shift, "
        "int activation_min, int activation_max)"
    ),
    semantics=(
        "Quantized fully-connected layer (per-tensor symmetric, "
        "muRISCV-NN / CMSIS-NN convention).\n"
        "Layout (row-major):\n"
        "  input:  int8  [M, K]\n"
        "  weight: int8  [N, K]   (out_features outer, like nn.Linear)\n"
        "  bias:   int32 [N]      (pre-scaled to s_in*s_w; may be NULL)\n"
        "  output: int8  [M, N]\n"
        "Compute (per output element):\n"
        "  acc = bias[n]   if bias != NULL else 0\n"
        "  for k in 0..K-1:\n"
        "    acc += (input[m, k] + input_offset)\n"
        "         * (weight[n, k] + filter_offset)\n"
        "  acc = requantize(acc, output_multiplier, output_shift)\n"
        "  acc += output_offset\n"
        "  acc = clamp(acc, activation_min, activation_max)\n"
        "  output[m, n] = (int8_t) acc\n\n"
        "requantize(x, mult, shift) is the canonical Q0.31 fixed-point\n"
        "rounding-multiply-and-shift used in CMSIS-NN / muRISCV-NN:\n"
        "  int64 prod = (int64) x * (int64) mult;\n"
        "  prod = (prod + (1LL << 30)) >> 31;          // round to even\n"
        "  if (shift > 0) {\n"
        "    int32 round = (1 << (shift - 1));\n"
        "    return ((int32) prod + round) >> shift;\n"
        "  } else {\n"
        "    return (int32) prod << -shift;\n"
        "  }\n\n"
        "Notes:\n"
        "  * activation_min/max fold ReLU into the requantize tail. For a\n"
        "    fused ReLU pass activation_min = output_offset (often 0 in\n"
        "    symmetric quant, where it just becomes 0).\n"
        "  * Symmetric per-tensor quant (the only mode the IR emits today)\n"
        "    means input_offset = filter_offset = output_offset = 0; the\n"
        "    kernel must still accept the parameters for API parity with\n"
        "    asymmetric variants we'll add later.\n"
    ),
    reference_impl="""\
void kernel_linear_s8(const int8_t *input, const int8_t *weight,
                      const int32_t *bias, int8_t *output,
                      int M, int K, int N,
                      int input_offset, int filter_offset, int output_offset,
                      int output_multiplier, int output_shift,
                      int activation_min, int activation_max) {
    for (int m = 0; m < M; m++) {
        for (int n = 0; n < N; n++) {
            int32_t acc = bias ? bias[n] : 0;
            for (int k = 0; k < K; k++) {
                int32_t in_v = (int32_t)input[m * K + k] + input_offset;
                int32_t w_v  = (int32_t)weight[n * K + k] + filter_offset;
                acc += in_v * w_v;
            }
            /* Q0.31 rounding multiply. */
            int64_t prod = (int64_t)acc * (int64_t)output_multiplier;
            prod = (prod + (1LL << 30)) >> 31;
            int32_t scaled = (int32_t)prod;
            if (output_shift > 0) {
                scaled = (int32_t)(((int64_t)scaled + ((int64_t)1 << (output_shift - 1))) >> output_shift);
            } else if (output_shift < 0) {
                scaled = scaled << (-output_shift);
            }
            scaled += output_offset;
            if (scaled < activation_min) scaled = activation_min;
            if (scaled > activation_max) scaled = activation_max;
            output[m * N + n] = (int8_t)scaled;
        }
    }
}
""",
    extra_shapes=[
        # MLP shapes
        {"M": 1, "K": 16, "N": 32},
        {"M": 1, "K": 32, "N": 32},
        {"M": 1, "K": 32, "N": 10},
        # Generalization
        {"M": 1, "K": 7,  "N": 13},
        {"M": 4, "K": 17, "N": 23},
        # dronet linear2: a SINGLE output. A kernel vectorized over N runs
        # at vl=1 here; nothing else covered that tail.
        {"M": 1, "K": 64, "N": 1},
        # dronet's ACTUAL linear1/linear2 heads (kernel_opt_log 1000+): both
        # run at M=1,K=2048,N=1 -- the N=1 tail above only tested K=64. K=2048
        # is 32x larger (more K-chunk iterations before the vl=1 tail), which
        # the K=64 shape cannot exercise.
        {"M": 1, "K": 2048, "N": 1},
    ],
    argtypes_factory=_linear_s8_argtypes,
    algorithms=[
        AlgorithmCandidate(
            name="gemmini_tiled_matmul",
            target_affinity=("gemmini", "gemmini_q31"),
            # Bit-exact accumulator (gemmini's 32-bit acc with full_C
            # mvout, no float-scale shortcut), then scalar Q0.31 requantize
            # on CPU using exactly the reference rounding formula. Drift
            # vs the Q0.31 PyTorch golden is ≤1 LSB / layer.
            accuracy_class=AccuracyClass.NUMERIC_DRIFT,
            description=(
                "Route the linear through the Gemmini int8 systolic mesh "
                "via gemmini.h's tiled_matmul_auto(full_C=true). Pass "
                "input as A[M,K] and weight (physically [N,K]) with "
                "transpose_B=true so gemmini sees the logical [K,N] B "
                "matrix. full_C=true asks for raw int32 accumulator "
                "output (no float-mvout scale); we apply the Q0.31 "
                "requantize + bias-add on the CPU side after a "
                "gemmini_fence so the gemmini path matches the conv2d "
                "im2col_full_C precision contract.\n\n"
                "Stage-1 limitations (caller falls back to scalar):\n"
                "  * input_offset / filter_offset / output_offset == 0 "
                "    (symmetric per-tensor int8; matches our extract_int8 "
                "    output).\n"
                "  * output_shift in [0, 30] for the Q0.31 fold path.\n"
                "  * M*N ≤ 16*4096 (static accumulator workspace).\n"
                "  * total_out * K ≥ 256 — below this the per-call "
                "    setup (mstatus, gemmini_flush, fence) exceeds the "
                "    scalar dot-product cost and we fall back."
            ),
            reference_impl="""\
void kernel_linear_s8(const int8_t *input, const int8_t *weight,
                      const int32_t *bias, int8_t *output,
                      int M, int K, int N,
                      int input_offset, int filter_offset, int output_offset,
                      int output_multiplier, int output_shift,
                      int activation_min, int activation_max)
{
    enum { GEMMINI_LIN_ACC_MAX = 16 * 4096 };
    static int32_t ws_acc[GEMMINI_LIN_ACC_MAX] __attribute__((aligned(64)));

    int total_out = M * N;
    if (input_offset != 0 || filter_offset != 0 || output_offset != 0
            || output_shift < 0 || output_shift > 30
            || (size_t)(M * N) > GEMMINI_LIN_ACC_MAX
            || M <= 0 || K <= 0 || N <= 0
            || total_out * K < 256) {
        for (int m = 0; m < M; m++) {
            for (int n = 0; n < N; n++) {
                int32_t acc = bias ? bias[n] : 0;
                for (int k = 0; k < K; k++) {
                    int32_t in_v = (int32_t)input[m * K + k] + input_offset;
                    int32_t w_v  = (int32_t)weight[n * K + k] + filter_offset;
                    acc += in_v * w_v;
                }
                int64_t prod = (int64_t)acc * (int64_t)output_multiplier;
                prod = (prod + (1LL << 30)) >> 31;
                int32_t scaled = (int32_t)prod;
                if (output_shift > 0) {
                    int32_t round = (1 << (output_shift - 1));
                    scaled = (scaled + round) >> output_shift;
                } else if (output_shift < 0) {
                    scaled = scaled << (-output_shift);
                }
                scaled += output_offset;
                if (scaled < activation_min) scaled = activation_min;
                if (scaled > activation_max) scaled = activation_max;
                output[m * N + n] = (int8_t)scaled;
            }
        }
        return;
    }

    asm volatile("csrs mstatus, %0" : : "r"(0x18000) : "memory");
    gemmini_flush(0);
    asm volatile("fence" ::: "memory");

    tiled_matmul_auto(
        (size_t)M, (size_t)N, (size_t)K,
        input, weight,
        NULL, (void *)ws_acc,
        (size_t)K, (size_t)K, (size_t)N, (size_t)N,
        MVIN_SCALE_IDENTITY, MVIN_SCALE_IDENTITY, (scale_acc_t)1,
        NO_ACTIVATION, ACC_SCALE_IDENTITY, (acc_scale_t)0,
        false,
        false, true,
        true, false,
        0, WS
    );

    gemmini_fence();
    gemmini_flush(0);

    for (int m = 0; m < M; m++) {
        for (int n = 0; n < N; n++) {
            int32_t acc = ws_acc[m * N + n] + (bias ? bias[n] : 0);
            int64_t prod = (int64_t)acc * (int64_t)output_multiplier;
            prod = (prod + ((int64_t)1 << 30)) >> 31;
            int32_t scaled = (int32_t)prod;
            if (output_shift > 0) {
                scaled = (int32_t)(((int64_t)scaled
                    + ((int64_t)1 << (output_shift - 1))) >> output_shift);
            } else if (output_shift < 0) {
                scaled <<= (-output_shift);
            }
            scaled += output_offset;
            if (scaled < activation_min) scaled = activation_min;
            if (scaled > activation_max) scaled = activation_max;
            output[m * N + n] = (int8_t)scaled;
        }
    }
}
""",
        ),
        AlgorithmCandidate(
            name="outerprod",
            target_affinity=("rvv_opu",),
            description=(
                "Saturn OPU i8 outer-product MAC with bias broadcast.\n"
                "Ported from\n"
                "  hw/chipyard/generators/saturn/benchmarks/opu-gemm/kernel.h\n"
                "(branch origin/opu-fp8, `i8_mm_bme_sq` + bias variant).\n\n"
                "ALGORITHM:\n"
                "  if bias: vle32.v v0 <- bias[0..N-1]\n"
                "  else:    vmv.v.i v0, 0\n"
                "  OPMVINBCAST m1 <- v0  (broadcast bias to all M rows)\n"
                "  for k in [0, K):\n"
                "    vlse8.v v16, &input[k],  stride=K  -- input[r,k] per row\n"
                "    vlse8.v v18, &weight[k], stride=K  -- weight[c,k] per col\n"
                "    VOPACC m1, v18, v16\n"
                "  drain m1 rows; per-element Q0.31 requantize + clamp + i8.\n\n"
                "Strided loads avoid pre-transpose scratch (supports K up to\n"
                "any size). Symmetric quant only (input_offset = filter_offset\n"
                "= 0); asymmetric falls back to scalar reference. Single OPU\n"
                "tile: M, N <= mlmax = VLEN/8."
            ),
            reference_impl="",  # the curated file supplies the impl
        ),
    ],
)


RELU_S8 = KernelSpec(
    op="relu_s8",
    signature="void kernel_relu_s8(const int8_t *input, int8_t *output, int n)",
    semantics=(
        "Elementwise ReLU on a contiguous int8 buffer with symmetric "
        "quantization (zero_point = 0):\n"
        "  output[i] = max(0, input[i])  for i in [0, n)\n"
        "Standalone version; for fused linear→relu we use linear_s8 with "
        "activation_min = 0."
    ),
    reference_impl="""\
void kernel_relu_s8(const int8_t *input, int8_t *output, int n) {
    for (int i = 0; i < n; i++) {
        int8_t v = input[i];
        output[i] = v > 0 ? v : 0;
    }
}
""",
    extra_shapes=[
        {"n": 1},
        {"n": 17},
        {"n": 256},
    ],
    argtypes_factory=_relu_s8_argtypes,
    algorithms=[
        AlgorithmCandidate(
            name="gemmini_resadd_relu",
            target_affinity=("gemmini", "gemmini_q31"),
            accuracy_class=AccuracyClass.BIT_EXACT,
            description=(
                "Route the elementwise ReLU through gemmini's "
                "tiled_resadd_auto by passing B=zeros and relu=true. "
                "Computes output[i] = sat_int8(relu(A[i]*1 + zero*0)) "
                "= relu(A[i]). The 'add' is semantically a no-op (B is "
                "zero); the gain is from streaming int8 through "
                "gemmini's mvin → mvout pipeline with the requantize-"
                "with-relu unit doing all the work. Saves the scalar "
                "ALU's per-element max(0, x). Same chunking workaround "
                "as add_s8 (≤6272-element pieces) and same fallback for "
                "tiny n."
            ),
            reference_impl="""\
void kernel_relu_s8(const int8_t *input, int8_t *output, int n)
{
    enum { ADD_CHUNK_MAX = 6272 };
    static int8_t zero_buf[ADD_CHUNK_MAX] __attribute__((aligned(64)));
    if (n <= 0 || n < 256) {
        for (int i = 0; i < n; i++) {
            int8_t v = input[i];
            output[i] = v > 0 ? v : 0;
        }
        return;
    }
    asm volatile("csrs mstatus, %0" : : "r"(0x18000) : "memory");
    int remaining = n, offset = 0;
    while (remaining > 0) {
        int chunk = remaining > ADD_CHUNK_MAX ? ADD_CHUNK_MAX : remaining;
        gemmini_flush(0);
        asm volatile("fence" ::: "memory");
        tiled_resadd_auto(
            1, (size_t)chunk,
            (scale_t)1.0f, (scale_t)0.0f, ACC_SCALE_IDENTITY,
            input + offset, zero_buf, output + offset,
            true,
            WS
        );
        gemmini_fence();
        gemmini_flush(0);
        offset += chunk;
        remaining -= chunk;
    }
}
""",
        ),
    ],
)


CONV2D_S8 = KernelSpec(
    op="conv2d_s8",
    signature=(
        "void kernel_conv2d_s8(const int8_t *input, const int8_t *weight, "
        "const int32_t *bias, int8_t *output, "
        "int N, int IC, int IH, int IW, int OC, "
        "int KH, int KW, int SH, int SW, int PH, int PW, "
        "int input_offset, int filter_offset, int output_offset, "
        "int output_multiplier, int output_shift, "
        "int activation_min, int activation_max)"
    ),
    semantics=(
        "Quantized 2D convolution (per-tensor symmetric, muRISCV-NN / "
        "CMSIS-NN convention). Same dataflow as conv2d but in int8 with "
        "an int32 accumulator and a Q0.31 requantize tail.\n"
        "Layout (NCHW for activations, OIHW for weights):\n"
        "  input:  int8  [N, IC, IH, IW]\n"
        "  weight: int8  [OC, IC, KH, KW]\n"
        "  bias:   int32 [OC] (may be NULL)\n"
        "  output: int8  [N, OC, OH, OW]  with OH/OW per the conv2d formula\n"
        "Compute (per output element):\n"
        "  acc = bias[oc] if bias != NULL else 0\n"
        "  for ic, kh, kw with ih = oh*SH-PH+kh, iw = ow*SW-PW+kw:\n"
        "    if (ih, iw) in bounds:\n"
        "      acc += (input[n,ic,ih,iw] + input_offset)\n"
        "           * (weight[oc,ic,kh,kw] + filter_offset)\n"
        "    (input reads outside [0,IH) x [0,IW) treated as 0 — "
        "i.e. their contribution to acc is just `input_offset * "
        "(weight[..] + filter_offset)`. For the symmetric quant case "
        "input_offset = 0 those padded contributions are zero.)\n"
        "  acc = requantize(acc, output_multiplier, output_shift)\n"
        "  acc += output_offset\n"
        "  acc = clamp(acc, activation_min, activation_max)\n"
        "  output[n, oc, oh, ow] = (int8_t) acc\n"
        "Requantize is the same Q0.31 fixed-point rounding-multiply-and-"
        "shift as kernel_linear_s8."
    ),
    reference_impl="""\
void kernel_conv2d_s8(const int8_t *input, const int8_t *weight,
                      const int32_t *bias, int8_t *output,
                      int N, int IC, int IH, int IW, int OC,
                      int KH, int KW, int SH, int SW, int PH, int PW,
                      int input_offset, int filter_offset, int output_offset,
                      int output_multiplier, int output_shift,
                      int activation_min, int activation_max) {
    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;
    /* Weight layout depends on the active hardware target. The gemmini
     * codegen pre-packs to flat HWIO at compile time
     * (generate_skeleton.py::_backend_pack_weight) so the gemmini ROCC
     * kernel can pass the blob straight into tiled_conv_auto without
     * a per-call transpose. backends.py wires
     * MODELBLASTER_GEMMINI_HWIO_WEIGHTS=1 into kernel_cflags only for the
     * gemmini backend; all other backends keep PyTorch OIHW. */
    for (int n = 0; n < N; n++) {
        for (int oc = 0; oc < OC; oc++) {
            for (int oh = 0; oh < OH; oh++) {
                for (int ow = 0; ow < OW; ow++) {
                    int32_t acc = bias ? bias[oc] : 0;
                    for (int ic = 0; ic < IC; ic++) {
                        /* Hoist (n,ic,*) row offsets to size_t so the
                         * multiply by IH*IW happens in 64-bit. Without
                         * this, GCC -O2 occasionally splits the
                         * pointer-+-int32-index addition into 32-bit
                         * `addw` on the low half + 64-bit `add` on the
                         * upper half — fine when (input_low32 + idx)
                         * stays positive, but wraps modulo 2^32 when
                         * it crosses the int32 sign boundary. Hit on
                         * V512D256 firesim with yolov8 because the
                         * wider thread-vreg state shifted BSS placement
                         * past the wrap boundary. */
                        const size_t in_row_base =
                            ((size_t)n * IC + ic) * IH;
                        for (int kh = 0; kh < KH; kh++) {
                            int ih = oh * SH - PH + kh;
                            for (int kw = 0; kw < KW; kw++) {
                                int iw = ow * SW - PW + kw;
                                int32_t in_v;
                                if (ih < 0 || ih >= IH || iw < 0 || iw >= IW) {
                                    in_v = input_offset;
                                } else {
                                    in_v = (int32_t)input[(in_row_base + ih) * IW + iw]
                                         + input_offset;
                                }
#if defined(MODELBLASTER_GEMMINI_HWIO_WEIGHTS) || defined(MODELBLASTER_RVV_IHWOC_WEIGHTS)
                                int32_t w_v = (int32_t)weight[((kh*KW + kw)*IC + ic)*OC + oc]
                                            + filter_offset;
#else
                                int32_t w_v = (int32_t)weight[((oc*IC + ic)*KH + kh)*KW + kw]
                                            + filter_offset;
#endif
                                acc += in_v * w_v;
                            }
                        }
                    }
                    int64_t prod = (int64_t)acc * (int64_t)output_multiplier;
                    prod = (prod + (1LL << 30)) >> 31;
                    int32_t scaled = (int32_t)prod;
                    if (output_shift > 0) {
                        scaled = (int32_t)(((int64_t)scaled + ((int64_t)1 << (output_shift - 1))) >> output_shift);
                    } else if (output_shift < 0) {
                        scaled = scaled << (-output_shift);
                    }
                    scaled += output_offset;
                    if (scaled < activation_min) scaled = activation_min;
                    if (scaled > activation_max) scaled = activation_max;
                    output[((n*OC + oc)*OH + oh)*OW + ow] = (int8_t)scaled;
                }
            }
        }
    }
}
""",
    extra_shapes=[
        # LeNet shapes
        {"N": 1, "IC": 1, "IH": 28, "IW": 28, "OC": 6,
         "KH": 5, "KW": 5, "SH": 1, "SW": 1, "PH": 0, "PW": 0},
        {"N": 1, "IC": 6, "IH": 12, "IW": 12, "OC": 16,
         "KH": 5, "KW": 5, "SH": 1, "SW": 1, "PH": 0, "PW": 0},
        # DroNet-style
        {"N": 1, "IC": 32, "IH": 16, "IW": 16, "OC": 64,
         "KH": 3, "KW": 3, "SH": 2, "SW": 2, "PH": 1, "PW": 1},
        {"N": 1, "IC": 32, "IH": 16, "IW": 16, "OC": 64,
         "KH": 1, "KW": 1, "SH": 2, "SW": 2, "PH": 0, "PW": 0},
        # fused_full vision_cnn.0 shape class: PADDING 2. Every shape above
        # is PH/PW <= 1, so the 2-column border path -- where an out-of-bounds
        # tap must still contribute input_offset rather than be skipped -- was
        # exercised by no build except fused_full's own, on a SHARED kernel.
        {"N": 1, "IC": 1, "IH": 20, "IW": 30, "OC": 16,
         "KH": 5, "KW": 5, "SH": 2, "SW": 2, "PH": 2, "PW": 2},
    ],
    argtypes_factory=_conv2d_s8_argtypes,
    algorithms=[
        AlgorithmCandidate(
            name="indir_gemm",
            target_affinity=("rvv_opu",),
            description=(
                "Saturn OPU indirect-GEMM conv2d_s8 (XNNPACK-style).\n"
                "Maps conv onto the OPU outer-product MAC by addressing\n"
                "the input tensor in its native [N,IC,IH,IW] layout via\n"
                "a per-tile indirection pointer array — no im2col data\n"
                "duplication.\n\n"
                "ALGORITHM:\n"
                "  outer (n, oh, ow_tile in OW step OW_BLK=mlmax):\n"
                "    build indir[KH*KW][OW_BLK]: ptr to IC slice or zero_buf\n"
                "    for oc_tile in OC step mlmax:\n"
                "      OPMVINBCAST m1 <- bias[oc_tile..+mlmax] (padded)\n"
                "      for (kh, kw, ic) in K-reduction:\n"
                "        vs1 = gather i8 lanes from indir[kk][p]+ic (1 per pixel)\n"
                "        vs2 = vlse8 weight[oc_tile..+mlmax, ic, kh, kw]\n"
                "        VOPACC m1, vs2, vs1\n"
                "      drain m1 rows, Q0.31 requantize, i8 store with OC stride\n\n"
                "Indirection is per-tile (~KH*KW*mlmax pointers, stack-safe).\n"
                "Padded entries point at a static __opu_zero_buf so vluxei\n"
                "gathers zeros and VOPACC contributes nothing — branch-free.\n"
                "Symmetric quant only; falls back to scalar reference for\n"
                "asymmetric quant or shapes that exceed scratch caps.\n\n"
                "See modelblaster/notes/opu_indirect_gemm_design.md for the\n"
                "compile-time-indirection follow-up (Option A) once the\n"
                "skeleton supports per-algorithm signatures."
            ),
            reference_impl="",  # the curated file supplies the impl
        ),
        AlgorithmCandidate(
            name="direct",
            # Same nested-loop math as the spec's reference_impl (verify
            # oracle); reads weights from whichever layout the codegen
            # produces (OIHW or HWIO via #ifdef MODELBLASTER_GEMMINI_HWIO_WEIGHTS)
            # but the arithmetic is bit-for-bit identical.
            accuracy_class=AccuracyClass.BIT_EXACT,
            description=(
                "Direct sliding-window int8 conv. Six nested loops over "
                "(n, oc, oh, ow, ic, kh, kw); per-element bounds checks; "
                "i32 accumulator; Q0.31 requantize tail per output element. "
                "No vectorization, no precomputation. The simplest correct "
                "form — useful as a baseline but on RVV it leaves all the "
                "vector lanes idle."
            ),
            reference_impl="""\
void kernel_conv2d_s8(const int8_t *input, const int8_t *weight,
                      const int32_t *bias, int8_t *output,
                      int N, int IC, int IH, int IW, int OC,
                      int KH, int KW, int SH, int SW, int PH, int PW,
                      int input_offset, int filter_offset, int output_offset,
                      int output_multiplier, int output_shift,
                      int activation_min, int activation_max) {
    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;
    for (int n = 0; n < N; n++) {
        for (int oc = 0; oc < OC; oc++) {
            for (int oh = 0; oh < OH; oh++) {
                for (int ow = 0; ow < OW; ow++) {
                    int32_t acc = bias ? bias[oc] : 0;
                    for (int ic = 0; ic < IC; ic++) {
                        /* size_t hoist — see CONV2D_S8 spec.reference_impl
                         * for the full rationale (V512 BSS-placement + GCC
                         * 32-bit addw wrap). */
                        const size_t in_row_base =
                            ((size_t)n * IC + ic) * IH;
                        for (int kh = 0; kh < KH; kh++) {
                            int ih = oh * SH - PH + kh;
                            for (int kw = 0; kw < KW; kw++) {
                                int iw = ow * SW - PW + kw;
                                int32_t in_v;
                                if (ih < 0 || ih >= IH || iw < 0 || iw >= IW) {
                                    in_v = input_offset;
                                } else {
                                    in_v = (int32_t)input[(in_row_base + ih) * IW + iw]
                                         + input_offset;
                                }

#if defined(MODELBLASTER_GEMMINI_HWIO_WEIGHTS) || defined(MODELBLASTER_RVV_IHWOC_WEIGHTS)
                                int32_t w_v = (int32_t)weight[((kh*KW + kw)*IC + ic)*OC + oc]
                                            + filter_offset;
#else
                                int32_t w_v = (int32_t)weight[((oc*IC + ic)*KH + kh)*KW + kw]
                                            + filter_offset;
#endif
                                acc += in_v * w_v;
                            }
                        }
                    }
                    int64_t prod = (int64_t)acc * (int64_t)output_multiplier;
                    prod = (prod + (1LL << 30)) >> 31;
                    int32_t scaled = (int32_t)prod;
                    if (output_shift > 0) {
                        scaled = (int32_t)(((int64_t)scaled + ((int64_t)1 << (output_shift - 1))) >> output_shift);
                    } else if (output_shift < 0) {
                        scaled = scaled << (-output_shift);
                    }
                    scaled += output_offset;
                    if (scaled < activation_min) scaled = activation_min;
                    if (scaled > activation_max) scaled = activation_max;
                    output[((n*OC + oc)*OH + oh)*OW + ow] = (int8_t)scaled;
                }
            }
        }
    }
}
""",
        ),
        AlgorithmCandidate(
            name="rvv_widening_oc",
            target_affinity=("rvv", "rvv_f16"),
            weight_layout="ihwoc",
            description=(
                "Vectorize over OUTPUT CHANNELS using RVV's widening "
                "integer intrinsics — the int8 analogue of the XNNPACK "
                "f32 OC-broadcast pattern (this same shape was the 16x "
                "win on fp32 conv2d). Stay in plain int across the "
                "accumulation hot path; only convert to fp32 for the "
                "requantize tail.\n\n"
                "WHY THIS HELPS:\n"
                "  Each i8 MAC, when written scalar, is 6+ instructions "
                "(load, sign-extend twice, add offsets, multiply, add). "
                "The widening-multiply path collapses i8xi8 -> i16 to "
                "one vwmul.vv that produces a vector of i16 partial "
                "products, and vwadd.wv folds that into an i32 vector "
                "accumulator. With LMUL=2 on i32 (so VLEN-bytes worth "
                "of accumulators in one register group), one inner "
                "iteration replaces a scalar inner iteration's worth of "
                "OC outputs.\n\n"
                "DATA LAYOUT (unchanged from input/output of "
                "kernel_conv2d_s8):\n"
                "  input:  int8 [N, IC, IH, IW]\n"
                "  weight: int8 [OC, IC, KH, KW]\n"
                "  output: int8 [N, OC, OH, OW]\n\n"
                "ALGORITHM (for each (n, oh, ow) — outer 3 loops "
                "scalar, oc loop is the vectorized one):\n"
                "  for oc_base in [0, OC) step vl:\n"
                "      vl = vsetvl_e32m2(OC - oc_base);\n"
                "      // bias[oc_base..oc_base+vl] -> i32 vector acc\n"
                "      vint32m2_t vacc;\n"
                "      if (bias) vacc = __riscv_vle32_v_i32m2(\n"
                "          bias + oc_base, vl);\n"
                "      else      vacc = __riscv_vmv_v_x_i32m2(0, vl);\n"
                "      for ic, kh, kw with bounds-checked ih/iw:\n"
                "          int8_t in_byte =\n"
                "              (in-bounds) ? input[((n*IC+ic)*IH+ih)*IW+iw]\n"
                "                          : 0;\n"
                "          int32_t in_v = (int32_t)in_byte + input_offset;\n"
                "          // Strided load of OC weight bytes. Stride =\n"
                "          // IC*KH*KW (bytes) since weight is OIHW.\n"
                "          vint8m1_t vw8 = __riscv_vlse8_v_i8m1(\n"
                "              weight + (oc_base*IC*KH*KW)\n"
                "                     + (ic*KH + kh)*KW + kw,\n"
                "              (ptrdiff_t)IC*KH*KW, vl);\n"
                "          // Widen i8 -> i16 and add filter_offset.\n"
                "          vint16m2_t vw16 = __riscv_vwadd_vx_i16m2(\n"
                "              vw8, filter_offset, vl);\n"
                "          // Widen-multiply by the input scalar:\n"
                "          // vwmul.vx i32 = i16 * scalar (sign-ext).\n"
                "          // We have vacc (i32) += vw16 * in_v\n"
                "          // implemented as widening-multiply-accumulate:\n"
                "          vacc = __riscv_vwmacc_vx_i32m2(\n"
                "              vacc, (int16_t)in_v, vw16, vl);\n"
                "      }}}\n"
                "      // Q0.31 requantize tail. Keep this in scalar i32 "
                "math (matches the reference bit-exactly). Pull each "
                "lane out, requantize, store.\n"
                "      int32_t accs[vl_max];\n"
                "      __riscv_vse32_v_i32m2(accs, vacc, vl);\n"
                "      for j in [0, vl):\n"
                "          int32_t acc = accs[j];\n"
                "          int64_t prod = (int64_t)acc * output_multiplier;\n"
                "          prod = (prod + (1LL<<30)) >> 31;\n"
                "          int32_t s = (int32_t)prod;\n"
                "          if (output_shift > 0)\n"
                "              s = (int32_t)(((int64_t)s + ((int64_t)1 << (output_shift-1))) >> output_shift);\n"
                "          else if (output_shift < 0)\n"
                "              s <<= -output_shift;\n"
                "          s += output_offset;\n"
                "          if (s < activation_min) s = activation_min;\n"
                "          if (s > activation_max) s = activation_max;\n"
                "          output[((n*OC + oc_base + j)*OH + oh)*OW + ow]\n"
                "              = (int8_t)s;\n\n"
                "INTRINSIC NAMES (RVV V1.0, exact spellings):\n"
                "  __riscv_vsetvl_e32m2(size_t avl) -> size_t\n"
                "  __riscv_vle32_v_i32m2(const int32_t*, size_t)\n"
                "  __riscv_vmv_v_x_i32m2(int32_t, size_t)\n"
                "  __riscv_vlse8_v_i8m1(const int8_t*, ptrdiff_t bstride, size_t)\n"
                "  __riscv_vwadd_vx_i16m2(vint8m1_t, int16_t, size_t)\n"
                "  __riscv_vwmacc_vx_i32m2(vint32m2_t, int16_t, vint16m2_t, size_t)\n"
                "  __riscv_vse32_v_i32m2(int32_t*, vint32m2_t, size_t)\n\n"
                "DO NOT use any vfXXX (fp) intrinsics — the requantize "
                "must be Q0.31 fixed-point exactly (the verify oracle "
                "checks bit-equal to the scalar reference).\n"
                "DO NOT vectorize across (ic, kh, kw) — they're a "
                "reduction; the vector dim is OC. The strided weight "
                "load is what feeds OC-many filter elements per inner "
                "iteration; do not flatten OIHW into a contiguous read.\n"
                "DO handle the boundary case where vl_max may be < OC "
                "(loop on oc_base += vl).\n"
                "DO put the bounds check (ih, iw padding) outside the "
                "vector op — the in/out of bounds decision is on the "
                "scalar input pixel, not on the OC fan-out."
            ),
            reference_impl="""\
void kernel_conv2d_s8(const int8_t *input, const int8_t *weight,
                      const int32_t *bias, int8_t *output,
                      int N, int IC, int IH, int IW, int OC,
                      int KH, int KW, int SH, int SW, int PH, int PW,
                      int input_offset, int filter_offset, int output_offset,
                      int output_multiplier, int output_shift,
                      int activation_min, int activation_max) {
    /* OC-vectorized i8 conv, RVV V1.0.
     *
     * LMUL choice: i32 acc at LMUL=2 means we need i16 ops at LMUL=1
     * and i8 ops at LMUL=1/2 (fractional) to stay element-count-matched
     * across widening intrinsics. vsetvl_e32m2(remaining_OC) gives one
     * vl that's reused for the i8 strided load (vlse8_v_i8mf2), the
     * widening offset add (vwadd_vx_i16m1), and the widening MAC
     * (vwmacc_vx_i32m2). VLEN=128 -> vlmax for e32m2 == 8 OC elems per
     * chunk. */
    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;

    for (int n = 0; n < N; n++) {
        for (int oh = 0; oh < OH; oh++) {
            for (int ow = 0; ow < OW; ow++) {
                int oc_base = 0;
                while (oc_base < OC) {
                    size_t vl = __riscv_vsetvl_e32m2((size_t)(OC - oc_base));
                    vint32m2_t vacc;
                    if (bias != NULL) {
                        vacc = __riscv_vle32_v_i32m2(bias + oc_base, vl);
                    } else {
                        vacc = __riscv_vmv_v_x_i32m2(0, vl);
                    }
                    for (int ic = 0; ic < IC; ic++) {
                        /* size_t hoist — see CONV2D_S8 spec.reference_impl
                         * for the full rationale. */
                        const size_t in_row_base =
                            ((size_t)n * IC + ic) * IH;
                        for (int kh = 0; kh < KH; kh++) {
                            int ih = oh * SH - PH + kh;
                            int row_in_bounds = (ih >= 0 && ih < IH);
                            for (int kw = 0; kw < KW; kw++) {
                                int iw = ow * SW - PW + kw;
                                int8_t in_byte = 0;
                                if (row_in_bounds && iw >= 0 && iw < IW) {
                                    in_byte = input[(in_row_base + ih) * IW + iw];
                                }
                                int32_t in_v = (int32_t)in_byte + input_offset;

                                /* IHWOC: weight[ic][kh][kw][oc] — OC contiguous */
                                const int8_t *wp = weight
                                    + ((size_t)ic * KH * KW + (size_t)kh * KW + kw) * OC
                                    + oc_base;
                                vint8mf2_t vw8 = __riscv_vle8_v_i8mf2(wp, vl);
                                vint16m1_t vw16 = __riscv_vwadd_vx_i16m1(
                                    vw8, (int16_t)filter_offset, vl);
                                vacc = __riscv_vwmacc_vx_i32m2(
                                    vacc, (int16_t)in_v, vw16, vl);
                            }
                        }
                    }
                    /* Pull lanes out and run the Q0.31 requantize
                     * scalar — bit-exact match to the reference. */
                    int32_t lane[64];   /* vlmax for e32m2 at VLEN=512 is 32; 64 is generous */
                    __riscv_vse32_v_i32m2(lane, vacc, vl);
                    for (size_t j = 0; j < vl; j++) {
                        int32_t acc = lane[j];
                        int64_t prod = (int64_t)acc * (int64_t)output_multiplier;
                        prod = (prod + (1LL << 30)) >> 31;
                        int32_t scaled = (int32_t)prod;
                        if (output_shift > 0) {
                            scaled = (int32_t)(((int64_t)scaled + ((int64_t)1 << (output_shift - 1))) >> output_shift);
                        } else if (output_shift < 0) {
                            scaled = scaled << (-output_shift);
                        }
                        scaled += output_offset;
                        if (scaled < activation_min) scaled = activation_min;
                        if (scaled > activation_max) scaled = activation_max;
                        output[((n*OC + oc_base + (int)j)*OH + oh)*OW + ow] =
                            (int8_t)scaled;
                    }
                    oc_base += (int)vl;
                }
            }
        }
    }
}
""",
        ),
        AlgorithmCandidate(
            name="rvv_vsmul_vnclip",
            target_affinity=("rvv", "rvv_f16"),
            weight_layout="ihwoc",
            description=(
                "Pure-integer RVV conv2d_s8 using vsmul (Q0.31 multiply) "
                "+ vnclip (shift + saturating narrow) for the entire "
                "requantize tail. Zero FP instructions — runs on Zve32x "
                "profile (pure-int vector cores, no F/D extension).\n\n"
                "LMUL PLAN (element counts match across all types):\n"
                "  i32m4  — accumulator.  VLMAX = 4*VLEN/32\n"
                "  i16m2  — requant intermediate.  VLMAX = 2*VLEN/16 = same\n"
                "  i8m1   — weight bytes / final output.  VLMAX = VLEN/8 = same\n"
                "VLEN=256 → 32 OC/iter; VLEN=128 → 16 OC/iter (2x more "
                "than LMUL=2 rvv_widening_oc).\n\n"
                "INNER LOOP (identical to rvv_widening_oc up to the "
                "requantize block):\n"
                "  vsetvl_e32m4(OC - oc_base) → vl\n"
                "  load/init bias into vint32m4_t vacc\n"
                "  for ic, kh, kw:\n"
                "      in_v = input[...] + input_offset   (scalar i32)\n"
                "      vw8  = vlse8_v_i8m1(wp, oc_stride, vl)\n"
                "      vw16 = vwadd_vx_i16m2(vw8, filter_offset, vl)\n"
                "      vacc = vwmacc_vx_i32m4(vacc, in_v, vw16, vl)\n\n"
                "REQUANTIZE (pure-integer, no scalar fallback):\n"
                "  // Step 1: Q0.31 multiply — equivalent to\n"
                "  //         (acc * output_multiplier + 2^30) >> 31\n"
                "  vscaled = vsmul_vx_i32m4(vacc, output_multiplier,\n"
                "                           RISCV_VXRM_RNU, vl)\n"
                "  // Step 2: right-shift and saturating narrow i32→i16\n"
                "  if output_shift < 0:\n"
                "      vshifted = vsll_vx_i32m4(vscaled, -output_shift, vl)\n"
                "      vout16   = vnclip_wx_i16m2(vshifted, 0,\n"
                "                                 RISCV_VXRM_RNU, vl)\n"
                "  elif output_shift < 32:\n"
                "      vout16 = vnclip_wx_i16m2(vscaled, output_shift,\n"
                "                               RISCV_VXRM_RNU, vl)\n"
                "  else:\n"
                "      // vnclip masks shift mod 32; split large shifts.\n"
                "      sa2 = min(output_shift - 31, 31)\n"
                "      vscaled2 = vsra_vx_i32m4(vscaled, 31, vl)\n"
                "      vout16   = vnclip_wx_i16m2(vscaled2, sa2,\n"
                "                                 RISCV_VXRM_RNU, vl)\n"
                "  // Step 3: add zero-point, clamp, narrow i16→i8\n"
                "  vout16 = vadd_vx_i16m2(vout16, output_offset, vl)\n"
                "  vout16 = vmax_vx_i16m2(vout16, activation_min, vl)\n"
                "  vout16 = vmin_vx_i16m2(vout16, activation_max, vl)\n"
                "  vout8  = vnsra_wx_i8m1(vout16, 0, vl)  // already clamped\n\n"
                "OUTPUT STORE: strided (OC not contiguous in NCHW):\n"
                "  vsse8_v_i8m1(output + (n*OC+oc_base)*OH*OW + oh*OW + ow,\n"
                "               OH*OW, vout8, vl)\n\n"
                "INTRINSIC SPELLINGS (RVV V1.0):\n"
                "  __riscv_vsetvl_e32m4(avl)\n"
                "  __riscv_vle32_v_i32m4 / __riscv_vmv_v_x_i32m4\n"
                "  __riscv_vlse8_v_i8m1(ptr, bstride, vl)\n"
                "  __riscv_vwadd_vx_i16m2(vint8m1_t, int16_t, vl)\n"
                "  __riscv_vwmacc_vx_i32m4(vint32m4_t, int16_t, vint16m2_t, vl)\n"
                "  __riscv_vsmul_vx_i32m4(vint32m4_t, int32_t, vxrm, vl)\n"
                "  __riscv_vnclip_wx_i16m2(vint32m4_t, size_t shift, vxrm, vl)\n"
                "  __riscv_vsll_vx_i32m4(vint32m4_t, size_t, vl)\n"
                "  __riscv_vadd_vx_i16m2 / __riscv_vmax_vx_i16m2 / __riscv_vmin_vx_i16m2\n"
                "  __riscv_vnsra_wx_i8m1(vint16m2_t, size_t, vl)\n"
                "  __riscv_vsse8_v_i8m1(int8_t*, ptrdiff_t, vint8m1_t, vl)\n"
            ),
            reference_impl="""\
void kernel_conv2d_s8(const int8_t *input, const int8_t *weight,
                      const int32_t *bias, int8_t *output,
                      int N, int IC, int IH, int IW, int OC,
                      int KH, int KW, int SH, int SW, int PH, int PW,
                      int input_offset, int filter_offset, int output_offset,
                      int output_multiplier, int output_shift,
                      int activation_min, int activation_max)
{
    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;

    for (int n = 0; n < N; n++) {
        for (int oh = 0; oh < OH; oh++) {
            for (int ow = 0; ow < OW; ow++) {
                int oc_base = 0;
                while (oc_base < OC) {
                    size_t vl = __riscv_vsetvl_e32m4((size_t)(OC - oc_base));
                    vint32m4_t vacc;
                    if (bias != NULL)
                        vacc = __riscv_vle32_v_i32m4(bias + oc_base, vl);
                    else
                        vacc = __riscv_vmv_v_x_i32m4(0, vl);
                    for (int ic = 0; ic < IC; ic++) {
                        const size_t in_row_base =
                            ((size_t)n * IC + ic) * IH;
                        for (int kh = 0; kh < KH; kh++) {
                            int ih = oh * SH - PH + kh;
                            int row_in = (ih >= 0 && ih < IH);
                            for (int kw = 0; kw < KW; kw++) {
                                int iw = ow * SW - PW + kw;
                                int8_t in_byte = 0;
                                if (row_in && iw >= 0 && iw < IW)
                                    in_byte = input[(in_row_base + ih) * IW + iw];
                                int32_t in_v = (int32_t)in_byte + input_offset;
                                /* IHWOC: weight[ic][kh][kw][oc] — OC contiguous */
                                const int8_t *wp = weight
                                    + ((size_t)ic * KH * KW + (size_t)kh * KW + kw) * OC
                                    + oc_base;
                                vint8m1_t vw8 = __riscv_vle8_v_i8m1(wp, vl);
                                vint16m2_t vw16 = __riscv_vwadd_vx_i16m2(
                                    vw8, (int16_t)filter_offset, vl);
                                vacc = __riscv_vwmacc_vx_i32m4(
                                    vacc, (int16_t)in_v, vw16, vl);
                            }
                        }
                    }
                    vint32m4_t vscaled = __riscv_vsmul_vx_i32m4(
                        vacc, output_multiplier, __RISCV_VXRM_RNU, vl);
                    vint16m2_t vout16;
                    if (output_shift >= 0) {
                        vout16 = __riscv_vnclip_wx_i16m2(
                            vscaled, (size_t)output_shift, __RISCV_VXRM_RNU, vl);
                    } else {
                        vint32m4_t vshifted = __riscv_vsll_vx_i32m4(
                            vscaled, (size_t)(-output_shift), vl);
                        vout16 = __riscv_vnclip_wx_i16m2(
                            vshifted, 0, __RISCV_VXRM_RNU, vl);
                    }
                    vout16 = __riscv_vadd_vx_i16m2(vout16, (int16_t)output_offset, vl);
                    vout16 = __riscv_vmax_vx_i16m2(vout16, (int16_t)activation_min, vl);
                    vout16 = __riscv_vmin_vx_i16m2(vout16, (int16_t)activation_max, vl);
                    vint8m1_t vout8 = __riscv_vnsra_wx_i8m1(vout16, 0, vl);
                    /* Output is NCHW — OC elements are OH*OW apart (strided).
                     * Scatter via contiguous vse8 into temp + scalar copy to
                     * avoid vsse8 (Saturn strided-store hardware bug). */
                    int8_t *op = output
                        + ((size_t)n * OC + oc_base) * OH * OW
                        + (size_t)oh * OW + ow;
                    int8_t _obuf[256];
                    __riscv_vse8_v_i8m1(_obuf, vout8, vl);
                    for (size_t _vi = 0; _vi < vl; _vi++)
                        op[_vi * (ptrdiff_t)(OH * OW)] = _obuf[_vi];
                    oc_base += (int)vl;
                }
            }
        }
    }
}
""",
        ),
        AlgorithmCandidate(
            name="rvv_oc_blocked",
            target_affinity=("rvv", "rvv_f16"),
            weight_layout="ihwoc",
            description=(
                "Cache-aware variant of rvv_vsmul_vnclip. Same inner "
                "vector reduction (vsmul + vnclip Q0.31 requantize, "
                "contiguous OC weight load via vle8 from IHWOC layout) "
                "but the OC dimension is tiled at the outermost level "
                "so a TILE_OC slab of weights stays resident in L1D across the entire "
                "(n, oh, ow) spatial sweep before moving to the next "
                "tile.\n\n"
                "Tile-size selection (runtime):\n"
                "  TILE_OC = 24 KB / (IC*KH*KW)\n"
                "  rounded down to a multiple of vlmax_e32m4 (= 32 on VLEN=256)\n"
                "  clamped to [vlmax_e32m4, OC]\n"
                "Falls back to TILE_OC=vlmax (one inner pass) when "
                "IC*KH*KW alone exceeds the L1D budget — degrades "
                "cleanly to the un-blocked behavior.\n\n"
                "Reuse improvement: weight LLC traffic drops from "
                "OH*OW*OC*IC*KH*KW (un-blocked) to OC*IC*KH*KW (blocked) "
                "— for the dronet 3x3 IC=128 OC=128 layer, ~16x less "
                "weight traffic. Spike doesn't reward this rewrite "
                "(no cache modeling); FireSim does."
            ),
            reference_impl="""\
void kernel_conv2d_s8(const int8_t *input, const int8_t *weight,
                      const int32_t *bias, int8_t *output,
                      int N, int IC, int IH, int IW, int OC,
                      int KH, int KW, int SH, int SW, int PH, int PW,
                      int input_offset, int filter_offset, int output_offset,
                      int output_multiplier, int output_shift,
                      int activation_min, int activation_max)
{
    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;
    const ptrdiff_t oc_stride = (ptrdiff_t)IC * KH * KW;

    enum { L1D_OC_BUDGET_BYTES = 24 * 1024 };
    const int vlmax_oc = (int)__riscv_vsetvlmax_e32m4();
    const int oc_slab_bytes = (int)oc_stride;
    int TILE_OC;
    if (oc_slab_bytes > 0 && oc_slab_bytes <= L1D_OC_BUDGET_BYTES) {
        TILE_OC = L1D_OC_BUDGET_BYTES / oc_slab_bytes;
        if (TILE_OC > vlmax_oc)
            TILE_OC = (TILE_OC / vlmax_oc) * vlmax_oc;
        else
            TILE_OC = vlmax_oc;
    } else {
        TILE_OC = vlmax_oc;
    }
    if (TILE_OC > OC) TILE_OC = OC;
    if (TILE_OC <= 0) TILE_OC = OC;

    for (int oc_outer = 0; oc_outer < OC; oc_outer += TILE_OC) {
        int oc_end = oc_outer + TILE_OC;
        if (oc_end > OC) oc_end = OC;
        for (int n = 0; n < N; n++) {
            for (int oh = 0; oh < OH; oh++) {
                for (int ow = 0; ow < OW; ow++) {
                    int oc_base = oc_outer;
                    while (oc_base < oc_end) {
                        size_t vl = __riscv_vsetvl_e32m4(
                            (size_t)(oc_end - oc_base));
                        vint32m4_t vacc;
                        if (bias != NULL)
                            vacc = __riscv_vle32_v_i32m4(bias + oc_base, vl);
                        else
                            vacc = __riscv_vmv_v_x_i32m4(0, vl);
                        for (int ic = 0; ic < IC; ic++) {
                            /* size_t hoist — see CONV2D_S8 spec.reference_impl. */
                            const size_t in_row_base =
                                ((size_t)n * IC + ic) * IH;
                            for (int kh = 0; kh < KH; kh++) {
                                int ih = oh * SH - PH + kh;
                                int row_in = (ih >= 0 && ih < IH);
                                for (int kw = 0; kw < KW; kw++) {
                                    int iw = ow * SW - PW + kw;
                                    int8_t in_byte = 0;
                                    if (row_in && iw >= 0 && iw < IW)
                                        in_byte = input[(in_row_base + ih) * IW + iw];
                                    int32_t in_v = (int32_t)in_byte + input_offset;

                                    /* IHWOC: weight[ic][kh][kw][oc] — OC contiguous */
                                    const int8_t *wp = weight
                                        + ((size_t)ic * KH * KW + (size_t)kh * KW + kw) * OC
                                        + oc_base;
                                    vint8m1_t vw8 = __riscv_vle8_v_i8m1(wp, vl);
                                    vint16m2_t vw16 = __riscv_vwadd_vx_i16m2(
                                        vw8, (int16_t)filter_offset, vl);
                                    vacc = __riscv_vwmacc_vx_i32m4(
                                        vacc, (int16_t)in_v, vw16, vl);
                                }
                            }
                        }
                        vint32m4_t vscaled = __riscv_vsmul_vx_i32m4(
                            vacc, output_multiplier, __RISCV_VXRM_RNU, vl);
                        vint16m2_t vout16;
                        if (output_shift < 0) {
                            vint32m4_t vshifted = __riscv_vsll_vx_i32m4(
                                vscaled, (size_t)(-output_shift), vl);
                            vout16 = __riscv_vnclip_wx_i16m2(
                                vshifted, 0, __RISCV_VXRM_RNU, vl);
                        } else if (output_shift < 32) {
                            vout16 = __riscv_vnclip_wx_i16m2(
                                vscaled, (size_t)output_shift, __RISCV_VXRM_RNU, vl);
                        } else {
                            int sa2 = output_shift - 31;
                            if (sa2 > 31) sa2 = 31;
                            vint32m4_t vscaled2 = __riscv_vsra_vx_i32m4(vscaled, 31, vl);
                            vout16 = __riscv_vnclip_wx_i16m2(
                                vscaled2, (size_t)sa2, __RISCV_VXRM_RNU, vl);
                        }
                        vout16 = __riscv_vadd_vx_i16m2(vout16, (int16_t)output_offset, vl);
                        vout16 = __riscv_vmax_vx_i16m2(vout16, (int16_t)activation_min, vl);
                        vout16 = __riscv_vmin_vx_i16m2(vout16, (int16_t)activation_max, vl);
                        vint8m1_t vout8 = __riscv_vnsra_wx_i8m1(vout16, 0, vl);
                        int8_t *op = output
                            + ((size_t)n * OC + oc_base) * OH * OW
                            + (size_t)oh * OW + ow;
                        int8_t _obuf[256];
                        __riscv_vse8_v_i8m1(_obuf, vout8, vl);
                        for (size_t _vi = 0; _vi < vl; _vi++)
                            op[_vi * (ptrdiff_t)(OH * OW)] = _obuf[_vi];
                        oc_base += (int)vl;
                    }
                }
            }
        }
    }
}
""",
        ),
        AlgorithmCandidate(
            name="gemmini_tiled_conv",
            target_affinity=("gemmini", "gemmini_q31"),
            weight_layout="hwio",
            # HW im2col + GEMM + mvout-requantize. Float-scale on Saturn /
            # Q0.31-fold on Q31 bitstream — both single-stage requantize, drift
            # ≤1 LSB / layer vs the TFLite two-stage golden. Fast on RTL but
            # not bit-exact for deep nets.
            accuracy_class=AccuracyClass.NUMERIC_DRIFT,
            description=(
                "Route the conv through the Gemmini int8 systolic mesh "
                "via gemmini.h's tiled_conv_auto. Gemmini handles "
                "im2col + GEMM + requantize internally; we transpose "
                "NCHW→NHWC inputs and OIHW→OHWI weights into static "
                "scratch buffers (gemmini's required layout), call "
                "tiled_conv_auto, and transpose the output back.\n\n"
                "Stage-1 limitations:\n"
                "  * Square kernel/stride/padding only (KH==KW, SH==SW, "
                "    PH==PW). Asserts otherwise.\n"
                "  * input_offset / filter_offset / output_offset must "
                "    all be 0 (symmetric quant; matches our extract_int8 "
                "    output). The implementation rejects non-zero offsets "
                "    by falling back to no-op (caller falls back).\n"
                "  * Requantize is float-scale (gemmini's mvout-with-scale, "
                "    derived from output_multiplier/output_shift via "
                "    ldexpf) — accepts ~1-3 LSB drift vs the Q0.31 "
                "    PyTorch golden. See modelblaster/notes/gemmini_extension_"
                "    plan.md 'Requantize tail' section.\n"
                "  * activation_min == 0 enables gemmini's RELU; "
                "    activation_max is implicit (int8 saturate inside "
                "    mvout). Other activation ranges fall back to a "
                "    post-call clamp.\n"
                "  * Static workspaces sized 128 KB each for input / "
                "    weight / output buffers — fits dronet's largest "
                "    conv (32×56×56). Larger models would need bigger "
                "    workspaces or codegen-driven sizing."
            ),
            reference_impl="""\
void kernel_conv2d_s8(const int8_t *input, const int8_t *weight,
                      const int32_t *bias, int8_t *output,
                      int N, int IC, int IH, int IW, int OC,
                      int KH, int KW, int SH, int SW, int PH, int PW,
                      int input_offset, int filter_offset, int output_offset,
                      int output_multiplier, int output_shift,
                      int activation_min, int activation_max) {
    /* Static workspaces (function-scope so the cache validator's
     * signature check sees the function definition first). 128 KB each
     * fits dronet's largest int8 conv (32*56*56 = 100352 bytes activations;
     * 128*64*3*3 = 73728 bytes weights) with margin. .bss-allocated. */
    enum { GEMMINI_WS_BYTES = 128 * 1024 };
    static elem_t  ws_input  [GEMMINI_WS_BYTES] __attribute__((aligned(64)));
    static elem_t  ws_weight [GEMMINI_WS_BYTES] __attribute__((aligned(64)));
    static elem_t  ws_output [GEMMINI_WS_BYTES] __attribute__((aligned(64)));

    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;

    /* Stage-1 constraints. Symmetric per-tensor quant (offsets all 0)
     * matches what extract_int8 emits today. tiled_conv_auto wants
     * one int for kernel_dim/stride/padding — square only. */
    if (KH != KW || SH != SW || PH != PW
            || input_offset != 0 || filter_offset != 0
            || output_offset != 0
            || (size_t)(N*IH*IW*IC) > GEMMINI_WS_BYTES
            || (size_t)(OC*KH*KW*IC) > GEMMINI_WS_BYTES
            || (size_t)(N*OH*OW*OC) > GEMMINI_WS_BYTES) {
        /* Fallback: scalar reference impl. Same bit-exact behavior as
         * the 'direct' algorithm; included verbatim so this kernel is
         * self-contained even when the gemmini path can't be used. */
        for (int n = 0; n < N; n++) {
            for (int oc = 0; oc < OC; oc++) {
                for (int oh = 0; oh < OH; oh++) {
                    for (int ow = 0; ow < OW; ow++) {
                        int32_t acc = bias ? bias[oc] : 0;
                        for (int ic = 0; ic < IC; ic++) {
                            for (int kh = 0; kh < KH; kh++) {
                                int ih = oh*SH - PH + kh;
                                for (int kw = 0; kw < KW; kw++) {
                                    int iw = ow*SW - PW + kw;
                                    int32_t in_v;
                                    if (ih < 0 || ih >= IH || iw < 0 || iw >= IW) {
                                        in_v = input_offset;
                                    } else {
                                        in_v = (int32_t)input[((n*IC+ic)*IH+ih)*IW+iw]
                                             + input_offset;
                                    }
                                    int32_t w_v = (int32_t)weight[((oc*IC+ic)*KH+kh)*KW+kw]
                                                + filter_offset;
                                    acc += in_v * w_v;
                                }
                            }
                        }
                        int64_t prod = (int64_t)acc * (int64_t)output_multiplier;
                        prod = (prod + (1LL << 30)) >> 31;
                        int32_t scaled = (int32_t)prod;
                        if (output_shift > 0) {
                            scaled = (int32_t)(((int64_t)scaled + ((int64_t)1 << (output_shift - 1))) >> output_shift);
                        } else if (output_shift < 0) {
                            scaled = scaled << (-output_shift);
                        }
                        scaled += output_offset;
                        if (scaled < activation_min) scaled = activation_min;
                        if (scaled > activation_max) scaled = activation_max;
                        output[((n*OC+oc)*OH+oh)*OW+ow] = (int8_t)scaled;
                    }
                }
            }
        }
        return;
    }

    /* Enable mstatus.XS so RoCC custom-3 instructions don't trap as
     * illegal. Zephyr's reset.S enables FS and VS but leaves XS=Off.
     * The bareMetalC RVTEST_XS_ENABLE macro writes XS=Initial (0x8000)
     * which works on functional spike + libgemmini. On real Rocket+
     * Saturn-Gemmini RTL we need XS=Dirty (0x18000) — Initial alone
     * still traps custom-3 (likely the RTL's enable signal AND-gates
     * both XS bits, requiring 0b11). */
    asm volatile("csrs mstatus, %0" : : "r"(0x18000) : "memory");

    /* gemmini_flush(0) puts the accelerator in a known state. Idempotent;
     * the bareMetalC reference tests call this once at boot, but here we
     * call it per-kernel since kernels.c has no other init hook. */
    gemmini_flush(0);

    /* NCHW -> NHWC transpose. Input shape: [N, IC, IH, IW] -> [N, IH, IW, IC]. */
    for (int n = 0; n < N; n++) {
        for (int h = 0; h < IH; h++) {
            for (int w = 0; w < IW; w++) {
                for (int c = 0; c < IC; c++) {
                    ws_input[((n*IH + h)*IW + w)*IC + c] =
                        input[((n*IC + c)*IH + h)*IW + w];
                }
            }
        }
    }

    /* OIHW -> patch-major (KH*KW*IC) x OC. tiled_conv_auto reads
     * weights as a flattened [K*K*IC, OC] matrix — see
     * gemmini-rocc-tests' bareMetalC/conv.c flatten_weights() — NOT
     * the OHWI [OC, KH, KW, IC] layout the input uses. Getting this
     * wrong silently gives ~random output (max_abs_err ≈ 130 even
     * with ACC_SCALE_IDENTITY); ws_weight rows must be (kh,kw,ic) in
     * patch order, columns are oc. */
    for (int oc = 0; oc < OC; oc++) {
        for (int kh = 0; kh < KH; kh++) {
            for (int kw = 0; kw < KW; kw++) {
                for (int ic = 0; ic < IC; ic++) {
                    ws_weight[((kh*KW + kw)*IC + ic)*OC + oc] =
                        weight[((oc*IC + ic)*KH + kh)*KW + kw];
                }
            }
        }
    }

    /* Q0.31 multiplier+shift -> float scale.
     * effective_scale = output_multiplier / 2^31 / 2^output_shift
     *                 = output_multiplier * 2^(-(31 + output_shift))
     * ldexpf handles either sign of (31 + output_shift). */
    float scale = ldexpf((float)output_multiplier, -(31 + output_shift));

    /* Activation enum. RELU (1) clamps the float-scaled output to [0,
     * INT8_MAX]; NO_ACTIVATION (0) lets it use the full int8 range. We
     * map activation_min == 0 to RELU. activation_max == INT8_MAX is
     * implicit either way (gemmini saturates on int8 cast). */
    int act_kind = (activation_min == 0) ? 1 /*RELU*/ : 0 /*NO_ACTIVATION*/;

    /* Drain the CPU store buffer before gemmini's DMA reads ws_input /
     * ws_weight. On spike (functional sim) stores are immediately visible;
     * on real Rocket silicon the store buffer races the DMA load and can
     * feed stale data. The RISC-V fence with "memory" clobber (a) tells
     * the compiler the preceding stores are architectural, and (b) stalls
     * the Rocket pipeline until the store buffer empties into L2, at which
     * point gemmini's mvin sees the correct values. */
    asm volatile ("fence" ::: "memory");

    /* tiled_conv_auto: gemmini does im2col + GEMM + requantize
     * internally. WS = weight-stationary dataflow (the canonical
     * choice for inference). */
    tiled_conv_auto(
        N, IH, IW, IC,
        OC, OH, OW,
        SH, 1, 1, PH, KH,
        false, false, false, false, false,
        ws_input, ws_weight, bias, ws_output,
        act_kind, scale,
        0, 0, 0,
        WS
    );

    /* tiled_conv_auto's body (tiled_conv) does NOT end with a
     * gemmini_fence — unlike tiled_matmul_outer_eigen, which does.
     * Without an explicit drain, the post-conv NHWC->NCHW read and
     * the next op's gemmini_flush race with in-flight mvout DMAs
     * and corrupt memory near the stack (FireSim Saturn signature:
     * mcause=1, mepc=0).  gemmini_fence() blocks until the
     * reservation station has retired all queued ld/ex/st ops,
     * which transitively means all mvout DMAs have committed. */
    gemmini_fence();
    gemmini_flush(0);

    /* NHWC -> NCHW transpose for the output. */
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < OC; c++) {
            for (int h = 0; h < OH; h++) {
                for (int w = 0; w < OW; w++) {
                    output[((n*OC + c)*OH + h)*OW + w] =
                        ws_output[((n*OH + h)*OW + w)*OC + c];
                }
            }
        }
    }

    /* Optional post-clamp. activation_min == 0 was already handled by
     * gemmini's RELU; activation_max < INT8_MAX needs a manual pass. */
    if (activation_max < 127) {
        int n_out = N*OC*OH*OW;
        for (int i = 0; i < n_out; i++) {
            int v = output[i];
            if (v > activation_max) v = activation_max;
            output[i] = (int8_t)v;
        }
    }
}
""",
        ),
        AlgorithmCandidate(
            name="gemmini_im2col_full_C",
            target_affinity=("gemmini", "gemmini_q31"),
            weight_layout="hwio",
            # CPU im2col + tiled_matmul_auto(full_C=true) raw int32 mvout +
            # scalar two-stage Q0.31 requantize on the host. Matches the
            # TFLite/modelblaster reference math element-for-element.
            accuracy_class=AccuracyClass.BIT_EXACT,
            description=(
                "im2col + tiled_matmul_auto(full_C=true) + scalar Q0.31 "
                "requantize. Bypasses Saturn-Gemmini's float-scale mvout "
                "to get bit-exact results matching the Q0.31 PyTorch golden "
                "(max_abs_err=0 on Saturn RTL FireSim, validated May 2026).\n\n"
                "Algorithm stages:\n"
                "  1. Transpose input NCHW→NHWC into ws_input.\n"
                "  2. Transpose weights OIHW→[K_inner, OC] patch-major into "
                "     ws_weight (same layout as tiled_conv_auto expects).\n"
                "  3. For each DIM-row tile of output positions:\n"
                "     a. Build im2col A-matrix: DIM rows × K_inner cols from "
                "        ws_input (zero-pad OOB; zero-fill rows beyond tile).\n"
                "     b. tiled_matmul_auto(DIM, OC, K_inner, A=ws_im2col, "
                "        B=ws_weight, D=bias, C=ws_acc_out, full_C=true) "
                "        → int32 raw accumulators in ws_acc_out.\n"
                "     c. gemmini_flush(0) to wait for DMA writes to ws_acc_out.\n"
                "     d. Scalar Q0.31 requantize: "
                "        (acc * output_multiplier + 1<<30) >> 31; "
                "        >> output_shift; + output_offset; clamp.\n"
                "  4. Transpose output NHWC→NCHW.\n\n"
                "Key parameters:\n"
                "  ws_im2col: DIM × IC*KH*KW (up to 16×128×9=18432 bytes).\n"
                "  ws_acc_out: DIM × OC as acc_t (int32); 16×128×4=8192 bytes.\n"
                "  full_C=true encodes as bit 1 of rs1 in gemmini_loop_ws; "
                "  ACC_READ_FULL_WIDTH must be set in gemmini_params.h (it is).\n"
                "  repeating_bias=true broadcasts bias[OC] to all DIM rows.\n\n"
                "Scalar fallback (return after scalar path) for:\n"
                "  input_offset != 0, filter_offset != 0, or buffer overflow.\n\n"
                "Performance note: per-tile gemmini_flush dominates for "
                "small-spatial convs (conv_modules.0 needs 196 flush calls). "
                "conv_modules.8 (75% of dronet cycles) needs only 1. "
                "Overall ~10% slower than scalar on dronet FireSim, but "
                "bit-exact vs ~59 LSB drift on float-scale path."
            ),
            reference_impl="""\
void kernel_conv2d_s8(const int8_t *input, const int8_t *weight,
                      const int32_t *bias, int8_t *output,
                      int N, int IC, int IH, int IW, int OC,
                      int KH, int KW, int SH, int SW, int PH, int PW,
                      int input_offset, int filter_offset, int output_offset,
                      int output_multiplier, int output_shift,
                      int activation_min, int activation_max) {
    /* im2col → tiled_matmul_auto(full_C=true) → scalar Q0.31 requantize.
     *
     * Bypasses Saturn-Gemmini's float-scale mvout entirely: gemmini accumulates
     * raw int32 dot products, the CPU applies the same Q0.31 fixed-point
     * requantize as the reference kernel.  Bit-exact with the reference golden.
     *
     * Layout contract:
     *   ws_input  [N, IH, IW, IC]       — NHWC input
     *   ws_weight [KH*KW*IC, OC]        — patch-major weight (B matrix for matmul)
     *   ws_im2col [DIM, KH*KW*IC]       — one DIM-row im2col tile (A matrix)
     *   ws_acc_out[DIM, OC]             — int32 accumulator output from gemmini
     *   ws_output [N, OH, OW, OC]       — NHWC int8 output (filled tile-by-tile)
     */
    enum { GEMMINI_WS_BYTES  = 128 * 1024 };
    static elem_t ws_input  [GEMMINI_WS_BYTES] __attribute__((aligned(64)));
    static elem_t ws_weight [GEMMINI_WS_BYTES] __attribute__((aligned(64)));
    static elem_t ws_output [GEMMINI_WS_BYTES] __attribute__((aligned(64)));
    /* DIM × max(IC*KH*KW): dronet max = 16 × 128×9 = 18 432 bytes */
    enum { GEMMINI_IM2COL_ELEMS = DIM * 128 * 9 };
    static elem_t ws_im2col [GEMMINI_IM2COL_ELEMS] __attribute__((aligned(64)));
    /* DIM × max(OC): dronet max = 16 × 128 × 4 = 8 192 bytes */
    enum { GEMMINI_ACC_ELEMS = DIM * 128 };
    static acc_t  ws_acc_out[GEMMINI_ACC_ELEMS]    __attribute__((aligned(64)));

    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;
    int K_inner   = IC * KH * KW;
    int total_out = N * OH * OW;

    /* Fall back to scalar for configs that exceed workspace or need offsets. */
    if (input_offset != 0 || filter_offset != 0
            || (size_t)(N*IH*IW*IC)  > GEMMINI_WS_BYTES
            || (size_t)(K_inner*OC)  > GEMMINI_WS_BYTES
            || (size_t)(N*OH*OW*OC)  > GEMMINI_WS_BYTES
            || K_inner * DIM         > GEMMINI_IM2COL_ELEMS
            || OC * DIM              > GEMMINI_ACC_ELEMS) {
        for (int n = 0; n < N; n++) {
            for (int oc = 0; oc < OC; oc++) {
                for (int oh = 0; oh < OH; oh++) {
                    for (int ow = 0; ow < OW; ow++) {
                        int32_t acc = bias ? bias[oc] : 0;
                        for (int ic = 0; ic < IC; ic++) {
                            for (int kh = 0; kh < KH; kh++) {
                                int ih = oh * SH - PH + kh;
                                for (int kw = 0; kw < KW; kw++) {
                                    int iw = ow * SW - PW + kw;
                                    int32_t in_v;
                                    if (ih < 0 || ih >= IH || iw < 0 || iw >= IW) {
                                        in_v = input_offset;
                                    } else {
                                        in_v = (int32_t)input[((n*IC+ic)*IH+ih)*IW+iw]
                                             + input_offset;
                                    }
                                    int32_t w_v = (int32_t)weight[((oc*IC+ic)*KH+kh)*KW+kw]
                                                + filter_offset;
                                    acc += in_v * w_v;
                                }
                            }
                        }
                        int64_t prod = (int64_t)acc * (int64_t)output_multiplier;
                        prod = (prod + (1LL << 30)) >> 31;
                        int32_t scaled = (int32_t)prod;
                        if (output_shift > 0) {
                            scaled = (int32_t)(((int64_t)scaled + ((int64_t)1 << (output_shift - 1))) >> output_shift);
                        } else if (output_shift < 0) {
                            scaled = scaled << (-output_shift);
                        }
                        scaled += output_offset;
                        if (scaled < activation_min) scaled = activation_min;
                        if (scaled > activation_max) scaled = activation_max;
                        output[((n*OC+oc)*OH+oh)*OW+ow] = (int8_t)scaled;
                    }
                }
            }
        }
        return;
    }

    /* Enable mstatus.XS=Dirty so RoCC custom-3 instructions don't trap. */
    asm volatile("csrs mstatus, %0" : : "r"(0x18000) : "memory");

    /* Reset gemmini controller and drain any prior DMA. */
    gemmini_flush(0);

    /* NCHW → NHWC input transpose. */
    for (int n = 0; n < N; n++)
        for (int h = 0; h < IH; h++)
            for (int w = 0; w < IW; w++)
                for (int c = 0; c < IC; c++)
                    ws_input[((n*IH + h)*IW + w)*IC + c] =
                        input[((n*IC + c)*IH + h)*IW + w];

    /* OIHW → patch-major [K_inner, OC]: B-matrix for tiled_matmul_auto.
     * Row index = kh*KW*IC + kw*IC + ic (matching im2col column order). */
    for (int oc = 0; oc < OC; oc++)
        for (int kh = 0; kh < KH; kh++)
            for (int kw = 0; kw < KW; kw++)
                for (int ic = 0; ic < IC; ic++)
                    ws_weight[((kh*KW + kw)*IC + ic)*OC + oc] =
                        weight[((oc*IC + ic)*KH + kh)*KW + kw];

    /* Drain CPU store buffer before gemmini mvin reads ws_weight. */
    asm volatile("fence" ::: "memory");

    /* Process output in tiles of DIM rows so ws_acc_out stays bounded. */
    for (int tile_i = 0; tile_i < total_out; tile_i += DIM) {
        int tile_rows = total_out - tile_i < DIM ? total_out - tile_i : DIM;

        /* Build im2col A-matrix: DIM rows × K_inner cols.
         * Row i = flattened receptive field for output position (tile_i + i).
         * Rows beyond tile_rows are zero-padded (gemmini ignores their results). */
        for (int i = 0; i < DIM; i++) {
            elem_t *row = &ws_im2col[i * K_inner];
            if (i >= tile_rows) {
                for (int k = 0; k < K_inner; k++) row[k] = 0;
                continue;
            }
            int out_idx = tile_i + i;
            int ow_idx  = out_idx % OW;
            int oh_idx  = (out_idx / OW) % OH;
            int n_idx   = out_idx / (OH * OW);
            for (int kh = 0; kh < KH; kh++) {
                int ih = oh_idx * SH - PH + kh;
                for (int kw = 0; kw < KW; kw++) {
                    int iw = ow_idx * SW - PW + kw;
                    elem_t *cell = row + kh * KW * IC + kw * IC;
                    if (ih >= 0 && ih < IH && iw >= 0 && iw < IW) {
                        const elem_t *src = &ws_input[((n_idx*IH + ih)*IW + iw)*IC];
                        for (int c = 0; c < IC; c++) cell[c] = src[c];
                    } else {
                        for (int c = 0; c < IC; c++) cell[c] = 0;
                    }
                }
            }
        }

        /* Drain CPU stores to ws_im2col before gemmini mvin. */
        asm volatile("fence" ::: "memory");

        /* GEMM: ws_im2col [DIM × K_inner] × ws_weight [K_inner × OC] + bias[OC]
         * full_C=true → output written as raw int32 (no float-scale applied). */
        tiled_matmul_auto(
            DIM, OC, K_inner,
            ws_im2col, ws_weight,
            (const void *)bias, (void *)ws_acc_out,
            /* strides: A=K_inner, B=OC, D=OC, C=OC */
            K_inner, OC, OC, OC,
            MVIN_SCALE_IDENTITY, MVIN_SCALE_IDENTITY, (scale_acc_t)1,
            NO_ACTIVATION, ACC_SCALE_IDENTITY, (acc_scale_t)0,
            bias != NULL,   /* repeating_bias: same OC vector for every row */
            false, false,   /* no A/B transpose */
            true, false,    /* full_C=true: int32 output; low_D=false */
            0, WS
        );

        /* Wait for gemmini DMA writes to ws_acc_out to reach L2. */
        gemmini_flush(0);

        /* Scalar Q0.31 requantize: int32 accumulator → int8 NHWC. */
        for (int i = 0; i < tile_rows; i++) {
            int out_idx = tile_i + i;
            int ow_idx  = out_idx % OW;
            int oh_idx  = (out_idx / OW) % OH;
            int n_idx   = out_idx / (OH * OW);
            for (int oc = 0; oc < OC; oc++) {
                int32_t acc = ws_acc_out[i * OC + oc];
                int64_t prod = (int64_t)acc * (int64_t)output_multiplier;
                prod = (prod + (1LL << 30)) >> 31;
                int32_t scaled = (int32_t)prod;
                if (output_shift > 0) {
                    scaled = (int32_t)(((int64_t)scaled + ((int64_t)1 << (output_shift - 1))) >> output_shift);
                } else if (output_shift < 0) {
                    scaled <<= (-output_shift);
                }
                scaled += output_offset;
                if (scaled < activation_min) scaled = activation_min;
                if (scaled > activation_max) scaled = activation_max;
                ws_output[((n_idx*OH + oh_idx)*OW + ow_idx)*OC + oc] = (elem_t)scaled;
            }
        }
    }

    /* NHWC → NCHW output transpose. */
    for (int n = 0; n < N; n++)
        for (int c = 0; c < OC; c++)
            for (int h = 0; h < OH; h++)
                for (int w = 0; w < OW; w++)
                    output[((n*OC + c)*OH + h)*OW + w] =
                        ws_output[((n*OH + h)*OW + w)*OC + c];
}
""",
        ),
    ],
)


# Fused Conv2D + SiLU. Same dataflow as CONV2D_S8 plus an int8 SiLU LUT
# applied during the requantize epilogue (saves 1 dispatch + 1 cross-tile
# sync per occurrence; the int8 output tensor materializes once instead
# of twice). Detected in extract_graph.py when a Conv2d is immediately
# followed by an nn.SiLU. Curated kernels per backend can implement the
# fused requantize→LUT epilogue directly; the reference impl below
# composes the two ops in C as a fallback.
CONV2D_SILU_S8 = KernelSpec(
    op="conv2d_silu_s8",
    signature=(
        "void kernel_conv2d_silu_s8(const int8_t *input, const int8_t *weight, "
        "const int32_t *bias, int8_t *output, "
        "int N, int IC, int IH, int IW, int OC, "
        "int KH, int KW, int SH, int SW, int PH, int PW, "
        "int input_offset, int filter_offset, int output_offset, "
        "int output_multiplier, int output_shift, "
        "int activation_min, int activation_max, "
        "float silu_scale_in, float silu_scale_out)"
    ),
    semantics=(
        "Fused quantized 2D convolution + SiLU activation. Computes\n"
        "conv2d_s8(input, weight, bias) → int8 intermediate, then\n"
        "elementwise SiLU(intermediate * silu_scale_in) / silu_scale_out\n"
        "→ int8 output. activation_min / activation_max bound the final\n"
        "output. silu_scale_in is the conv's output scale (= dequant for\n"
        "the SiLU's float compute); silu_scale_out is the quantization\n"
        "scale for the SiLU result.\n"
        "Reference impl materializes the intermediate; curated kernels\n"
        "can apply the SiLU LUT inline in the conv's requantize loop."
    ),
    reference_impl="""\
#include <math.h>
void kernel_conv2d_silu_s8(const int8_t *input, const int8_t *weight,
                            const int32_t *bias, int8_t *output,
                            int N, int IC, int IH, int IW, int OC,
                            int KH, int KW, int SH, int SW, int PH, int PW,
                            int input_offset, int filter_offset, int output_offset,
                            int output_multiplier, int output_shift,
                            int activation_min, int activation_max,
                            float silu_scale_in, float silu_scale_out) {
    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;
    /* Precompute SiLU LUT: 256 entries indexed by (uint8_t)int8 value.
     * The conv intermediate is int8 (after requantize); SiLU maps each
     * to another int8 via the float-precision SiLU formula. */
    int8_t silu_lut[256];
    for (int v = 0; v < 256; v++) {
        int8_t iv = (int8_t)(uint8_t)v;
        float f = (float)iv * silu_scale_in;
        float y = f / (1.0f + expf(-f));
        int32_t q = (int32_t)roundf(y / silu_scale_out);
        if (q < activation_min) q = activation_min;
        if (q > activation_max) q = activation_max;
        silu_lut[v] = (int8_t)q;
    }
    /* Per-output-element conv with inline SiLU LUT. */
    for (int n = 0; n < N; n++) {
        for (int oc = 0; oc < OC; oc++) {
            for (int oh = 0; oh < OH; oh++) {
                for (int ow = 0; ow < OW; ow++) {
                    int32_t acc = bias ? bias[oc] : 0;
                    for (int ic = 0; ic < IC; ic++) {
                        const size_t in_row_base = ((size_t)n * IC + ic) * IH;
                        for (int kh = 0; kh < KH; kh++) {
                            int ih = oh * SH - PH + kh;
                            for (int kw = 0; kw < KW; kw++) {
                                int iw = ow * SW - PW + kw;
                                int32_t in_v = (ih < 0 || ih >= IH || iw < 0 || iw >= IW)
                                    ? input_offset
                                    : (int32_t)input[(in_row_base + ih) * IW + iw] + input_offset;
#if defined(MODELBLASTER_GEMMINI_HWIO_WEIGHTS) || defined(MODELBLASTER_RVV_IHWOC_WEIGHTS)
                                int32_t w_v = (int32_t)weight[((kh*KW + kw)*IC + ic)*OC + oc]
                                            + filter_offset;
#else
                                int32_t w_v = (int32_t)weight[((oc*IC + ic)*KH + kh)*KW + kw]
                                            + filter_offset;
#endif
                                acc += in_v * w_v;
                            }
                        }
                    }
                    /* Conv requantize → int8 intermediate (no clamp at the
                     * activation min/max yet — those belong to the SiLU
                     * output. Clamp to int8 range so the LUT index is valid). */
                    int64_t prod = (int64_t)acc * (int64_t)output_multiplier;
                    prod = (prod + (1LL << 30)) >> 31;
                    int32_t scaled = (int32_t)prod;
                    if (output_shift > 0) {
                        scaled = (int32_t)(((int64_t)scaled + ((int64_t)1 << (output_shift - 1))) >> output_shift);
                    } else if (output_shift < 0) {
                        scaled = scaled << (-output_shift);
                    }
                    scaled += output_offset;
                    if (scaled < -128) scaled = -128;
                    if (scaled > 127) scaled = 127;
                    /* SiLU LUT applied to the int8 intermediate. */
                    output[((n*OC + oc)*OH + oh)*OW + ow] =
                        silu_lut[(uint8_t)(int8_t)scaled];
                }
            }
        }
    }
}
""",
    extra_shapes=[
        # Small shape for verify; SiLU scales chosen so the LUT is non-trivial.
        {"N": 1, "IC": 3, "IH": 8, "IW": 8, "OC": 16,
         "KH": 3, "KW": 3, "SH": 1, "SW": 1, "PH": 1, "PW": 1},
    ],
    argtypes_factory=_conv2d_silu_s8_argtypes,
)


MAXPOOL2D_S8 = KernelSpec(
    op="maxpool2d_s8",
    signature=(
        "void kernel_maxpool2d_s8(const int8_t *input, int8_t *output, "
        "int N, int C, int IH, int IW, "
        "int KH, int KW, int SH, int SW, "
        "int PH, int PW, int DH, int DW)"
    ),
    semantics=(
        "Quantized 2D max-pool. Identical dataflow to fp32 maxpool2d but "
        "operating on int8 lanes. No requantize is needed — max is just a "
        "compare, and selecting an int8 input directly produces an int8 "
        "output at the same scale. Padding is filled with INT8_MIN so OOB "
        "lanes never win the max (the int8 analogue of -INF).\n"
        "Layout (NCHW):\n"
        "  input:  int8 [N, C, IH, IW]\n"
        "  output: int8 [N, C, OH, OW]  with\n"
        "    OH = (IH + 2*PH - DH*(KH-1) - 1) / SH + 1\n"
        "    OW = (IW + 2*PW - DW*(KW-1) - 1) / SW + 1\n"
        "  output[n, c, oh, ow] = max over kh in [0,KH), kw in [0,KW) of\n"
        "    val(n, c, oh*SH - PH + kh*DH, ow*SW - PW + kw*DW)\n"
        "  where val(...) returns input[n,c,ih,iw] when in bounds, else\n"
        "  INT8_MIN."
    ),
    reference_impl="""\
#include <stdint.h>

void kernel_maxpool2d_s8(const int8_t *input, int8_t *output,
                         int N, int C, int IH, int IW,
                         int KH, int KW, int SH, int SW,
                         int PH, int PW, int DH, int DW) {
    int OH = (IH + 2*PH - DH*(KH-1) - 1) / SH + 1;
    int OW = (IW + 2*PW - DW*(KW-1) - 1) / SW + 1;
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            for (int oh = 0; oh < OH; oh++) {
                for (int ow = 0; ow < OW; ow++) {
                    int8_t m = INT8_MIN;
                    for (int kh = 0; kh < KH; kh++) {
                        int ih = oh*SH - PH + kh*DH;
                        if (ih < 0 || ih >= IH) continue;
                        for (int kw = 0; kw < KW; kw++) {
                            int iw = ow*SW - PW + kw*DW;
                            if (iw < 0 || iw >= IW) continue;
                            int8_t v = input[((n*C + c)*IH + ih)*IW + iw];
                            if (v > m) m = v;
                        }
                    }
                    output[((n*C + c)*OH + oh)*OW + ow] = m;
                }
            }
        }
    }
}
""",
    extra_shapes=[
        # LeNet
        {"N": 1, "C": 6, "IH": 24, "IW": 24, "KH": 2, "KW": 2, "SH": 2, "SW": 2,
         "PH": 0, "PW": 0, "DH": 1, "DW": 1},
        {"N": 1, "C": 16, "IH": 8, "IW": 8, "KH": 2, "KW": 2, "SH": 2, "SW": 2,
         "PH": 0, "PW": 0, "DH": 1, "DW": 1},
        # DroNet
        {"N": 1, "C": 32, "IH": 64, "IW": 64, "KH": 3, "KW": 3, "SH": 2, "SW": 2,
         "PH": 0, "PW": 0, "DH": 1, "DW": 1},
        # YOLOv8 SPPF. Every shape above is SW=2/PW=0, so a kernel's
        # stride-1 and padded-boundary paths were exercised by NO model's
        # verify -- and maxpool2d_s8 is a single kernel shared by every
        # model that has the op. This shape covers both.
        {"N": 1, "C": 128, "IH": 5, "IW": 5, "KH": 5, "KW": 5, "SH": 1, "SW": 1,
         "PH": 2, "PW": 2, "DH": 1, "DW": 1},
    ],
    argtypes_factory=_maxpool2d_s8_argtypes,
    algorithms=[
        AlgorithmCandidate(
            name="gemmini_tiled_conv_pool",
            target_affinity=("gemmini", "gemmini_q31"),
            accuracy_class=AccuracyClass.BIT_EXACT,
            description=(
                "Route the maxpool through gemmini's depthwise-conv + "
                "pool tail (tiled_conv_dw_auto). The conv is a per-"
                "channel passthrough — kernel_dim=1, stride=1, "
                "padding=0, weights=+1 per channel, bias=NULL, "
                "act=0, scale=ACC_SCALE_IDENTITY — so the "
                "accumulator value matches the input, and the mvout "
                "pool unit takes max over each KH×KW window with "
                "stride SH while writing to DRAM. We pick the dw "
                "variant over the full conv path so we only need C "
                "int8 weights instead of a C×C identity tensor "
                "(matters for yolov8 where C up to 256). Square "
                "windows only (KH==KW, SH==SW), DH==DW==1, and "
                "PH==PW==0 since gemmini's pool zero-pads OOB but "
                "the spec wants INT8_MIN — falls back to scalar "
                "otherwise."
            ),
            reference_impl="""\
void kernel_maxpool2d_s8(const int8_t *input, int8_t *output,
                         int N, int C, int IH, int IW,
                         int KH, int KW, int SH, int SW,
                         int PH, int PW, int DH, int DW)
{
    enum { GEMMINI_WS_BYTES = 512 * 1024 };
    enum { MAXPOOL_MAX_CHANNELS = 1024 };
    static elem_t ws_input  [GEMMINI_WS_BYTES] __attribute__((aligned(64)));
    static elem_t ws_output [GEMMINI_WS_BYTES] __attribute__((aligned(64)));
    static elem_t ws_weights[MAXPOOL_MAX_CHANNELS] __attribute__((aligned(64)));
    static int    ws_weights_inited = 0;
    int OH = (IH + 2*PH - DH*(KH-1) - 1) / SH + 1;
    int OW = (IW + 2*PW - DW*(KW-1) - 1) / SW + 1;
    bool gemmini_ok =
           KH == KW && SH == SW && PH == PW
        && DH == 1 && DW == 1
        && PH == 0
        && C <= MAXPOOL_MAX_CHANNELS
        && (size_t)(N * C * IH * IW) <= GEMMINI_WS_BYTES
        && (size_t)(N * C * OH * OW) <= GEMMINI_WS_BYTES;
    if (!gemmini_ok) {
        for (int n = 0; n < N; n++)
        for (int c = 0; c < C; c++)
        for (int oh = 0; oh < OH; oh++)
        for (int ow = 0; ow < OW; ow++) {
            int8_t m = INT8_MIN;
            for (int kh = 0; kh < KH; kh++) {
                int ih = oh*SH - PH + kh*DH;
                if (ih < 0 || ih >= IH) continue;
                for (int kw = 0; kw < KW; kw++) {
                    int iw = ow*SW - PW + kw*DW;
                    if (iw < 0 || iw >= IW) continue;
                    int8_t v = input[((n*C + c)*IH + ih)*IW + iw];
                    if (v > m) m = v;
                }
            }
            output[((n*C + c)*OH + oh)*OW + ow] = m;
        }
        return;
    }
    asm volatile("csrs mstatus, %0" : : "r"(0x18000) : "memory");
    if (!ws_weights_inited) {
        for (int i = 0; i < MAXPOOL_MAX_CHANNELS; i++) ws_weights[i] = 1;
        ws_weights_inited = 1;
    }
    gemmini_flush(0);
    for (int n = 0; n < N; n++)
        for (int h = 0; h < IH; h++)
            for (int w = 0; w < IW; w++)
                for (int c = 0; c < C; c++)
                    ws_input[((n*IH + h)*IW + w)*C + c] =
                        input[((n*C + c)*IH + h)*IW + w];
    asm volatile("fence" ::: "memory");
    tiled_conv_dw_auto(
        N, IH, IW, C, IH, IW,
        1, 0, 1,
        ws_input, ws_weights, NULL, ws_output,
        0, ACC_SCALE_IDENTITY,
        KH, SH, PH,
        WS);
    gemmini_fence();
    gemmini_flush(0);
    for (int n = 0; n < N; n++)
        for (int c = 0; c < C; c++)
            for (int h = 0; h < OH; h++)
                for (int w = 0; w < OW; w++)
                    output[((n*C + c)*OH + h)*OW + w] =
                        ws_output[((n*OH + h)*OW + w)*C + c];
}
""",
        ),
    ],
)


ADD_S8 = KernelSpec(
    op="add_s8",
    signature=(
        "void kernel_add_s8(const int8_t *a, const int8_t *b, int8_t *output, "
        "int n, float scale_a, float scale_b, float scale_out, "
        "int activation_min, int activation_max)"
    ),
    semantics=(
        "Quantized elementwise add. The two inputs may have different "
        "scales — they are dequantized to float, summed, and re-quantized "
        "into the output's scale. Internal float32 math; result is\n"
        "  output[i] = clamp(roundf((a[i]*scale_a + b[i]*scale_b)/scale_out),\n"
        "                    activation_min, activation_max)\n"
        "Use roundf (round-to-nearest, ties to even on most platforms; the\n"
        "verify simulator matches by using numpy.float32 + numpy.round)."
    ),
    reference_impl="""\
void kernel_add_s8(const int8_t *a, const int8_t *b, int8_t *output, int n,
                   float scale_a, float scale_b, float scale_out,
                   int activation_min, int activation_max) {
    for (int i = 0; i < n; i++) {
        float fa = (float)a[i] * scale_a;
        float fb = (float)b[i] * scale_b;
        float fout = (fa + fb) / scale_out;
        int32_t v = (int32_t)roundf(fout);
        if (v < activation_min) v = activation_min;
        if (v > activation_max) v = activation_max;
        output[i] = (int8_t)v;
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 17}, {"n": 8192}],
    argtypes_factory=_add_s8_argtypes,
    algorithms=[
        AlgorithmCandidate(
            name="gemmini_resadd",
            target_affinity=("gemmini", "gemmini_q31"),
            # Gemmini's tiled_resadd_auto: C[i] = sat_int8(round(A_scale*A[i]
            # + B_scale*B[i]) * C_scale) with optional fused ReLU. Same
            # mvin float-scale path as conv2d's mvin_scale; no Q0.31 drift
            # vs the float reference because the modelblaster add_s8 reference
            # is itself a float computation.
            accuracy_class=AccuracyClass.NUMERIC_DRIFT,
            description=(
                "Route the elementwise add through Gemmini's "
                "tiled_resadd_auto. Maps the modelblaster add_s8 contract "
                "(output = round((a*scale_a + b*scale_b) / scale_out), "
                "clamp [activation_min, activation_max]) to gemmini's "
                "A_scale = scale_a/scale_out, B_scale = scale_b/scale_out, "
                "C_scale = ACC_SCALE_IDENTITY, fused relu = "
                "(activation_min == 0). Pass I=1, J=n; the inner tiler "
                "shrinks tile_J in DIM-multiples to fit ACC_ROWS/2.\n\n"
                "Stage-1 limitations (caller falls back to scalar):\n"
                "  * n < 256: per-call gemmini setup (mstatus, "
                "    gemmini_flush, fence) costs more than a scalar "
                "    elementwise pass.\n"
                "  * activation ranges other than (0, 127) and "
                "    (-128, 127) need a CPU post-clamp (still a win — "
                "    the elementwise body runs on gemmini)."
            ),
            reference_impl="""\
void kernel_add_s8(const int8_t *a, const int8_t *b, int8_t *output, int n,
                   float scale_a, float scale_b, float scale_out,
                   int activation_min, int activation_max)
{
    float a_ratio = scale_a / scale_out;
    float b_ratio = scale_b / scale_out;
    float a_abs   = a_ratio < 0 ? -a_ratio : a_ratio;
    float b_abs   = b_ratio < 0 ? -b_ratio : b_ratio;
    bool scales_ok = (a_abs >= 0.5f && a_abs <= 2.0f
                      && b_abs >= 0.5f && b_abs <= 2.0f);
    if (n <= 0 || n < 256 || !scales_ok) {
        for (int i = 0; i < n; i++) {
            float fa = (float)a[i] * scale_a;
            float fb = (float)b[i] * scale_b;
            float fout = (fa + fb) / scale_out;
            int32_t v = (int32_t)roundf(fout);
            if (v < activation_min) v = activation_min;
            if (v > activation_max) v = activation_max;
            output[i] = (int8_t)v;
        }
        return;
    }
    bool fused_relu = (activation_min == 0 && activation_max == 127);
    bool need_post_clamp = !(activation_min == -128 && activation_max == 127)
                            && !fused_relu;
    asm volatile("csrs mstatus, %0" : : "r"(0x18000) : "memory");
    scale_t a_scale = (scale_t)(scale_a / scale_out);
    scale_t b_scale = (scale_t)(scale_b / scale_out);
    /* Chunk to ≤6272 to dodge the I=1, large-J memory-corruption mode
     * in tiled_resadd_auto's internal tiler. */
    enum { ADD_CHUNK_MAX = 6272 };
    int remaining = n, offset = 0;
    while (remaining > 0) {
        int chunk = remaining > ADD_CHUNK_MAX ? ADD_CHUNK_MAX : remaining;
        gemmini_flush(0);
        asm volatile("fence" ::: "memory");
        tiled_resadd_auto(
            1, (size_t)chunk,
            a_scale, b_scale, ACC_SCALE_IDENTITY,
            a + offset, b + offset, output + offset,
            fused_relu,
            WS
        );
        gemmini_fence();
        gemmini_flush(0);
        offset += chunk;
        remaining -= chunk;
    }
    if (need_post_clamp) {
        for (int i = 0; i < n; i++) {
            int v = output[i];
            if (v < activation_min) output[i] = (int8_t)activation_min;
            else if (v > activation_max) output[i] = (int8_t)activation_max;
        }
    }
}
""",
        ),
    ],
)


BATCHNORM2D_S8 = KernelSpec(
    op="batchnorm2d_s8",
    signature=(
        "void kernel_batchnorm2d_s8(const int8_t *input, const float *scale, "
        "const float *bias, int8_t *output, int N, int C, int H, int W, "
        "float scale_in, float scale_out, int activation_min, int activation_max)"
    ),
    semantics=(
        "Quantized BN: per-channel float affine on int8 activations.\n"
        "  output[n, c, h, w] = clamp(\n"
        "      roundf((scale[c] * (input[n, c, h, w] * scale_in) + bias[c])\n"
        "             / scale_out),\n"
        "      activation_min, activation_max)\n"
        "scale and bias are the eval-mode-folded BatchNorm parameters\n"
        "(scale = gamma / sqrt(var + eps), bias = beta - mean * scale).\n"
        "Per-channel float arrays of length C."
    ),
    reference_impl="""\
void kernel_batchnorm2d_s8(const int8_t *input, const float *scale,
                           const float *bias, int8_t *output,
                           int N, int C, int H, int W,
                           float scale_in, float scale_out,
                           int activation_min, int activation_max) {
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            float s = scale[c];
            float b = bias[c];
            for (int h = 0; h < H; h++) {
                for (int w = 0; w < W; w++) {
                    int idx = ((n*C + c)*H + h)*W + w;
                    float fv = (float)input[idx] * scale_in;
                    float y = s * fv + b;
                    int32_t v = (int32_t)roundf(y / scale_out);
                    if (v < activation_min) v = activation_min;
                    if (v > activation_max) v = activation_max;
                    output[idx] = (int8_t)v;
                }
            }
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "C": 32, "H": 16, "W": 16},
        {"N": 1, "C": 64, "H": 8, "W": 8},
        {"N": 1, "C": 128, "H": 4, "W": 4},
    ],
    argtypes_factory=_batchnorm2d_s8_argtypes,
)


SIGMOID_S8 = KernelSpec(
    op="sigmoid_s8",
    signature=(
        "void kernel_sigmoid_s8(const int8_t *input, int8_t *output, int n, "
        "float scale_in, float scale_out, int activation_min, int activation_max)"
    ),
    semantics=(
        "Elementwise quantized sigmoid:\n"
        "  output[i] = clamp(\n"
        "      roundf( (1 / (1 + expf(-input[i] * scale_in))) / scale_out ),\n"
        "      activation_min, activation_max)\n"
        "Tiny tensors (often n=1 at a model output head) — scalar loop is\n"
        "fine."
    ),
    reference_impl="""\
void kernel_sigmoid_s8(const int8_t *input, int8_t *output, int n,
                       float scale_in, float scale_out,
                       int activation_min, int activation_max) {
    for (int i = 0; i < n; i++) {
        float fv = (float)input[i] * scale_in;
        float sig = 1.0f / (1.0f + expf(-fv));
        int32_t v = (int32_t)roundf(sig / scale_out);
        if (v < activation_min) v = activation_min;
        if (v > activation_max) v = activation_max;
        output[i] = (int8_t)v;
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 16}],
    argtypes_factory=_sigmoid_s8_argtypes,
)


LSTM_S8 = KernelSpec(
    op="lstm_s8",
    signature=(
        "void kernel_lstm_s8(const int8_t *x, const int8_t *w_ih, "
        "const int8_t *w_hh, const float *bias, "
        "int8_t *h, int8_t *c, int8_t *out, "
        "int in_size, int H, "
        "float s_x, float s_wih, float s_whh, float s_h, float s_c)"
    ),
    semantics=(
        "Single-layer, single-timestep quantized LSTM cell (PyTorch nn.LSTM\n"
        "gate order: input, forget, cell, output). Recurrence across timesteps\n"
        "is expressed by persisting h and c in caller-owned buffers between\n"
        "calls (seq-len-1 unroll: one call per timestep).\n"
        "Layout (row-major):\n"
        "  x:     int8  [in_size]           layer input (scale s_x)\n"
        "  w_ih:  int8  [4H, in_size]       input->gates (scale s_wih)\n"
        "  w_hh:  int8  [4H, H]             hidden->gates (scale s_whh)\n"
        "  bias:  f32   [4H]                b_ih + b_hh (already summed)\n"
        "  h:     int8  [H]  IN/OUT         hidden state (scale s_h)\n"
        "  c:     int8  [H]  IN/OUT         cell state   (scale s_c)\n"
        "  out:   int8  [H]                 new hidden (= h after update); MUST\n"
        "                                    NOT alias h (h[k] of the PREVIOUS\n"
        "                                    step is read for every unit).\n"
        "Compute per unit j (gate row g uses w_[.][g*H + j]):\n"
        "  pre[g] = (float)(x . w_ih[g]) * (s_x*s_wih)\n"
        "         + (float)(h . w_hh[g]) * (s_h*s_whh) + bias[g*H+j]\n"
        "  i=sigmoid(pre_i); f=sigmoid(pre_f); g=tanh(pre_g); o=sigmoid(pre_o)\n"
        "  c' = f*(c[j]*s_c) + i*g;  h' = o*tanh(c')\n"
        "  c[j] = sat8(round(c'/s_c));  out[j] = sat8(round(h'/s_h))\n"
        "then h[:] = out[:] (deferred so the w_hh GEMM sees the previous h).\n"
        "Gate GEMMs are int8xint8->int32; gate nonlinearities + cell update\n"
        "are done in float (H is small — 128 — so this is cheap), matching the\n"
        "'encoder GEMMs int8, LSTM gates in float' split."
    ),
    reference_impl="""\
#include <math.h>
void kernel_lstm_s8(const int8_t *x, const int8_t *w_ih, const int8_t *w_hh,
                    const float *bias, int8_t *h, int8_t *c, int8_t *out,
                    int in_size, int H,
                    float s_x, float s_wih, float s_whh, float s_h, float s_c) {
    const float sx = s_x * s_wih;   /* dequant for the x . w_ih accumulator */
    const float sr = s_h * s_whh;   /* dequant for the h . w_hh accumulator */
    for (int j = 0; j < H; j++) {
        float pre[4];
        for (int g = 0; g < 4; g++) {
            int row = g * H + j;
            const int8_t *wih_row = w_ih + (long)row * in_size;
            const int8_t *whh_row = w_hh + (long)row * H;
            int32_t acc_x = 0, acc_h = 0;
            for (int k = 0; k < in_size; k++)
                acc_x += (int32_t)x[k] * (int32_t)wih_row[k];
            for (int k = 0; k < H; k++)
                acc_h += (int32_t)h[k] * (int32_t)whh_row[k];
            pre[g] = (float)acc_x * sx + (float)acc_h * sr + bias[row];
        }
        float ig = 1.0f / (1.0f + expf(-pre[0]));   /* input gate  */
        float fg = 1.0f / (1.0f + expf(-pre[1]));   /* forget gate */
        float cg = tanhf(pre[2]);                   /* cell gate   */
        float og = 1.0f / (1.0f + expf(-pre[3]));   /* output gate */
        float c_prev = (float)c[j] * s_c;
        float c_new  = fg * c_prev + ig * cg;
        float h_new  = og * tanhf(c_new);
        int32_t cq = (int32_t)roundf(c_new / s_c);
        if (cq < -128) cq = -128;
        if (cq > 127) cq = 127;
        int32_t hq = (int32_t)roundf(h_new / s_h);
        if (hq < -128) hq = -128;
        if (hq > 127) hq = 127;
        c[j]   = (int8_t)cq;
        out[j] = (int8_t)hq;   /* into out[] so h[] stays the previous state */
    }
    for (int j = 0; j < H; j++) h[j] = out[j];   /* commit new hidden state */
}
""",
    extra_shapes=[{"in_size": 8, "H": 4}, {"in_size": 16, "H": 8}],
    argtypes_factory=_lstm_s8_argtypes,
)


LSTM = KernelSpec(
    op="lstm",
    signature=(
        "void kernel_lstm(const float *x, const float *w_ih, "
        "const float *w_hh, const float *bias, "
        "float *h, float *c, float *out, int in_size, int H)"
    ),
    semantics=(
        "Single-layer, single-timestep fp32 LSTM cell (PyTorch nn.LSTM gate\n"
        "order: input, forget, cell, output). Recurrence is expressed by\n"
        "persisting h and c in caller buffers between calls (seq-len-1 unroll).\n"
        "  x:[in_size] w_ih:[4H,in_size] w_hh:[4H,H] bias:[4H] h:[H] c:[H] out:[H]\n"
        "per unit j (gate row g = g*H+j):\n"
        "  pre[g] = x.w_ih[g] + h.w_hh[g] + bias[g*H+j]\n"
        "  i=sig(pre_i) f=sig(pre_f) g=tanh(pre_g) o=sig(pre_o)\n"
        "  c' = f*c[j] + i*g;  out[j] = o*tanh(c')\n"
        "then h[:] = out[:] (deferred so the w_hh GEMM sees the previous h;\n"
        "out MUST NOT alias h)."
    ),
    reference_impl="""\
#include <math.h>
void kernel_lstm(const float *x, const float *w_ih, const float *w_hh,
                 const float *bias, float *h, float *c, float *out,
                 int in_size, int H) {
    for (int j = 0; j < H; j++) {
        float pre[4];
        for (int g = 0; g < 4; g++) {
            int row = g * H + j;
            const float *wih_row = w_ih + (long)row * in_size;
            const float *whh_row = w_hh + (long)row * H;
            float ax = 0.0f, ah = 0.0f;
            for (int k = 0; k < in_size; k++) ax += x[k] * wih_row[k];
            for (int k = 0; k < H; k++)       ah += h[k] * whh_row[k];
            pre[g] = ax + ah + bias[row];
        }
        float ig = 1.0f / (1.0f + expf(-pre[0]));
        float fg = 1.0f / (1.0f + expf(-pre[1]));
        float cg = tanhf(pre[2]);
        float og = 1.0f / (1.0f + expf(-pre[3]));
        float c_new = fg * c[j] + ig * cg;
        c[j]   = c_new;
        out[j] = og * tanhf(c_new);
    }
    for (int j = 0; j < H; j++) h[j] = out[j];
}
""",
    extra_shapes=[{"in_size": 8, "H": 4}, {"in_size": 16, "H": 8}],
    argtypes_factory=_lstm_argtypes,
)


CONV2D_DW = KernelSpec(
    op="conv2d_dw",
    signature=(
        "void kernel_conv2d_dw(const float *input, const float *weight, "
        "const float *bias, float *output, "
        "int N, int C, int IH, int IW, "
        "int KH, int KW, int SH, int SW, int PH, int PW)"
    ),
    semantics=(
        "Depthwise 2D convolution — each input channel has its OWN filter,\n"
        "applied independently. Equivalent to torch.nn.Conv2d with\n"
        "groups=in_channels=out_channels=C and dilation=1.\n"
        "Layout (row-major):\n"
        "  input:  [N, C, IH, IW]\n"
        "  weight: [C, 1, KH, KW]   (one KHxKW filter per channel)\n"
        "  bias:   [C] (may be NULL — treat as zeros)\n"
        "  output: [N, C, OH, OW]   with\n"
        "    OH = (IH + 2*PH - KH) / SH + 1\n"
        "    OW = (IW + 2*PW - KW) / SW + 1\n"
        "Definition (zero-padding):\n"
        "  output[n, c, oh, ow] = bias[c] + sum over kh, kw of\n"
        "    input[n, c, oh*SH - PH + kh, ow*SW - PW + kw]\n"
        "    * weight[c, 0, kh, kw]\n"
        "  with input reads outside [0, IH) x [0, IW) treated as 0.\n"
        "All tensors are float32."
    ),
    reference_impl="""\
void kernel_conv2d_dw(const float *input, const float *weight, const float *bias,
                      float *output,
                      int N, int C, int IH, int IW,
                      int KH, int KW, int SH, int SW, int PH, int PW) {
    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            for (int oh = 0; oh < OH; oh++) {
                for (int ow = 0; ow < OW; ow++) {
                    float acc = bias ? bias[c] : 0.0f;
                    for (int kh = 0; kh < KH; kh++) {
                        int ih = oh * SH - PH + kh;
                        if (ih < 0 || ih >= IH) continue;
                        for (int kw = 0; kw < KW; kw++) {
                            int iw = ow * SW - PW + kw;
                            if (iw < 0 || iw >= IW) continue;
                            float v = input[((n*C + c)*IH + ih)*IW + iw];
                            float w = weight[(c*KH + kh)*KW + kw];
                            acc += v * w;
                        }
                    }
                    output[((n*C + c)*OH + oh)*OW + ow] = acc;
                }
            }
        }
    }
}
""",
    extra_shapes=[
        # MobileNetV2 width_mult=0.25 first-block 3x3 stride=1 dw conv
        {"N": 1, "C": 8, "IH": 56, "IW": 56,
         "KH": 3, "KW": 3, "SH": 1, "SW": 1, "PH": 1, "PW": 1},
        # MobileNetV2 stride=2 dw transition
        {"N": 1, "C": 24, "IH": 56, "IW": 56,
         "KH": 3, "KW": 3, "SH": 2, "SW": 2, "PH": 1, "PW": 1},
        # Asymmetric / odd shapes
        {"N": 1, "C": 4, "IH": 7, "IW": 5,
         "KH": 3, "KW": 3, "SH": 1, "SW": 1, "PH": 1, "PW": 1},
    ],
    argtypes_factory=_conv2d_dw_argtypes,
)


RELU6 = KernelSpec(
    op="relu6",
    signature="void kernel_relu6(const float *input, float *output, int n)",
    semantics=(
        "Elementwise ReLU6 on a contiguous float32 buffer:\n"
        "  output[i] = min(max(0.0f, input[i]), 6.0f)  for i in [0, n)\n"
        "It must be safe for `input` and `output` to alias."
    ),
    reference_impl="""\
void kernel_relu6(const float *input, float *output, int n) {
    for (int i = 0; i < n; i++) {
        float v = input[i];
        if (v < 0.0f) v = 0.0f;
        if (v > 6.0f) v = 6.0f;
        output[i] = v;
    }
}
""",
    extra_shapes=[
        {"n": 1},
        {"n": 17},
        {"n": 1024},
    ],
    argtypes_factory=_relu6_argtypes,
)


# ---------------------------------------------------------------------------
# KernelBench Phase 2 activations (10 ops). All pointwise, fp32. The
# matching fp16 variants live below alongside the other _f16 specs so
# the existing fp16 mode picks them up via the op-suffix mechanism.
# ---------------------------------------------------------------------------

LEAKY_RELU = KernelSpec(
    op="leaky_relu",
    signature=(
        "void kernel_leaky_relu(const float *input, float *output, "
        "int n, float negative_slope)"
    ),
    semantics=(
        "Elementwise LeakyReLU on a contiguous float32 buffer:\n"
        "  output[i] = input[i]                if input[i] >= 0\n"
        "  output[i] = input[i] * negative_slope otherwise\n"
        "Same shape as ReLU; the slope on the negative half-line is the\n"
        "only difference. Safe to alias input/output."
    ),
    reference_impl="""\
void kernel_leaky_relu(const float *input, float *output,
                       int n, float negative_slope) {
    for (int i = 0; i < n; i++) {
        float v = input[i];
        output[i] = v >= 0.0f ? v : v * negative_slope;
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 17}, {"n": 1024}],
    argtypes_factory=_leaky_relu_argtypes,
)


TANH = KernelSpec(
    op="tanh",
    signature="void kernel_tanh(const float *input, float *output, int n)",
    semantics=(
        "Elementwise tanh on a contiguous float32 buffer.\n"
        "Uses libm's tanhf — already accurate to <1ulp on Zephyr's\n"
        "newlib/picolibc."
    ),
    reference_impl="""\
#include <math.h>

void kernel_tanh(const float *input, float *output, int n) {
    for (int i = 0; i < n; i++) {
        output[i] = tanhf(input[i]);
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 17}, {"n": 1024}],
    argtypes_factory=_pointwise_argtypes,
)


SWISH = KernelSpec(
    op="swish",
    signature="void kernel_swish(const float *input, float *output, int n)",
    semantics=(
        "Elementwise Swish (also called SiLU): output[i] = x * sigmoid(x).\n"
        "sigmoid(x) = 1 / (1 + expf(-x))."
    ),
    reference_impl="""\
#include <math.h>

void kernel_swish(const float *input, float *output, int n) {
    for (int i = 0; i < n; i++) {
        float x = input[i];
        float s = 1.0f / (1.0f + expf(-x));
        output[i] = x * s;
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 17}, {"n": 1024}],
    argtypes_factory=_pointwise_argtypes,
)


GELU = KernelSpec(
    op="gelu",
    signature="void kernel_gelu(const float *input, float *output, int n)",
    semantics=(
        "Elementwise GELU using the EXACT erf formulation, matching\n"
        "torch.nn.GELU and torch.nn.functional.gelu's `approximate='none'`\n"
        "default (PyTorch 1.10+):\n"
        "  output = 0.5 * x * (1 + erf(x / sqrt(2)))\n"
        "The tanh approximation lives under the separate `gelu_exact`\n"
        "op (used by the MinGPT-style hand-rolled expression). The two\n"
        "agree to ~5e-4 absolute on randn inputs — close but distinct,\n"
        "and PyTorch ships the erf form as default so we use it here."
    ),
    reference_impl="""\
#include <math.h>

void kernel_gelu(const float *input, float *output, int n) {
    /* 1 / sqrt(2) = 0.70710678118654752440f. */
    const float inv_sqrt2 = 0.7071067811865475f;
    for (int i = 0; i < n; i++) {
        float x = input[i];
        output[i] = 0.5f * x * (1.0f + erff(x * inv_sqrt2));
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 17}, {"n": 1024}],
    argtypes_factory=_pointwise_argtypes,
)


# The tanh-based GELU approximation — what MinGPT (and the original
# BERT / GPT-2 papers) hand-rolled. PyTorch reaches this form via
# `F.gelu(x, approximate='tanh')` or by tracing the explicit
# expression. We keep a separate op for it so the IR cleanly captures
# which surface the bench used; numerically the two agree to ~5e-4.
GELU_EXACT = KernelSpec(
    op="gelu_exact",
    signature=(
        "void kernel_gelu_exact(const float *input, float *output, int n)"
    ),
    semantics=(
        "Elementwise GELU computed via the MinGPT / BERT formula:\n"
        "  output = 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))\n"
        "Approximation of the exact erf form; the two agree to ~5e-4 on\n"
        "randn inputs. Used by 88_MinGPTNewGelu and `F.gelu(approximate='tanh')`."
    ),
    reference_impl="""\
#include <math.h>

void kernel_gelu_exact(const float *input, float *output, int n) {
    /* sqrtf(2.0f / M_PI) = 0.79788456080286535588f. */
    const float k = 0.7978845608028654f;
    for (int i = 0; i < n; i++) {
        float x = input[i];
        float u = k * (x + 0.044715f * x * x * x);
        output[i] = 0.5f * x * (1.0f + tanhf(u));
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 17}, {"n": 1024}],
    argtypes_factory=_pointwise_argtypes,
)


SELU = KernelSpec(
    op="selu",
    signature="void kernel_selu(const float *input, float *output, int n)",
    semantics=(
        "Scaled Exponential Linear Unit. PyTorch uses fixed constants:\n"
        "  alpha  = 1.6732632423543772\n"
        "  scale  = 1.0507009873554805\n"
        "  output = scale * (x       if x > 0\n"
        "                    alpha * (expf(x) - 1)   otherwise)"
    ),
    reference_impl="""\
#include <math.h>

void kernel_selu(const float *input, float *output, int n) {
    const float alpha = 1.6732632423543772f;
    const float scale = 1.0507009873554805f;
    for (int i = 0; i < n; i++) {
        float x = input[i];
        float y = x > 0.0f ? x : alpha * (expf(x) - 1.0f);
        output[i] = scale * y;
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 17}, {"n": 1024}],
    argtypes_factory=_pointwise_argtypes,
)


HARDSIGMOID = KernelSpec(
    op="hardsigmoid",
    signature=(
        "void kernel_hardsigmoid(const float *input, float *output, int n)"
    ),
    semantics=(
        "Piecewise-linear sigmoid approximation matching\n"
        "torch.nn.functional.hardsigmoid:\n"
        "  output[i] =   0          if x <= -3\n"
        "              1            if x >=  3\n"
        "              x/6 + 0.5    otherwise"
    ),
    reference_impl="""\
void kernel_hardsigmoid(const float *input, float *output, int n) {
    for (int i = 0; i < n; i++) {
        float x = input[i];
        float y;
        if (x <= -3.0f)      y = 0.0f;
        else if (x >=  3.0f) y = 1.0f;
        else                 y = x * (1.0f / 6.0f) + 0.5f;
        output[i] = y;
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 17}, {"n": 1024}],
    argtypes_factory=_pointwise_argtypes,
)


SOFTPLUS = KernelSpec(
    op="softplus",
    signature=(
        "void kernel_softplus(const float *input, float *output, int n)"
    ),
    semantics=(
        "Elementwise softplus: output = log(1 + expf(x)).\n"
        "For numerical stability we pivot on the sign of x so we never\n"
        "compute expf of a large positive: large-x reduces to x +\n"
        "log(1 + expf(-x)) ~= x. PyTorch defaults to beta=1, threshold=20\n"
        "but the threshold-passthrough only matters for extreme inputs;\n"
        "the unconditional formula via log1pf(expf(...)) is fine in fp32."
    ),
    reference_impl="""\
#include <math.h>

void kernel_softplus(const float *input, float *output, int n) {
    for (int i = 0; i < n; i++) {
        float x = input[i];
        /* Pivot keeps expf's argument <= 0, avoiding overflow. */
        float y = x > 0.0f
            ? x + log1pf(expf(-x))
            : log1pf(expf(x));
        output[i] = y;
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 17}, {"n": 1024}],
    argtypes_factory=_pointwise_argtypes,
)


SOFTSIGN = KernelSpec(
    op="softsign",
    signature=(
        "void kernel_softsign(const float *input, float *output, int n)"
    ),
    semantics=(
        "Elementwise softsign: output = x / (1 + |x|). Smooth, bounded\n"
        "alternative to tanh; no transcendental cost."
    ),
    reference_impl="""\
void kernel_softsign(const float *input, float *output, int n) {
    for (int i = 0; i < n; i++) {
        float x = input[i];
        float ax = x < 0.0f ? -x : x;
        output[i] = x / (1.0f + ax);
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 17}, {"n": 1024}],
    argtypes_factory=_pointwise_argtypes,
)


HARDTANH = KernelSpec(
    op="hardtanh",
    signature=(
        "void kernel_hardtanh(const float *input, float *output, "
        "int n, float min_val, float max_val)"
    ),
    semantics=(
        "Pointwise clamp to [min_val, max_val]. PyTorch's hardtanh\n"
        "defaults to min=-1, max=+1. Same dataflow as relu6 with\n"
        "configurable bounds."
    ),
    reference_impl="""\
void kernel_hardtanh(const float *input, float *output,
                     int n, float min_val, float max_val) {
    for (int i = 0; i < n; i++) {
        float x = input[i];
        if (x < min_val) x = min_val;
        if (x > max_val) x = max_val;
        output[i] = x;
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 17}, {"n": 1024}],
    argtypes_factory=_hardtanh_argtypes,
)


# ---------------------------------------------------------------------------
# KernelBench Phase 2 reductions over a single dimension. Each kernel
# treats the input as logically 3D — [outer, reduce, inner] — so any
# Nd input with `dim=k` flattens to outer=prod(shape[:k]),
# reduce=shape[k], inner=prod(shape[k+1:]). The output is [outer, inner]
# (or [outer, 1, inner] for keepdim) — same flat layout for both, so
# the kernels don't need to know about keepdim.
# ---------------------------------------------------------------------------

def _reduce_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    return [fp, fp, ctypes.c_int, ctypes.c_int, ctypes.c_int]


def _argreduce_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    i64p = ctypes.POINTER(ctypes.c_int64)
    return [fp, i64p, ctypes.c_int, ctypes.c_int, ctypes.c_int]


SUM_DIM = KernelSpec(
    op="sum_dim",
    signature=(
        "void kernel_sum_dim(const float *input, float *output, "
        "int outer, int reduce, int inner)"
    ),
    semantics=(
        "Reduce-sum along the middle axis of a logically [outer, reduce,\n"
        "inner] flattened tensor. Output is [outer, inner].\n"
        "  output[o, i] = sum over r in [0, reduce) of\n"
        "    input[(o * reduce + r) * inner + i]"
    ),
    reference_impl="""\
void kernel_sum_dim(const float *input, float *output,
                    int outer, int reduce, int inner) {
    for (int o = 0; o < outer; o++) {
        for (int i = 0; i < inner; i++) {
            float acc = 0.0f;
            for (int r = 0; r < reduce; r++) {
                acc += input[(o * reduce + r) * inner + i];
            }
            output[o * inner + i] = acc;
        }
    }
}
""",
    extra_shapes=[
        {"outer": 1,  "reduce": 17,  "inner": 1},
        {"outer": 4,  "reduce": 33,  "inner": 8},
        {"outer": 16, "reduce": 256, "inner": 256},
    ],
    argtypes_factory=_reduce_argtypes,
)


MEAN_DIM = KernelSpec(
    op="mean_dim",
    signature=(
        "void kernel_mean_dim(const float *input, float *output, "
        "int outer, int reduce, int inner)"
    ),
    semantics=(
        "Reduce-mean along the middle axis. Same dataflow as sum_dim,\n"
        "with a final divide by `reduce`."
    ),
    reference_impl="""\
void kernel_mean_dim(const float *input, float *output,
                     int outer, int reduce, int inner) {
    float inv = 1.0f / (float)reduce;
    for (int o = 0; o < outer; o++) {
        for (int i = 0; i < inner; i++) {
            float acc = 0.0f;
            for (int r = 0; r < reduce; r++) {
                acc += input[(o * reduce + r) * inner + i];
            }
            output[o * inner + i] = acc * inv;
        }
    }
}
""",
    extra_shapes=[
        {"outer": 1,  "reduce": 17,  "inner": 1},
        {"outer": 4,  "reduce": 33,  "inner": 8},
        {"outer": 16, "reduce": 256, "inner": 256},
    ],
    argtypes_factory=_reduce_argtypes,
)


MAX_DIM = KernelSpec(
    op="max_dim",
    signature=(
        "void kernel_max_dim(const float *input, float *output, "
        "int outer, int reduce, int inner)"
    ),
    semantics=(
        "Reduce-max (values only, not indices) along the middle axis.\n"
        "Initialized to -FLT_MAX so a single-element reduce returns the\n"
        "input value directly."
    ),
    reference_impl="""\
#include <float.h>

void kernel_max_dim(const float *input, float *output,
                    int outer, int reduce, int inner) {
    for (int o = 0; o < outer; o++) {
        for (int i = 0; i < inner; i++) {
            float m = -FLT_MAX;
            for (int r = 0; r < reduce; r++) {
                float v = input[(o * reduce + r) * inner + i];
                if (v > m) m = v;
            }
            output[o * inner + i] = m;
        }
    }
}
""",
    extra_shapes=[
        {"outer": 1,  "reduce": 17,  "inner": 1},
        {"outer": 4,  "reduce": 33,  "inner": 8},
        {"outer": 16, "reduce": 256, "inner": 256},
    ],
    argtypes_factory=_reduce_argtypes,
)


MIN_DIM = KernelSpec(
    op="min_dim",
    signature=(
        "void kernel_min_dim(const float *input, float *output, "
        "int outer, int reduce, int inner)"
    ),
    semantics=(
        "Reduce-min (values only) along the middle axis. Mirror of\n"
        "max_dim with FLT_MAX init and `<` compare."
    ),
    reference_impl="""\
#include <float.h>

void kernel_min_dim(const float *input, float *output,
                    int outer, int reduce, int inner) {
    for (int o = 0; o < outer; o++) {
        for (int i = 0; i < inner; i++) {
            float m = FLT_MAX;
            for (int r = 0; r < reduce; r++) {
                float v = input[(o * reduce + r) * inner + i];
                if (v < m) m = v;
            }
            output[o * inner + i] = m;
        }
    }
}
""",
    extra_shapes=[
        {"outer": 1,  "reduce": 17,  "inner": 1},
        {"outer": 4,  "reduce": 33,  "inner": 8},
        {"outer": 16, "reduce": 256, "inner": 256},
    ],
    argtypes_factory=_reduce_argtypes,
)


PROD_DIM = KernelSpec(
    op="prod_dim",
    signature=(
        "void kernel_prod_dim(const float *input, float *output, "
        "int outer, int reduce, int inner)"
    ),
    semantics=(
        "Reduce-product along the middle axis. Init=1.0, multiply-fold."
    ),
    reference_impl="""\
void kernel_prod_dim(const float *input, float *output,
                     int outer, int reduce, int inner) {
    for (int o = 0; o < outer; o++) {
        for (int i = 0; i < inner; i++) {
            float acc = 1.0f;
            for (int r = 0; r < reduce; r++) {
                acc *= input[(o * reduce + r) * inner + i];
            }
            output[o * inner + i] = acc;
        }
    }
}
""",
    extra_shapes=[
        {"outer": 1,  "reduce": 17,  "inner": 1},
        {"outer": 4,  "reduce": 33,  "inner": 8},
        {"outer": 16, "reduce": 256, "inner": 256},
    ],
    argtypes_factory=_reduce_argtypes,
)


ARGMAX_DIM = KernelSpec(
    op="argmax_dim",
    signature=(
        "void kernel_argmax_dim(const float *input, int64_t *output, "
        "int outer, int reduce, int inner)"
    ),
    semantics=(
        "Argmax along the middle axis. Returns int64 indices (same dtype\n"
        "as torch.argmax). On ties, returns the FIRST index (matches\n"
        "torch's behavior on CPU)."
    ),
    reference_impl="""\
#include <stdint.h>
#include <float.h>

void kernel_argmax_dim(const float *input, int64_t *output,
                       int outer, int reduce, int inner) {
    for (int o = 0; o < outer; o++) {
        for (int i = 0; i < inner; i++) {
            float m = -FLT_MAX;
            int64_t idx = 0;
            for (int r = 0; r < reduce; r++) {
                float v = input[(o * reduce + r) * inner + i];
                if (v > m) { m = v; idx = (int64_t)r; }
            }
            output[o * inner + i] = idx;
        }
    }
}
""",
    extra_shapes=[
        {"outer": 1,  "reduce": 17,  "inner": 1},
        {"outer": 4,  "reduce": 33,  "inner": 8},
        {"outer": 16, "reduce": 256, "inner": 256},
    ],
    argtypes_factory=_argreduce_argtypes,
)


ARGMIN_DIM = KernelSpec(
    op="argmin_dim",
    signature=(
        "void kernel_argmin_dim(const float *input, int64_t *output, "
        "int outer, int reduce, int inner)"
    ),
    semantics=(
        "Argmin along the middle axis. Returns int64 indices. Same\n"
        "tie-breaking as torch (first index)."
    ),
    reference_impl="""\
#include <stdint.h>
#include <float.h>

void kernel_argmin_dim(const float *input, int64_t *output,
                       int outer, int reduce, int inner) {
    for (int o = 0; o < outer; o++) {
        for (int i = 0; i < inner; i++) {
            float m = FLT_MAX;
            int64_t idx = 0;
            for (int r = 0; r < reduce; r++) {
                float v = input[(o * reduce + r) * inner + i];
                if (v < m) { m = v; idx = (int64_t)r; }
            }
            output[o * inner + i] = idx;
        }
    }
}
""",
    extra_shapes=[
        {"outer": 1,  "reduce": 17,  "inner": 1},
        {"outer": 4,  "reduce": 33,  "inner": 8},
        {"outer": 16, "reduce": 256, "inner": 256},
    ],
    argtypes_factory=_argreduce_argtypes,
)


# ---------------------------------------------------------------------------
# KernelBench Phase 2 norms (subset). Each divides the input by some
# reduction-derived scalar/vector. L1Norm / L2Norm share the
# (outer, reduce, inner) shape with the reductions; FrobeniusNorm
# uses a single global denominator over the whole tensor.
# ---------------------------------------------------------------------------

L1_NORM = KernelSpec(
    op="l1_norm",
    signature=(
        "void kernel_l1_norm(const float *input, float *output, "
        "int outer, int reduce, int inner)"
    ),
    semantics=(
        "Per-(outer, inner) L1 normalization:\n"
        "  denom[o, i] = sum over r of |input[(o*reduce + r)*inner + i]|\n"
        "  output[o, r, i] = input[o, r, i] / denom[o, i]\n"
        "Same flat layout as the reduction kernels, but the output\n"
        "preserves the reduce axis (broadcast division)."
    ),
    reference_impl="""\
void kernel_l1_norm(const float *input, float *output,
                    int outer, int reduce, int inner) {
    for (int o = 0; o < outer; o++) {
        for (int i = 0; i < inner; i++) {
            float denom = 0.0f;
            for (int r = 0; r < reduce; r++) {
                float v = input[(o * reduce + r) * inner + i];
                denom += v < 0.0f ? -v : v;
            }
            float inv = 1.0f / denom;
            for (int r = 0; r < reduce; r++) {
                int idx = (o * reduce + r) * inner + i;
                output[idx] = input[idx] * inv;
            }
        }
    }
}
""",
    extra_shapes=[
        {"outer": 1, "reduce": 17, "inner": 1},
        {"outer": 16, "reduce": 16384, "inner": 1},
    ],
    argtypes_factory=_reduce_argtypes,
)


L2_NORM = KernelSpec(
    op="l2_norm",
    signature=(
        "void kernel_l2_norm(const float *input, float *output, "
        "int outer, int reduce, int inner)"
    ),
    semantics=(
        "Per-(outer, inner) L2 normalization:\n"
        "  denom[o, i] = sqrt(sum over r of input[o, r, i]^2)\n"
        "  output[o, r, i] = input[o, r, i] / denom[o, i]"
    ),
    reference_impl="""\
#include <math.h>

void kernel_l2_norm(const float *input, float *output,
                    int outer, int reduce, int inner) {
    for (int o = 0; o < outer; o++) {
        for (int i = 0; i < inner; i++) {
            float ssq = 0.0f;
            for (int r = 0; r < reduce; r++) {
                float v = input[(o * reduce + r) * inner + i];
                ssq += v * v;
            }
            float inv = 1.0f / sqrtf(ssq);
            for (int r = 0; r < reduce; r++) {
                int idx = (o * reduce + r) * inner + i;
                output[idx] = input[idx] * inv;
            }
        }
    }
}
""",
    extra_shapes=[
        {"outer": 1, "reduce": 17, "inner": 1},
        {"outer": 16, "reduce": 16384, "inner": 1},
    ],
    argtypes_factory=_reduce_argtypes,
)


def _frobenius_norm_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    return [fp, fp, ctypes.c_int]


FROBENIUS_NORM = KernelSpec(
    op="frobenius_norm",
    signature=(
        "void kernel_frobenius_norm(const float *input, float *output, int n)"
    ),
    semantics=(
        "Global Frobenius normalization — whole tensor flattened.\n"
        "  denom = sqrt(sum over i of input[i]^2)\n"
        "  output[i] = input[i] / denom\n"
        "torch.norm(x, p='fro') == torch.norm(x, p=2) on a flattened\n"
        "tensor; we compute it as a sum-of-squares + sqrtf."
    ),
    reference_impl="""\
#include <math.h>

void kernel_frobenius_norm(const float *input, float *output, int n) {
    float ssq = 0.0f;
    for (int i = 0; i < n; i++) {
        float v = input[i];
        ssq += v * v;
    }
    float inv = 1.0f / sqrtf(ssq);
    for (int i = 0; i < n; i++) {
        output[i] = input[i] * inv;
    }
}
""",
    extra_shapes=[{"n": 17}, {"n": 1024}],
    argtypes_factory=_frobenius_norm_argtypes,
)


ADAPTIVE_AVG_POOL2D = KernelSpec(
    op="adaptive_avg_pool2d",
    signature=(
        "void kernel_adaptive_avg_pool2d(const float *input, float *output, "
        "int N, int C, int IH, int IW)"
    ),
    semantics=(
        "Global average pooling — collapses [N, C, IH, IW] to [N, C, 1, 1]\n"
        "by averaging over each channel's HxW plane. Matches\n"
        "torch.nn.AdaptiveAvgPool2d(output_size=1).\n"
        "Definition:\n"
        "  output[n, c, 0, 0] = (1 / (IH*IW)) * sum over ih, iw of\n"
        "    input[n, c, ih, iw]\n"
        "All tensors are float32. (Generic AdaptiveAvgPool2d to non-1x1\n"
        "outputs would partition the spatial dims into output-sized chunks;\n"
        "we only support 1x1 outputs since that's what classifiers use.)"
    ),
    reference_impl="""\
void kernel_adaptive_avg_pool2d(const float *input, float *output,
                                int N, int C, int IH, int IW) {
    int n_per_chan = IH * IW;
    float inv = 1.0f / (float)n_per_chan;
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            const float *src = input + ((n*C + c) * IH) * IW;
            float acc = 0.0f;
            for (int i = 0; i < n_per_chan; i++) {
                acc += src[i];
            }
            output[n*C + c] = acc * inv;
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "C": 16, "IH": 7, "IW": 7},
        {"N": 1, "C": 320, "IH": 7, "IW": 7},
        {"N": 1, "C": 4, "IH": 1, "IW": 1},
    ],
    argtypes_factory=_adaptive_avg_pool2d_argtypes,
)


# ---------------------------------------------------------------------------
# fp16 (half-precision) kernel specs. Mirror the fp32 pointwise / pool /
# conv / batchnorm shapes but use _Float16 storage. For accumulating ops
# (conv2d, batchnorm-fold) we accumulate in fp32 then cast back — same
# pattern Tensor Cores use, and the accuracy gap to a pure-fp16 accumulator
# is significant enough that torch.float16 conv goes through this path too.
# Element-wise transcendentals (sigmoid, elu) round-trip through float for
# the math kernel since libm has no half-precision expf yet.
# ---------------------------------------------------------------------------

RELU_F16 = KernelSpec(
    op="relu_f16",
    signature="void kernel_relu_f16(const _Float16 *input, _Float16 *output, int n)",
    semantics=(
        "Elementwise ReLU on a contiguous _Float16 buffer:\n"
        "  output[i] = max(0, input[i])  for i in [0, n)\n"
        "Same semantics as the fp32 RELU kernel — only the storage type "
        "changes. It must be safe for `input` and `output` to alias."
    ),
    reference_impl="""\
void kernel_relu_f16(const _Float16 *input, _Float16 *output, int n) {
    for (int i = 0; i < n; i++) {
        _Float16 v = input[i];
        output[i] = v > (_Float16)0.0f ? v : (_Float16)0.0f;
    }
}
""",
    extra_shapes=[
        {"n": 1}, {"n": 17}, {"n": 1024},
    ],
    argtypes_factory=_relu_f16_argtypes,
)


SIGMOID_F16 = KernelSpec(
    op="sigmoid_f16",
    signature="void kernel_sigmoid_f16(const _Float16 *input, _Float16 *output, int n)",
    semantics=(
        "Elementwise sigmoid on a contiguous _Float16 buffer:\n"
        "  output[i] = 1 / (1 + expf(-input[i]))\n"
        "Math is done in float (libm has no expf16), then the result is\n"
        "cast back to _Float16. This is what torch.float16 sigmoid does\n"
        "internally on CPU."
    ),
    reference_impl="""\
#include <math.h>

void kernel_sigmoid_f16(const _Float16 *input, _Float16 *output, int n) {
    for (int i = 0; i < n; i++) {
        float v = (float)input[i];
        output[i] = (_Float16)(1.0f / (1.0f + expf(-v)));
    }
}
""",
    extra_shapes=[
        {"n": 1}, {"n": 17}, {"n": 1024},
    ],
    argtypes_factory=_sigmoid_f16_argtypes,
)


ELU_F16 = KernelSpec(
    op="elu_f16",
    signature=("void kernel_elu_f16(const _Float16 *input, _Float16 *output, "
               "int n, float alpha)"),
    semantics=(
        "Elementwise ELU on a contiguous _Float16 buffer:\n"
        "  output[i] = input[i]                       if input[i] > 0\n"
        "  output[i] = alpha * (expf(input[i]) - 1)   otherwise\n"
        "alpha is passed as float and used directly by expf — the cast back\n"
        "to _Float16 happens at store. nn.ELU defaults to alpha=1.0."
    ),
    reference_impl="""\
#include <math.h>

void kernel_elu_f16(const _Float16 *input, _Float16 *output,
                    int n, float alpha) {
    for (int i = 0; i < n; i++) {
        float v = (float)input[i];
        float r = v > 0.0f ? v : alpha * (expf(v) - 1.0f);
        output[i] = (_Float16)r;
    }
}
""",
    extra_shapes=[
        {"n": 1}, {"n": 16}, {"n": 256}, {"n": 1024},
    ],
    argtypes_factory=_elu_f16_argtypes,
)


BATCHNORM2D_F16 = KernelSpec(
    op="batchnorm2d_f16",
    signature=(
        "void kernel_batchnorm2d_f16(const _Float16 *input, "
        "const _Float16 *scale, const _Float16 *bias, _Float16 *output, "
        "int N, int C, int H, int W)"
    ),
    semantics=(
        "Apply pre-folded affine BatchNorm to a [N, C, H, W] _Float16 input:\n"
        "  output[n, c, h, w] = scale[c] * input[n, c, h, w] + bias[c]\n"
        "scale and bias are the gamma/(running_var+eps) and beta-mean*scale\n"
        "fold pre-computed in fp32 by extract_graph and cast to _Float16 at\n"
        "save time."
    ),
    reference_impl="""\
void kernel_batchnorm2d_f16(const _Float16 *input,
                            const _Float16 *scale, const _Float16 *bias,
                            _Float16 *output,
                            int N, int C, int H, int W) {
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            /* Match PyTorch CPU fp16 BN: upcast operands to fp32 for the
             * scale*input + bias multiply-add, then cast result back to
             * fp16. Pure-fp16 arithmetic (the previous reference body)
             * accumulated rounding error per channel and produced 30-50%
             * magnitude drift through the EfficientNet body. */
            float s = (float)scale[c];
            float b = (float)bias[c];
            for (int h = 0; h < H; h++) {
                for (int w = 0; w < W; w++) {
                    int idx = ((n*C + c)*H + h)*W + w;
                    output[idx] = (_Float16)(s * (float)input[idx] + b);
                }
            }
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "C": 4, "H": 8, "W": 8},
        {"N": 1, "C": 64, "H": 7, "W": 7},
    ],
    argtypes_factory=_batchnorm2d_f16_argtypes,
)


MAXPOOL2D_F16 = KernelSpec(
    op="maxpool2d_f16",
    signature=(
        "void kernel_maxpool2d_f16(const _Float16 *input, _Float16 *output, "
        "int N, int C, int IH, int IW, "
        "int KH, int KW, int SH, int SW, "
        "int PH, int PW, int DH, int DW)"
    ),
    semantics=(
        "Half-precision 2D max pool. Same dataflow as the fp32 MAXPOOL2D\n"
        "kernel; only the storage type differs. OOB padding lanes are\n"
        "initialized with -65504 (the most-negative finite _Float16) so they\n"
        "never win the max — equivalent to -INF for the representable range."
    ),
    reference_impl="""\
void kernel_maxpool2d_f16(const _Float16 *input, _Float16 *output,
                          int N, int C, int IH, int IW,
                          int KH, int KW, int SH, int SW,
                          int PH, int PW, int DH, int DW) {
    int OH = (IH + 2*PH - DH*(KH-1) - 1) / SH + 1;
    int OW = (IW + 2*PW - DW*(KW-1) - 1) / SW + 1;
    /* -FLT16_MAX equivalent: -65504 is the most-negative finite half. */
    const _Float16 NEG_HALF_INF = (_Float16)-65504.0f;
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            for (int oh = 0; oh < OH; oh++) {
                for (int ow = 0; ow < OW; ow++) {
                    _Float16 m = NEG_HALF_INF;
                    for (int kh = 0; kh < KH; kh++) {
                        int ih = oh*SH - PH + kh*DH;
                        if (ih < 0 || ih >= IH) continue;
                        for (int kw = 0; kw < KW; kw++) {
                            int iw = ow*SW - PW + kw*DW;
                            if (iw < 0 || iw >= IW) continue;
                            _Float16 v = input[((n*C + c)*IH + ih)*IW + iw];
                            if (v > m) m = v;
                        }
                    }
                    output[((n*C + c)*OH + oh)*OW + ow] = m;
                }
            }
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "C": 6, "IH": 24, "IW": 24, "KH": 2, "KW": 2, "SH": 2, "SW": 2,
         "PH": 0, "PW": 0, "DH": 1, "DW": 1},
        # KernelBench 42 shape (padding+dilation)
        {"N": 1, "C": 8, "IH": 16, "IW": 16, "KH": 2, "KW": 2, "SH": 2, "SW": 2,
         "PH": 1, "PW": 1, "DH": 3, "DW": 3},
    ],
    argtypes_factory=_maxpool2d_f16_argtypes,
)


CONV2D_F16 = KernelSpec(
    op="conv2d_f16",
    signature=(
        "void kernel_conv2d_f16(const _Float16 *input, const _Float16 *weight, "
        "const _Float16 *bias, _Float16 *output, "
        "int N, int IC, int IH, int IW, int OC, "
        "int KH, int KW, int SH, int SW, int PH, int PW)"
    ),
    semantics=(
        "Half-precision 2D convolution. groups=1, dilation=1.\n"
        "Storage is _Float16 for input/weight/bias/output, but the inner\n"
        "accumulator is fp32 to avoid catastrophic cancellation when summing\n"
        "many partial products — same pattern as Tensor Cores and what\n"
        "torch.float16 conv2d does on CPU. The accumulator is cast back to\n"
        "_Float16 only at the final store."
    ),
    reference_impl="""\
void kernel_conv2d_f16(const _Float16 *input, const _Float16 *weight,
                       const _Float16 *bias, _Float16 *output,
                       int N, int IC, int IH, int IW, int OC,
                       int KH, int KW, int SH, int SW, int PH, int PW) {
    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;
    for (int n = 0; n < N; n++) {
        for (int oc = 0; oc < OC; oc++) {
            for (int oh = 0; oh < OH; oh++) {
                for (int ow = 0; ow < OW; ow++) {
                    float acc = bias ? (float)bias[oc] : 0.0f;
                    for (int ic = 0; ic < IC; ic++) {
                        for (int kh = 0; kh < KH; kh++) {
                            int ih = oh * SH - PH + kh;
                            if (ih < 0 || ih >= IH) continue;
                            for (int kw = 0; kw < KW; kw++) {
                                int iw = ow * SW - PW + kw;
                                if (iw < 0 || iw >= IW) continue;
                                float v = (float)input[((n*IC + ic)*IH + ih)*IW + iw];
                                float w = (float)weight[((oc*IC + ic)*KH + kh)*KW + kw];
                                acc += v * w;
                            }
                        }
                    }
                    output[((n*OC + oc)*OH + oh)*OW + ow] = (_Float16)acc;
                }
            }
        }
    }
}
""",
    extra_shapes=[
        # LeNet-shape, KernelBench 63
        {"N": 1, "IC": 3, "IH": 16, "IW": 16, "OC": 4,
         "KH": 3, "KW": 3, "SH": 1, "SW": 1, "PH": 0, "PW": 0},
    ],
    argtypes_factory=_conv2d_f16_argtypes,
    algorithms=[
        AlgorithmCandidate(
            name="widening",
            target_affinity=("rvv_f16",),
            description=(
                "RVV+Zvfh fp16 conv2d with vfwmacc IC-vectorized "
                "reduction. The scalar reference iterates 6 nested loops "
                "(n, oc, oh, ow, kh, kw) with an innermost IC scalar MAC "
                "loop. Vectorize that innermost IC reduction: each lane "
                "consumes one (ic, kh, kw) tap, the fp32 accumulator "
                "stays in LMUL=4 across iterations, and one vfredusum "
                "at the end folds it into the scalar that gets cast to "
                "fp16 + biased.\n\n"
                "The IC tap and the weight tap are both strided across "
                "IC (input stride = IH*IW per IC element, weight stride "
                "= KH*KW per IC element with OIHW layout), so we use "
                "vlse16. Strided fp16 loads are slower than unit-stride "
                "on V256 but still better than scalar MAC chains for the "
                "IC=32..480 reductions common in EfficientNet MBConvs.\n\n"
                "ALGORITHM:\n"
                "  for each (n, oc, oh, ow):\n"
                "    vacc = vfmv.v.f f32m4(0)  // fp32 accumulator\n"
                "    for kh, kw (with padding bounds check):\n"
                "      for ic_base in [0, IC) step vl=vsetvl(e16m2, IC-ic_base):\n"
                "        va = vlse16 f16m2(input, IH*IW*2, vl)\n"
                "        vb = vlse16 f16m2(weight, KH*KW*2, vl)\n"
                "        vacc = vfwmacc.vv(vacc, va, vb, vl)\n"
                "    acc = vfredusum(vacc, bias[oc])\n"
                "    output[...] = (_Float16)acc\n"
            ),
            reference_impl="""\
#include <stddef.h>
#include <riscv_vector.h>

void kernel_conv2d_f16(const _Float16 *input, const _Float16 *weight,
                       const _Float16 *bias, _Float16 *output,
                       int N, int IC, int IH, int IW, int OC,
                       int KH, int KW, int SH, int SW, int PH, int PW)
{
    const int OH = (IH + 2*PH - KH) / SH + 1;
    const int OW = (IW + 2*PW - KW) / SW + 1;
    const size_t vlmax_e32m4 = __riscv_vsetvlmax_e32m4();
    const ptrdiff_t in_ic_stride_bytes = (ptrdiff_t)IH * IW * sizeof(_Float16);
    const ptrdiff_t w_ic_stride_bytes  = (ptrdiff_t)KH * KW * sizeof(_Float16);
    for (int n = 0; n < N; n++) {
        for (int oc = 0; oc < OC; oc++) {
            const _Float16 *w_oc = weight + (size_t)oc * IC * KH * KW;
            for (int oh = 0; oh < OH; oh++) {
                for (int ow = 0; ow < OW; ow++) {
                    vfloat32m4_t vacc = __riscv_vfmv_v_f_f32m4(0.0f, vlmax_e32m4);
                    for (int kh = 0; kh < KH; kh++) {
                        int ih = oh*SH - PH + kh;
                        if (ih < 0 || ih >= IH) continue;
                        for (int kw = 0; kw < KW; kw++) {
                            int iw = ow*SW - PW + kw;
                            if (iw < 0 || iw >= IW) continue;
                            const _Float16 *in_base = input + ((size_t)n * IC * IH + ih) * IW + iw;
                            const _Float16 *w_base  = w_oc + (size_t)kh * KW + kw;
                            int ic = 0;
                            while (ic < IC) {
                                size_t vl = __riscv_vsetvl_e16m2((size_t)(IC - ic));
                                vfloat16m2_t va = __riscv_vlse16_v_f16m2(
                                    in_base + (size_t)ic * IH * IW, in_ic_stride_bytes, vl);
                                vfloat16m2_t vb = __riscv_vlse16_v_f16m2(
                                    w_base  + (size_t)ic * KH * KW, w_ic_stride_bytes, vl);
                                vacc = __riscv_vfwmacc_vv_f32m4(vacc, va, vb, vl);
                                ic += (int)vl;
                            }
                        }
                    }
                    float seed = bias ? (float)bias[oc] : 0.0f;
                    vfloat32m1_t vsum0 = __riscv_vfmv_v_f_f32m1(seed, 1);
                    vfloat32m1_t vred  = __riscv_vfredusum_vs_f32m4_f32m1(vacc, vsum0, vlmax_e32m4);
                    float acc = __riscv_vfmv_f_s_f32m1_f32(vred);
                    output[((size_t)n * OC + oc) * OH * OW + (size_t)oh * OW + ow] = (_Float16)acc;
                }
            }
        }
    }
}
""",
        ),
        AlgorithmCandidate(
            name="oc_blocked",
            target_affinity=("rvv_f16",),
            description=(
                "OC-parallel conv2d_f16. Vectorize over OC (each lane "
                "carries one output channel of the current output pixel); "
                "scalar-loop the (ic, kh, kw) reduction. Trades the "
                "widening kernel's strided fp16 input load (slow on V256 "
                "Saturn when IH*IW is small) for unit-stride scalar input "
                "+ strided weight. Useful for layers with tiny spatial "
                "dim (1×1 convs in EfficientNet MBConv expand/project) "
                "where the strided-by-IH*IW input load gathers from "
                "scattered addresses. Numerics equivalent to the widening "
                "kernel modulo summation order (fp32 accumulator both "
                "paths). Registered as the second candidate so 'widening' "
                "stays the default; pick this via --algorithms=oc_blocked "
                "or via the LLM optimize loop's FireSim re-rank."
            ),
            reference_impl="",  # curated file supplies the impl
        ),
    ],
)


# ---------------------------------------------------------------------------
# Mixed-precision cast kernels — i8↔f16 boundaries inserted by the
# walker's auto-cast pass when a fp16 op consumes an int8-produced
# tensor (or vice versa). Scale is the int8 tensor's per-tensor scale
# (precomputed at calibration time). See modelblaster/notes/mixed_precision_plan.md.
# ---------------------------------------------------------------------------

def _cast_i8_to_f16_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    h = ctypes.POINTER(ctypes.c_uint16)
    return [i8p, h, ctypes.c_int, ctypes.c_float]


CAST_I8_TO_F16 = KernelSpec(
    op="cast_i8_to_f16",
    signature=(
        "void kernel_cast_i8_to_f16(const int8_t *in, _Float16 *out, "
        "int n, float scale)"
    ),
    semantics=(
        "Dequantize an int8 tensor to _Float16:\n"
        "  out[i] = (_Float16)((float)in[i] * scale)\n"
        "Where `scale` is the int8 tensor's per-tensor symmetric scale\n"
        "(zero-point = 0). Inserted by the walker's auto-cast pass at\n"
        "i8 → f16 dtype boundaries when a fp16 op consumes an int8 producer."
    ),
    reference_impl="""\
void kernel_cast_i8_to_f16(const int8_t *in, _Float16 *out,
                           int n, float scale) {
    for (int i = 0; i < n; i++) {
        out[i] = (_Float16)((float)in[i] * scale);
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 256}, {"n": 4096}],
    argtypes_factory=_cast_i8_to_f16_argtypes,
)


def _cast_f16_to_i8_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    i8p = ctypes.POINTER(ctypes.c_int8)
    return [h, i8p, ctypes.c_int, ctypes.c_float]


CAST_F16_TO_I8 = KernelSpec(
    op="cast_f16_to_i8",
    signature=(
        "void kernel_cast_f16_to_i8(const _Float16 *in, int8_t *out, "
        "int n, float inv_scale)"
    ),
    semantics=(
        "Quantize a _Float16 tensor to int8 (per-tensor symmetric):\n"
        "  q = round((float)in[i] * inv_scale)\n"
        "  out[i] = clamp(q, -128, 127)\n"
        "Where `inv_scale = 1.0 / scale` and `scale` is the destination\n"
        "int8 tensor's per-tensor scale (precomputed at calibration time\n"
        "from the fp32 reference). Inserted by the walker's auto-cast\n"
        "pass at f16 → i8 dtype boundaries."
    ),
    reference_impl="""\
#include <stdint.h>

void kernel_cast_f16_to_i8(const _Float16 *in, int8_t *out,
                           int n, float inv_scale) {
    for (int i = 0; i < n; i++) {
        float v = (float)in[i] * inv_scale;
        int32_t q = (int32_t)(v >= 0.0f ? v + 0.5f : v - 0.5f);
        if (q > 127)  q = 127;
        if (q < -128) q = -128;
        out[i] = (int8_t)q;
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 256}, {"n": 4096}],
    argtypes_factory=_cast_f16_to_i8_argtypes,
)


# ---------------------------------------------------------------------------
# ViNT fp16 op set. Same dataflow as the corresponding fp32 ops; storage
# is _Float16. For accumulating ops (matmul / conv / layer_norm reduction)
# the inner accumulator is fp32 to avoid fp16-precision drift, matching
# what torch.float16 does on CPU and what Tensor Cores do in hardware.
# Transcendentals (gelu, softmax) round-trip through float for the math
# kernel since libm has no half-precision expf/erf yet.
# ---------------------------------------------------------------------------

def _linear_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, h, h, ctypes.c_int, ctypes.c_int, ctypes.c_int]


LINEAR_F16 = KernelSpec(
    op="linear_f16",
    signature=(
        "void kernel_linear_f16(const _Float16 *input, const _Float16 *weight, "
        "const _Float16 *bias, _Float16 *output, int M, int K, int N)"
    ),
    semantics=(
        "Half-precision fully-connected (matmul + bias), nn.Linear semantics:\n"
        "  output[m, n] = bias[n] + sum_k input[m, k] * weight[n, k]\n"
        "Shapes (row-major):\n"
        "  input:  [M, K]   weight: [N, K]   bias: [N] (may be NULL)\n"
        "  output: [M, N]\n"
        "All tensors are _Float16; the inner accumulator is fp32."
    ),
    reference_impl="""\
void kernel_linear_f16(const _Float16 *input, const _Float16 *weight,
                       const _Float16 *bias, _Float16 *output,
                       int M, int K, int N) {
    for (int m = 0; m < M; m++) {
        for (int n = 0; n < N; n++) {
            float acc = bias ? (float)bias[n] : 0.0f;
            for (int k = 0; k < K; k++) {
                acc += (float)input[m * K + k] * (float)weight[n * K + k];
            }
            output[m * N + n] = (_Float16)acc;
        }
    }
}
""",
    extra_shapes=[
        {"M": 1, "K": 1, "N": 1},
        {"M": 1, "K": 7, "N": 13},
        {"M": 4, "K": 17, "N": 23},
        {"M": 1, "K": 64, "N": 64},
        # Production shapes (fused_full's fp16 tail, kernel_opt_log 1000+):
        # every prior shape had K,N <= 64, far under a single LMUL4 register
        # group (vlmax_e16m4 = 64 @ VLEN=256) and under the N-blocking width
        # (4) any curated kernel would tile by -- none of them exercised
        # multi-chunk K reduction or an N%4 tail at production scale. These
        # three are fused_full's actual vision_fc / depth_fc / head calls.
        {"M": 1, "K": 1536, "N": 512},   # vision_fc: 1536->512 (multi-chunk K, N%4==0)
        {"M": 1, "K": 1024, "N": 64},    # depth_fc: 1024->64 (multi-chunk K, N%4==0)
        {"M": 1, "K": 128, "N": 2},      # head: 128->2 (N<4, exercises the tail-only path)
    ],
    argtypes_factory=_linear_f16_argtypes,
    algorithms=[
        AlgorithmCandidate(
            name="narrow",
            target_affinity=("rvv_f16",),
            description=(
                "RVV+Zvfh fp16 linear with PURE-fp16 accumulation (no fp32). "
                "Identical to 'widening' but the K-reduction uses vfmacc_vv_f16 "
                "(fp16 multiply-accumulate) + vfredusum_vs_f16, keeping the whole "
                "vector datapath at SEW=16 — NO vfwmacc / fp32 accumulator. This is "
                "the DEFAULT for rvv_f16 because it runs on BOTH full-zvfh AND a "
                "reduced fp16-only vector unit (the FPGA drone target has no LUT "
                "area for an fp32 vector ALU); 'widening' below needs the fp32 "
                "datapath. Divergence from the reference is reduction ORDER only "
                "(fp16 non-associative) -> numeric_drift; the fp16 accumulate also "
                "matches the deployment hardware exactly.\n"
            ),
            reference_impl="""\
#include <stddef.h>
#include <riscv_vector.h>

void kernel_linear_f16(const _Float16 *input, const _Float16 *weight,
                       const _Float16 *bias, _Float16 *output,
                       int M, int K, int N) {
    const size_t vlmax = __riscv_vsetvlmax_e16m4();
    for (int m = 0; m < M; m++) {
        const _Float16 *in_row = input + (size_t)m * (size_t)K;
        for (int n = 0; n < N; n++) {
            const _Float16 *w_row = weight + (size_t)n * (size_t)K;
            vfloat16m4_t vacc = __riscv_vfmv_v_f_f16m4((_Float16)0.0f, vlmax);
            int k = 0;
            size_t vl;
            for (; k < K; k += (int)vl) {
                vl = __riscv_vsetvl_e16m4(K - k);
                vfloat16m4_t va = __riscv_vle16_v_f16m4(in_row + k, vl);
                vfloat16m4_t vb = __riscv_vle16_v_f16m4(w_row + k, vl);
                vacc = __riscv_vfmacc_vv_f16m4(vacc, va, vb, vl);
            }
            vfloat16m1_t vs = __riscv_vfmv_s_f_f16m1((_Float16)0.0f, 1);
            vs = __riscv_vfredusum_vs_f16m4_f16m1(vacc, vs, vlmax);
            _Float16 acc = __riscv_vfmv_f_s_f16m1_f16(vs);
            if (bias) acc = (_Float16)(acc + bias[n]);
            output[(size_t)m * N + n] = acc;
        }
    }
}
""",
        ),
        AlgorithmCandidate(
            name="widening",
            target_affinity=("rvv_f16",),
            description=(
                "RVV+Zvfh widening fp16 MAC. The reference impl reads a "
                "scalar fp32 accumulator across K iterations of\n"
                "  acc += (float)input[m*K+k] * (float)weight[n*K+k];\n"
                "and casts to fp16 at the final store. Vectorize that "
                "inner K-loop with vfwmacc: each lane consumes one fp16 "
                "input + one fp16 weight, widens the product to fp32, "
                "and accumulates into a fp32 LMUL=4 vector. After the "
                "loop, vfredusum reduces the vector to a scalar (sum "
                "order differs from the scalar impl, but both keep fp32 "
                "precision so the result agrees with the reference within "
                "~1 ulp at the final fp16 cast).\n\n"
                "WHY THIS HELPS:\n"
                "  The reference impl is 5+ instructions per MAC on RVV "
                "scalar (two fp16 loads, two fcvt.s.h, one fmul.s, one "
                "fadd.s). vfwmacc.vv collapses load+widen+mul+add into "
                "one vector instruction operating on vlmax_e16m2 lanes "
                "per iteration. For ViNT's typical linear (M=1, K=512, "
                "N=512), the inner-K loop drops from 512 scalar MACs to "
                "~16 vector iterations on a V256 implementation.\n\n"
                "ALGORITHM:\n"
                "  for each (m, n):\n"
                "    vacc = vfmv.v.f f32m4(0)\n"
                "    for k_base in [0, K) step vl=vsetvl(e16m2, K-k_base):\n"
                "      va = vle16.v f16m2(input + m*K + k_base, vl)\n"
                "      vb = vle16.v f16m2(weight + n*K + k_base, vl)\n"
                "      vacc = vfwmacc.vv f32m4(vacc, va, vb, vl)\n"
                "    acc = vfredusum(vacc) + (bias ? bias[n] : 0)\n"
                "    output[m*N+n] = (_Float16)acc\n"
            ),
            reference_impl="""\
#include <riscv_vector.h>

void kernel_linear_f16(const _Float16 *input, const _Float16 *weight,
                       const _Float16 *bias, _Float16 *output,
                       int M, int K, int N) {
    const size_t vlmax_e32m4 = __riscv_vsetvlmax_e32m4();
    for (int m = 0; m < M; m++) {
        const _Float16 *in_row = input + (size_t)m * (size_t)K;
        for (int n = 0; n < N; n++) {
            const _Float16 *w_row = weight + (size_t)n * (size_t)K;
            vfloat32m4_t vacc = __riscv_vfmv_v_f_f32m4(0.0f, vlmax_e32m4);
            int k = 0;
            while (k < K) {
                size_t vl = __riscv_vsetvl_e16m2((size_t)(K - k));
                vfloat16m2_t va = __riscv_vle16_v_f16m2(in_row + k, vl);
                vfloat16m2_t vb = __riscv_vle16_v_f16m2(w_row  + k, vl);
                vacc = __riscv_vfwmacc_vv_f32m4(vacc, va, vb, vl);
                k += (int)vl;
            }
            vfloat32m1_t vsum0 = __riscv_vfmv_v_f_f32m1(0.0f, 1);
            vfloat32m1_t vred  = __riscv_vfredusum_vs_f32m4_f32m1(
                vacc, vsum0, vlmax_e32m4);
            float acc = __riscv_vfmv_f_s_f32m1_f32(vred);
            if (bias) acc += (float)bias[n];
            output[(size_t)m * (size_t)N + (size_t)n] = (_Float16)acc;
        }
    }
}
""",
        ),
    ],
)


def _depthwise_conv2d_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, h, h] + [ctypes.c_int] * 12


DEPTHWISE_CONV2D_F16 = KernelSpec(
    op="depthwise_conv2d_f16",
    signature=(
        "void kernel_depthwise_conv2d_f16(const _Float16 *input, "
        "const _Float16 *weight, const _Float16 *bias, _Float16 *output, "
        "int N, int IC, int IH, int IW, int OC, "
        "int KH, int KW, int SH, int SW, int PH, int PW)"
    ),
    semantics=(
        "Half-precision depthwise 2D convolution. groups == OC == IC, so each\n"
        "output channel reads from exactly one input channel via its own\n"
        "(1, KH, KW) filter. Storage _Float16; inner accumulator fp32."
    ),
    reference_impl="""\
void kernel_depthwise_conv2d_f16(const _Float16 *input, const _Float16 *weight,
                                 const _Float16 *bias, _Float16 *output,
                                 int N, int IC, int IH, int IW, int OC,
                                 int KH, int KW, int SH, int SW, int PH, int PW) {
    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;
    for (int n = 0; n < N; n++) {
        for (int oc = 0; oc < OC; oc++) {
            for (int oh = 0; oh < OH; oh++) {
                for (int ow = 0; ow < OW; ow++) {
                    float acc = bias ? (float)bias[oc] : 0.0f;
                    for (int kh = 0; kh < KH; kh++) {
                        int ih = oh*SH - PH + kh;
                        if (ih < 0 || ih >= IH) continue;
                        for (int kw = 0; kw < KW; kw++) {
                            int iw = ow*SW - PW + kw;
                            if (iw < 0 || iw >= IW) continue;
                            float v = (float)input[((n*OC + oc)*IH + ih)*IW + iw];
                            float w = (float)weight[((oc*KH) + kh)*KW + kw];
                            acc += v * w;
                        }
                    }
                    output[((n*OC + oc)*OH + oh)*OW + ow] = (_Float16)acc;
                }
            }
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "IC": 16, "IH": 8, "IW": 8, "OC": 16,
         "KH": 3, "KW": 3, "SH": 1, "SW": 1, "PH": 1, "PW": 1},
    ],
    argtypes_factory=_depthwise_conv2d_f16_argtypes,
    algorithms=[
        AlgorithmCandidate(
            name="oc_vec",
            target_affinity=("rvv_f16",),
            description=(
                "RVV+Zvfh depthwise conv2d, vectorize across OC channels.\n\n"
                "WHY THIS HELPS:\n"
                "  Depthwise has no IC reduction — each output channel "
                "reads from exactly one input channel via its own (1, KH, "
                "KW) filter. Vectorizing the IC dim (what conv2d_f16's "
                "widening does) would give vl=1; instead we vectorize "
                "across OC, with each lane handling one channel's "
                "(kh, kw) accumulation independently. No vfredusum at "
                "the end — each lane's accumulator is already that "
                "channel's output.\n\n"
                "MEMORY ACCESS:\n"
                "  input  [n, oc:oc+vl, ih, iw]:  stride IH*IW per OC\n"
                "  weight [oc:oc+vl, 0, kh, kw]:  stride KH*KW per OC\n"
                "  output [n, oc:oc+vl, oh, ow]:  stride OH*OW per OC\n"
                "All three use vlse16/vsse16 (strided). For EfficientNet "
                "depthwise (OC=32..1152, KH=KW=3 or 5), the inner per-OC "
                "compute over 9..25 (kh, kw) taps gets folded into "
                "vlmax_e16m2-wide vector ops vs the scalar reference's "
                "9..25 scalar MACs * OC iterations.\n\n"
                "ALGORITHM:\n"
                "  for n, oh, ow:\n"
                "    for oc_base in [0, OC) step vl=vsetvl(e16m2, OC-oc_base):\n"
                "      vacc = vfwcvt(vle16(bias + oc_base, vl))  // fp32 m4\n"
                "      for kh, kw (with padding bounds check):\n"
                "        va = vlse16(input ..., IH*IW*2, vl)\n"
                "        vw = vlse16(weight ..., KH*KW*2, vl)\n"
                "        vacc = vfwmacc.vv(vacc, va, vw, vl)\n"
                "      vsse16(output, OH*OW*2, vfncvt(vacc), vl)\n"
            ),
            reference_impl="""\
#include <stddef.h>
#include <riscv_vector.h>

void kernel_depthwise_conv2d_f16(const _Float16 *input, const _Float16 *weight,
                                 const _Float16 *bias, _Float16 *output,
                                 int N, int IC, int IH, int IW, int OC,
                                 int KH, int KW, int SH, int SW,
                                 int PH, int PW)
{
    (void)IC;
    const int OH = (IH + 2*PH - KH) / SH + 1;
    const int OW = (IW + 2*PW - KW) / SW + 1;
    const ptrdiff_t in_c_stride_bytes  = (ptrdiff_t)IH * IW * sizeof(_Float16);
    const ptrdiff_t w_c_stride_bytes   = (ptrdiff_t)KH * KW * sizeof(_Float16);
    const ptrdiff_t out_c_stride_bytes = (ptrdiff_t)OH * OW * sizeof(_Float16);
    for (int n = 0; n < N; n++) {
        for (int oh = 0; oh < OH; oh++) {
            for (int ow = 0; ow < OW; ow++) {
                int oc_base = 0;
                while (oc_base < OC) {
                    size_t vl = __riscv_vsetvl_e16m2((size_t)(OC - oc_base));
                    vfloat32m4_t vacc;
                    if (bias != NULL) {
                        vfloat16m2_t vb16 = __riscv_vle16_v_f16m2(bias + oc_base, vl);
                        vacc = __riscv_vfwcvt_f_f_v_f32m4(vb16, vl);
                    } else {
                        vacc = __riscv_vfmv_v_f_f32m4(0.0f, vl);
                    }
                    for (int kh = 0; kh < KH; kh++) {
                        int ih = oh * SH - PH + kh;
                        if (ih < 0 || ih >= IH) continue;
                        for (int kw = 0; kw < KW; kw++) {
                            int iw = ow * SW - PW + kw;
                            if (iw < 0 || iw >= IW) continue;
                            const _Float16 *in_p = input
                                + ((size_t)n * OC + oc_base) * IH * IW
                                + (size_t)ih * IW + iw;
                            vfloat16m2_t va = __riscv_vlse16_v_f16m2(
                                in_p, in_c_stride_bytes, vl);
                            const _Float16 *w_p = weight
                                + (size_t)oc_base * KH * KW
                                + (size_t)kh * KW + kw;
                            vfloat16m2_t vw = __riscv_vlse16_v_f16m2(
                                w_p, w_c_stride_bytes, vl);
                            vacc = __riscv_vfwmacc_vv_f32m4(vacc, va, vw, vl);
                        }
                    }
                    vfloat16m2_t vout = __riscv_vfncvt_f_f_w_f16m2(vacc, vl);
                    _Float16 *out_p = output
                        + ((size_t)n * OC + oc_base) * OH * OW
                        + (size_t)oh * OW + ow;
                    __riscv_vsse16_v_f16m2(out_p, out_c_stride_bytes, vout, vl);
                    oc_base += (int)vl;
                }
            }
        }
    }
}
""",
        ),
    ],
)


def _layer_norm_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, h, h, ctypes.c_int, ctypes.c_int, ctypes.c_float]


LAYER_NORM_F16 = KernelSpec(
    op="layer_norm_f16",
    signature=(
        "void kernel_layer_norm_f16(const _Float16 *input, "
        "const _Float16 *gamma, const _Float16 *beta, _Float16 *output, "
        "int M, int K, float eps)"
    ),
    semantics=(
        "Half-precision LayerNorm over the last axis of an [M, K] tensor:\n"
        "  mu     = mean(input[m, :])\n"
        "  sigma  = sqrt(var(input[m, :]) + eps)\n"
        "  output[m, k] = gamma[k] * (input[m, k] - mu) / sigma + beta[k]\n"
        "Mean/variance computed in fp32, applied + stored as _Float16. gamma\n"
        "and beta are _Float16 buffers of length K."
    ),
    reference_impl="""\
#include <math.h>

void kernel_layer_norm_f16(const _Float16 *input, const _Float16 *gamma,
                           const _Float16 *beta, _Float16 *output,
                           int M, int K, float eps) {
    for (int m = 0; m < M; m++) {
        float sum = 0.0f, sqsum = 0.0f;
        for (int k = 0; k < K; k++) {
            float v = (float)input[m*K + k];
            sum += v;
            sqsum += v * v;
        }
        float mean = sum / (float)K;
        float var  = sqsum / (float)K - mean * mean;
        float inv_sigma = 1.0f / sqrtf(var + eps);
        for (int k = 0; k < K; k++) {
            float v = (float)input[m*K + k];
            float g = (float)gamma[k];
            float b = (float)beta[k];
            output[m*K + k] = (_Float16)(g * (v - mean) * inv_sigma + b);
        }
    }
}
""",
    extra_shapes=[
        {"M": 1, "K": 16, "eps": 1e-5},
        {"M": 7, "K": 512, "eps": 1e-5},
    ],
    argtypes_factory=_layer_norm_f16_argtypes,
)


GELU_F16 = KernelSpec(
    op="gelu_f16",
    signature="void kernel_gelu_f16(const _Float16 *input, _Float16 *output, int n)",
    semantics=(
        "Half-precision GELU (PyTorch's 'tanh' approximation):\n"
        "  output[i] = 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))\n"
        "Math is done in fp32, result cast to _Float16."
    ),
    reference_impl="""\
#include <math.h>

void kernel_gelu_f16(const _Float16 *input, _Float16 *output, int n) {
    const float SQRT_2_OVER_PI = 0.7978845608028654f;  /* sqrt(2/pi) */
    for (int i = 0; i < n; i++) {
        float x = (float)input[i];
        float x3 = x * x * x;
        float arg = SQRT_2_OVER_PI * (x + 0.044715f * x3);
        float r = 0.5f * x * (1.0f + tanhf(arg));
        output[i] = (_Float16)r;
    }
}
""",
    extra_shapes=[{"n": 17}, {"n": 1024}, {"n": 14336}],
    argtypes_factory=_pointwise_f16_argtypes,
)


def _softmax_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, ctypes.c_int, ctypes.c_int, ctypes.c_float]


SOFTMAX_F16 = KernelSpec(
    op="softmax_f16",
    signature=(
        "void kernel_softmax_f16(const _Float16 *input, _Float16 *output, "
        "int M, int K, float input_scale)"
    ),
    semantics=(
        "Half-precision softmax over the last axis of an [M, K] tensor with\n"
        "a fused input scale (used by SDPA to absorb 1/√d_k without an extra\n"
        "pointwise pass):\n"
        "  x_k  = input[m, k] * input_scale\n"
        "  m_i  = max(x_:)\n"
        "  e    = exp(x_k - m_i)\n"
        "  output[m, k] = e / sum(e)\n"
        "input_scale == 1.0 disables the pre-multiply. Math in fp32 (no fp16\n"
        "expf), result cast to _Float16."
    ),
    reference_impl="""\
#include <math.h>

void kernel_softmax_f16(const _Float16 *input, _Float16 *output,
                        int M, int K, float input_scale) {
    for (int m = 0; m < M; m++) {
        float maxv = -65504.0f;
        for (int k = 0; k < K; k++) {
            float v = (float)input[m*K + k] * input_scale;
            if (v > maxv) maxv = v;
        }
        float sum = 0.0f;
        for (int k = 0; k < K; k++) {
            float v = (float)input[m*K + k] * input_scale;
            float e = expf(v - maxv);
            output[m*K + k] = (_Float16)e;
            sum += e;
        }
        float inv_sum = 1.0f / sum;
        for (int k = 0; k < K; k++) {
            output[m*K + k] = (_Float16)((float)output[m*K + k] * inv_sum);
        }
    }
}
""",
    extra_shapes=[{"M": 1, "K": 7, "input_scale": 1.0},
                  {"M": 7, "K": 7, "input_scale": 0.0883883476}],  # 1/√128
    argtypes_factory=_softmax_f16_argtypes,
)


def _pointwise2_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, h, ctypes.c_int]


ADD_F16 = KernelSpec(
    op="add_f16",
    signature=(
        "void kernel_add_f16(const _Float16 *a, const _Float16 *b, "
        "_Float16 *output, int n)"
    ),
    semantics=(
        "Half-precision elementwise add:\n"
        "  output[i] = a[i] + b[i]\n"
        "Addition is in fp32 (to dodge subnormal denormals), result cast back."
    ),
    reference_impl="""\
void kernel_add_f16(const _Float16 *a, const _Float16 *b,
                    _Float16 *output, int n) {
    for (int i = 0; i < n; i++) {
        output[i] = (_Float16)((float)a[i] + (float)b[i]);
    }
}
""",
    extra_shapes=[{"n": 16}, {"n": 3584}],
    argtypes_factory=_pointwise2_f16_argtypes,
)


MUL_F16 = KernelSpec(
    op="mul_f16",
    signature=(
        "void kernel_mul_f16(const _Float16 *a, const _Float16 *b, "
        "_Float16 *output, int n)"
    ),
    semantics=(
        "Half-precision elementwise multiply:\n"
        "  output[i] = a[i] * b[i]\n"
        "Multiply in fp32, result cast to _Float16."
    ),
    reference_impl="""\
void kernel_mul_f16(const _Float16 *a, const _Float16 *b,
                    _Float16 *output, int n) {
    for (int i = 0; i < n; i++) {
        output[i] = (_Float16)((float)a[i] * (float)b[i]);
    }
}
""",
    extra_shapes=[{"n": 16}, {"n": 1024}],
    argtypes_factory=_pointwise2_f16_argtypes,
)


def _mul_c1_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, h, ctypes.c_int, ctypes.c_int, ctypes.c_int]


MUL_C1_F16 = KernelSpec(
    op="mul_c1_f16",
    signature=(
        "void kernel_mul_c1_f16(const _Float16 *gate, const _Float16 *x, "
        "_Float16 *output, int N, int C, int HW)"
    ),
    semantics=(
        "Half-precision channel-axis broadcast multiply (EfficientNet SE):\n"
        "  output[n, c, h, w] = gate[c] * x[n, c, h, w]\n"
        "where `gate` has shape [1, C, 1, 1] (= C contiguous values) and\n"
        "`x` has shape [N, C, HW]. Without broadcast support, the elementwise\n"
        "mul_f16 reads past the end of the gate buffer (32 channels of gate\n"
        "vs 32*H*W of x) — that was the cause of the SE-block magnitude blow-up\n"
        "in the fp16 ViNT path. Math in fp32, result cast to _Float16."
    ),
    reference_impl="""\
void kernel_mul_c1_f16(const _Float16 *gate, const _Float16 *x,
                       _Float16 *output, int N, int C, int HW) {
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            float g = (float)gate[c];
            for (int i = 0; i < HW; i++) {
                int idx = (n*C + c)*HW + i;
                output[idx] = (_Float16)(g * (float)x[idx]);
            }
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "C": 32, "HW": 32*42},
        {"N": 1, "C": 1152, "HW": 4*5},
    ],
    argtypes_factory=_mul_c1_f16_argtypes,
)


MUL_C1_S8 = KernelSpec(
    op="mul_c1_s8",
    signature=(
        "void kernel_mul_c1_s8(const int8_t *gate, const int8_t *x, "
        "int8_t *output, int N, int C, int HW, "
        "float scale_gate, float scale_x, float scale_out)"
    ),
    semantics=(
        "Int8 channel-axis broadcast multiply (EfficientNet SE):\n"
        "  output[n, c, h, w] = round(\n"
        "    scale_gate * gate[c] * scale_x * x[n, c, h, w] / scale_out)\n"
        "Output clipped to [-128, 127]. Math is int32 accumulator → fp32\n"
        "scale → int8 store, same pattern as mul_s8 but with the gate\n"
        "broadcast across the H*W axis."
    ),
    reference_impl="""\
#include <stdint.h>

static int32_t _mul_c1_s8_round(float v) {
    int32_t i = (int32_t)(v >= 0.0f ? v + 0.5f : v - 0.5f);
    if (i < -128) i = -128;
    if (i > 127)  i = 127;
    return i;
}

void kernel_mul_c1_s8(const int8_t *gate, const int8_t *x, int8_t *output,
                      int N, int C, int HW,
                      float scale_gate, float scale_x, float scale_out) {
    float k = (scale_gate * scale_x) / scale_out;
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            float g_real = (float)gate[c] * scale_gate;
            for (int i = 0; i < HW; i++) {
                int idx = (n*C + c)*HW + i;
                float prod = g_real * ((float)x[idx] * scale_x);
                output[idx] = (int8_t)_mul_c1_s8_round(prod / scale_out);
            }
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "C": 32, "HW": 32*42,
         "scale_gate": 1.0/127.0, "scale_x": 0.08, "scale_out": 0.08},
    ],
    argtypes_factory=_pointwise2_f16_argtypes,  # placeholder; host-verify disabled
)


def _adaptive_avg_pool2d_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h] + [ctypes.c_int] * 6


ADAPTIVE_AVG_POOL2D_F16 = KernelSpec(
    op="adaptive_avg_pool2d_f16",
    signature=(
        "void kernel_adaptive_avg_pool2d_f16(const _Float16 *input, "
        "_Float16 *output, int N, int C, int IH, int IW, int OH, int OW)"
    ),
    semantics=(
        "Half-precision adaptive average pool: for each output position\n"
        "(oh, ow), compute the average of the input window mapped from\n"
        "torch.nn.AdaptiveAvgPool2d's index arithmetic:\n"
        "  h_start = floor(oh * IH / OH); h_end = ceil((oh+1) * IH / OH);\n"
        "  similarly for w. Average is fp32, cast to _Float16 at store."
    ),
    reference_impl="""\
void kernel_adaptive_avg_pool2d_f16(const _Float16 *input, _Float16 *output,
                                    int N, int C, int IH, int IW,
                                    int OH, int OW) {
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            for (int oh = 0; oh < OH; oh++) {
                int h_start = (oh * IH) / OH;
                int h_end   = ((oh + 1) * IH + OH - 1) / OH;
                for (int ow = 0; ow < OW; ow++) {
                    int w_start = (ow * IW) / OW;
                    int w_end   = ((ow + 1) * IW + OW - 1) / OW;
                    float sum = 0.0f;
                    int cnt = 0;
                    for (int h = h_start; h < h_end; h++) {
                        for (int w = w_start; w < w_end; w++) {
                            sum += (float)input[((n*C + c)*IH + h)*IW + w];
                            cnt++;
                        }
                    }
                    output[((n*C + c)*OH + oh)*OW + ow] =
                        (_Float16)(sum / (float)(cnt > 0 ? cnt : 1));
                }
            }
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "C": 4, "IH": 8, "IW": 8, "OH": 1, "OW": 1},
        {"N": 1, "C": 64, "IH": 7, "IW": 7, "OH": 1, "OW": 1},
    ],
    argtypes_factory=_adaptive_avg_pool2d_f16_argtypes,
)


def _slice_c_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h] + [ctypes.c_int] * 6


SLICE_C_F16 = KernelSpec(
    op="slice_c_f16",
    signature=(
        "void kernel_slice_c_f16(const _Float16 *input, _Float16 *output, "
        "int N, int IC, int C_start, int C_end, int H, int W)"
    ),
    semantics=(
        "Half-precision channel-axis slice of a [N, IC, H, W] tensor:\n"
        "  output[n, oc, h, w] = input[n, C_start + oc, h, w]\n"
        "  where oc in [0, C_end - C_start).\n"
        "Pure copy (no math)."
    ),
    reference_impl="""\
#include <string.h>

void kernel_slice_c_f16(const _Float16 *input, _Float16 *output,
                        int N, int IC, int C_start, int C_end,
                        int H, int W) {
    int OC = C_end - C_start;
    for (int n = 0; n < N; n++) {
        for (int oc = 0; oc < OC; oc++) {
            int ic = C_start + oc;
            const _Float16 *src = input + ((n*IC + ic)*H*W);
            _Float16 *dst = output + ((n*OC + oc)*H*W);
            memcpy(dst, src, sizeof(_Float16) * (size_t)(H*W));
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "IC": 18, "C_start": 15, "C_end": 18, "H": 64, "W": 85},
    ],
    argtypes_factory=_slice_c_f16_argtypes,
)


def _cat2_c1_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, h] + [ctypes.c_int] * 5


CAT2_C1_F16 = KernelSpec(
    op="cat2_c1_f16",
    signature=(
        "void kernel_cat2_c1_f16(const _Float16 *a, const _Float16 *b, "
        "_Float16 *output, int N, int H, int W, int Ca, int Cb)"
    ),
    semantics=(
        "Half-precision concatenation of two NCHW tensors along the channel\n"
        "axis (dim=1). a has shape [N, Ca, H, W], b has [N, Cb, H, W],\n"
        "output has [N, Ca+Cb, H, W]. Pure copy."
    ),
    reference_impl="""\
#include <string.h>

void kernel_cat2_c1_f16(const _Float16 *a, const _Float16 *b,
                        _Float16 *output,
                        int N, int H, int W, int Ca, int Cb) {
    int Cout = Ca + Cb;
    int HW = H * W;
    for (int n = 0; n < N; n++) {
        memcpy(output + n*Cout*HW,
               a + n*Ca*HW,
               sizeof(_Float16) * (size_t)(Ca * HW));
        memcpy(output + n*Cout*HW + Ca*HW,
               b + n*Cb*HW,
               sizeof(_Float16) * (size_t)(Cb * HW));
    }
}
""",
    extra_shapes=[
        {"N": 1, "H": 64, "W": 85, "Ca": 3, "Cb": 3},
        {"N": 1, "H": 1,  "W": 1,  "Ca": 1024, "Cb": 512},
    ],
    argtypes_factory=_cat2_c1_f16_argtypes,
)


def _pad_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h] + [ctypes.c_int] * 8


PAD_F16 = KernelSpec(
    op="pad_f16",
    signature=(
        "void kernel_pad_f16(const _Float16 *input, _Float16 *output, "
        "int N, int C, int IH, int IW, "
        "int pad_left, int pad_right, int pad_top, int pad_bottom)"
    ),
    semantics=(
        "Half-precision zero-pad an [N, C, IH, IW] tensor on H and W axes.\n"
        "OH = IH + pad_top + pad_bottom; OW = IW + pad_left + pad_right.\n"
        "Out-of-bounds positions are filled with 0.0."
    ),
    reference_impl="""\
#include <string.h>

void kernel_pad_f16(const _Float16 *input, _Float16 *output,
                    int N, int C, int IH, int IW,
                    int pad_left, int pad_right, int pad_top, int pad_bottom) {
    int OH = IH + pad_top + pad_bottom;
    int OW = IW + pad_left + pad_right;
    int OHW = OH * OW;
    memset(output, 0, sizeof(_Float16) * (size_t)(N * C * OHW));
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            for (int h = 0; h < IH; h++) {
                const _Float16 *src = input + ((n*C + c)*IH + h)*IW;
                _Float16 *dst = output +
                    ((n*C + c)*OH + (h + pad_top))*OW + pad_left;
                memcpy(dst, src, sizeof(_Float16) * (size_t)IW);
            }
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "C": 16, "IH": 8, "IW": 8,
         "pad_left": 1, "pad_right": 1, "pad_top": 1, "pad_bottom": 1},
    ],
    argtypes_factory=_pad_f16_argtypes,
)


# ---------------------------------------------------------------------------
# YOLOv8-nano fp16 op set: silu_f16, upsample_nearest_f16, cat{3,4}_c1_f16.
# Same semantics as the fp32 versions, _Float16 buffers throughout.
# ---------------------------------------------------------------------------


def _silu_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, ctypes.c_int]


SILU_F16 = KernelSpec(
    op="silu_f16",
    signature="void kernel_silu_f16(const _Float16 *input, _Float16 *output, int n)",
    semantics=(
        "Elementwise SiLU (Swish) on a contiguous _Float16 buffer:\n"
        "  output[i] = input[i] * sigmoid(input[i])  for i in [0, n)\n"
        "Reference computes sigmoid in float32 (to avoid the exp underflow\n"
        "stall on small _Float16 inputs) then casts the product back to\n"
        "_Float16. Safe for `input` and `output` to alias."
    ),
    reference_impl="""\
#include <math.h>
void kernel_silu_f16(const _Float16 *input, _Float16 *output, int n) {
    for (int i = 0; i < n; i++) {
        float v = (float)input[i];
        float s = 1.0f / (1.0f + expf(-v));
        output[i] = (_Float16)(v * s);
    }
}
""",
    extra_shapes=[
        {"n": 1}, {"n": 17}, {"n": 1024},
    ],
    argtypes_factory=_silu_f16_argtypes,
)


def _upsample_nearest_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, h, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int]


UPSAMPLE_NEAREST_F16 = KernelSpec(
    op="upsample_nearest_f16",
    signature=(
        "void kernel_upsample_nearest_f16(const _Float16 *input, _Float16 *output, "
        "int N, int C, int IH, int IW, int scale)"
    ),
    semantics=(
        "Nearest-neighbor 2D upsampling along H and W by integer factor `scale`,\n"
        "for _Float16 NCHW tensors. Output shape (N, C, IH*scale, IW*scale);\n"
        "each output pixel (oh, ow) reads input pixel (oh/scale, ow/scale)."
    ),
    reference_impl="""\
void kernel_upsample_nearest_f16(const _Float16 *input, _Float16 *output,
                                 int N, int C, int IH, int IW, int scale) {
    int OH = IH * scale, OW = IW * scale;
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            for (int oh = 0; oh < OH; oh++) {
                int ih = oh / scale;
                for (int ow = 0; ow < OW; ow++) {
                    int iw = ow / scale;
                    output[((n*C + c)*OH + oh)*OW + ow] =
                        input[((n*C + c)*IH + ih)*IW + iw];
                }
            }
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "C": 4,  "IH": 5,  "IW": 5,  "scale": 2},
        {"N": 1, "C": 16, "IH": 10, "IW": 10, "scale": 2},
    ],
    argtypes_factory=_upsample_nearest_f16_argtypes,
)


def _cat3_c1_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, ctypes.c_int, h, ctypes.c_int, h, ctypes.c_int,
            h, ctypes.c_int, ctypes.c_int, ctypes.c_int]


def _cat4_c1_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)
    return [h, ctypes.c_int, h, ctypes.c_int, h, ctypes.c_int,
            h, ctypes.c_int,
            h, ctypes.c_int, ctypes.c_int, ctypes.c_int]


CAT3_C1_F16 = KernelSpec(
    op="cat3_c1_f16",
    signature=(
        "void kernel_cat3_c1_f16(const _Float16 *in0, int c0, "
        "const _Float16 *in1, int c1, const _Float16 *in2, int c2, "
        "_Float16 *out, int N, int H, int W)"
    ),
    semantics=(
        "Half-precision channel-wise concat of three NCHW tensors (dim=1).\n"
        "Output shape (N, c0+c1+c2, H, W). Pure copy."
    ),
    reference_impl="""\
#include <string.h>

void kernel_cat3_c1_f16(const _Float16 *in0, int c0,
                        const _Float16 *in1, int c1,
                        const _Float16 *in2, int c2,
                        _Float16 *out, int N, int H, int W) {
    int C = c0 + c1 + c2;
    int HW = H * W;
    for (int n = 0; n < N; n++) {
        _Float16 *dst = out + n * C * HW;
        memcpy(dst, in0 + n*c0*HW, sizeof(_Float16) * (size_t)(c0*HW));
        dst += c0 * HW;
        memcpy(dst, in1 + n*c1*HW, sizeof(_Float16) * (size_t)(c1*HW));
        dst += c1 * HW;
        memcpy(dst, in2 + n*c2*HW, sizeof(_Float16) * (size_t)(c2*HW));
    }
}
""",
    extra_shapes=[
        {"c0": 16, "c1": 16, "c2": 16, "N": 1, "H": 8, "W": 8},
    ],
    argtypes_factory=_cat3_c1_f16_argtypes,
)


CAT4_C1_F16 = KernelSpec(
    op="cat4_c1_f16",
    signature=(
        "void kernel_cat4_c1_f16(const _Float16 *in0, int c0, "
        "const _Float16 *in1, int c1, const _Float16 *in2, int c2, "
        "const _Float16 *in3, int c3, "
        "_Float16 *out, int N, int H, int W)"
    ),
    semantics=(
        "Half-precision channel-wise concat of four NCHW tensors (dim=1).\n"
        "Output shape (N, c0+c1+c2+c3, H, W). Pure copy."
    ),
    reference_impl="""\
#include <string.h>

void kernel_cat4_c1_f16(const _Float16 *in0, int c0,
                        const _Float16 *in1, int c1,
                        const _Float16 *in2, int c2,
                        const _Float16 *in3, int c3,
                        _Float16 *out, int N, int H, int W) {
    int C = c0 + c1 + c2 + c3;
    int HW = H * W;
    for (int n = 0; n < N; n++) {
        _Float16 *dst = out + n * C * HW;
        memcpy(dst, in0 + n*c0*HW, sizeof(_Float16) * (size_t)(c0*HW));
        dst += c0 * HW;
        memcpy(dst, in1 + n*c1*HW, sizeof(_Float16) * (size_t)(c1*HW));
        dst += c1 * HW;
        memcpy(dst, in2 + n*c2*HW, sizeof(_Float16) * (size_t)(c2*HW));
        dst += c2 * HW;
        memcpy(dst, in3 + n*c3*HW, sizeof(_Float16) * (size_t)(c3*HW));
    }
}
""",
    extra_shapes=[
        {"c0": 8, "c1": 8, "c2": 8, "c3": 8, "N": 1, "H": 8, "W": 8},
    ],
    argtypes_factory=_cat4_c1_f16_argtypes,
)


# ---------------------------------------------------------------------------
# YOLOv8-nano support: silu / upsample_nearest / cat{2,3,4}_c1.
# silu and upsample_nearest are pointwise enough that the reference is
# obviously correct; the cat kernels are pure memcpy along the channel
# axis (NCHW). All four are needed end-to-end in the YOLOv8n graph.
# ---------------------------------------------------------------------------


def _silu_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    return [fp, fp, ctypes.c_int]


SILU = KernelSpec(
    op="silu",
    signature="void kernel_silu(const float *input, float *output, int n)",
    semantics=(
        "Elementwise SiLU (a.k.a. Swish) on a contiguous float32 buffer:\n"
        "  output[i] = input[i] / (1.0f + expf(-input[i]))   for i in [0, n)\n"
        "Equivalent to x * sigmoid(x). It must be safe for `input` and "
        "`output` to alias."
    ),
    reference_impl="""\
#include <math.h>
void kernel_silu(const float *input, float *output, int n) {
    for (int i = 0; i < n; i++) {
        float v = input[i];
        float s = 1.0f / (1.0f + expf(-v));
        output[i] = v * s;
    }
}
""",
    extra_shapes=[
        {"n": 1}, {"n": 17}, {"n": 1024},
    ],
    argtypes_factory=_silu_argtypes,
)


def _upsample_nearest_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    # input, output, N, C, IH, IW, scale
    return [fp, fp, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int]


UPSAMPLE_NEAREST = KernelSpec(
    op="upsample_nearest",
    signature=(
        "void kernel_upsample_nearest(const float *input, float *output, "
        "int N, int C, int IH, int IW, int scale)"
    ),
    semantics=(
        "Nearest-neighbor 2D upsampling along H and W by an integer factor.\n"
        "Output shape is (N, C, IH*scale, IW*scale). Each output pixel\n"
        "(oh, ow) reads the input pixel (oh/scale, ow/scale).\n"
        "Buffers are NCHW-laid-out; stride math:\n"
        "  in_idx  = ((n*C + c)*IH + ih)*IW + iw\n"
        "  out_idx = ((n*C + c)*OH + oh)*OW + ow\n"
        "where OH=IH*scale, OW=IW*scale, ih=oh/scale, iw=ow/scale."
    ),
    reference_impl="""\
void kernel_upsample_nearest(const float *input, float *output,
                             int N, int C, int IH, int IW, int scale) {
    int OH = IH * scale, OW = IW * scale;
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            for (int oh = 0; oh < OH; oh++) {
                int ih = oh / scale;
                for (int ow = 0; ow < OW; ow++) {
                    int iw = ow / scale;
                    output[((n*C + c)*OH + oh)*OW + ow] =
                        input[((n*C + c)*IH + ih)*IW + iw];
                }
            }
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "C": 4,  "IH": 5,  "IW": 5,  "scale": 2},
        {"N": 1, "C": 16, "IH": 10, "IW": 10, "scale": 2},
    ],
    argtypes_factory=_upsample_nearest_argtypes,
)


def _cat2_c1_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    # in0, c0, in1, c1, out, N, H, W
    return [fp, ctypes.c_int, fp, ctypes.c_int,
            fp, ctypes.c_int, ctypes.c_int, ctypes.c_int]


def _cat3_c1_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    return [fp, ctypes.c_int, fp, ctypes.c_int, fp, ctypes.c_int,
            fp, ctypes.c_int, ctypes.c_int, ctypes.c_int]


def _cat4_c1_argtypes():
    import ctypes
    fp = ctypes.POINTER(ctypes.c_float)
    return [fp, ctypes.c_int, fp, ctypes.c_int, fp, ctypes.c_int,
            fp, ctypes.c_int,
            fp, ctypes.c_int, ctypes.c_int, ctypes.c_int]


# Common cat semantics — only the input count varies. Pulled out so the
# three KernelSpecs share wording.
_CAT_SEMANTICS = (
    "Channel-wise concat (NCHW, dim=1) of {n} fp32 inputs into one output.\n"
    "Each input is N×c_i×H×W; the output is N×(c_0+c_1+...)×H×W.\n"
    "For each (n, h, w) the channel axis is filled by appending\n"
    "in0[n, :c0, h, w], then in1[n, :c1, h, w], then ... All inputs\n"
    "share the same N, H, W. Pure memcpy — no arithmetic."
)


CAT2_C1 = KernelSpec(
    op="cat2_c1",
    signature=(
        "void kernel_cat2_c1(const float *in0, int c0, "
        "const float *in1, int c1, float *out, int N, int H, int W)"
    ),
    semantics=_CAT_SEMANTICS.format(n=2),
    reference_impl="""\
void kernel_cat2_c1(const float *in0, int c0,
                    const float *in1, int c1,
                    float *out, int N, int H, int W) {
    int C = c0 + c1;
    int HW = H * W;
    for (int n = 0; n < N; n++) {
        float *dst = out + n * C * HW;
        const float *s0 = in0 + n * c0 * HW;
        const float *s1 = in1 + n * c1 * HW;
        for (int i = 0; i < c0 * HW; i++) dst[i] = s0[i];
        dst += c0 * HW;
        for (int i = 0; i < c1 * HW; i++) dst[i] = s1[i];
    }
}
""",
    extra_shapes=[
        {"c0": 16, "c1": 16, "N": 1, "H": 8,  "W": 8},
        {"c0": 64, "c1": 32, "N": 1, "H": 10, "W": 10},
    ],
    argtypes_factory=_cat2_c1_argtypes,
)


CAT3_C1 = KernelSpec(
    op="cat3_c1",
    signature=(
        "void kernel_cat3_c1(const float *in0, int c0, "
        "const float *in1, int c1, const float *in2, int c2, "
        "float *out, int N, int H, int W)"
    ),
    semantics=_CAT_SEMANTICS.format(n=3),
    reference_impl="""\
void kernel_cat3_c1(const float *in0, int c0,
                    const float *in1, int c1,
                    const float *in2, int c2,
                    float *out, int N, int H, int W) {
    int C = c0 + c1 + c2;
    int HW = H * W;
    for (int n = 0; n < N; n++) {
        float *dst = out + n * C * HW;
        const float *s0 = in0 + n * c0 * HW;
        const float *s1 = in1 + n * c1 * HW;
        const float *s2 = in2 + n * c2 * HW;
        for (int i = 0; i < c0 * HW; i++) dst[i] = s0[i];
        dst += c0 * HW;
        for (int i = 0; i < c1 * HW; i++) dst[i] = s1[i];
        dst += c1 * HW;
        for (int i = 0; i < c2 * HW; i++) dst[i] = s2[i];
    }
}
""",
    extra_shapes=[
        {"c0": 16, "c1": 16, "c2": 16, "N": 1, "H": 8, "W": 8},
    ],
    argtypes_factory=_cat3_c1_argtypes,
)


CAT4_C1 = KernelSpec(
    op="cat4_c1",
    signature=(
        "void kernel_cat4_c1(const float *in0, int c0, "
        "const float *in1, int c1, const float *in2, int c2, "
        "const float *in3, int c3, "
        "float *out, int N, int H, int W)"
    ),
    semantics=_CAT_SEMANTICS.format(n=4),
    reference_impl="""\
void kernel_cat4_c1(const float *in0, int c0,
                    const float *in1, int c1,
                    const float *in2, int c2,
                    const float *in3, int c3,
                    float *out, int N, int H, int W) {
    int C = c0 + c1 + c2 + c3;
    int HW = H * W;
    for (int n = 0; n < N; n++) {
        float *dst = out + n * C * HW;
        const float *s0 = in0 + n * c0 * HW;
        const float *s1 = in1 + n * c1 * HW;
        const float *s2 = in2 + n * c2 * HW;
        const float *s3 = in3 + n * c3 * HW;
        for (int i = 0; i < c0 * HW; i++) dst[i] = s0[i];
        dst += c0 * HW;
        for (int i = 0; i < c1 * HW; i++) dst[i] = s1[i];
        dst += c1 * HW;
        for (int i = 0; i < c2 * HW; i++) dst[i] = s2[i];
        dst += c2 * HW;
        for (int i = 0; i < c3 * HW; i++) dst[i] = s3[i];
    }
}
""",
    extra_shapes=[
        {"c0": 64, "c1": 64, "c2": 64, "c3": 64, "N": 1, "H": 5, "W": 5},
    ],
    argtypes_factory=_cat4_c1_argtypes,
)


# ---------------------------------------------------------------------------
# YOLOv8-nano int8 support: silu_s8 / upsample_nearest_s8 / cat{2,3,4}_c1_s8.
# All dequantize input(s) to float, apply the operation, then requantize to
# the output scale — same floating-point tail as sigmoid_s8 / batchnorm2d_s8.
# ---------------------------------------------------------------------------


def _silu_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    # input, output, n, scale_in, scale_out, activation_min, activation_max
    return [i8p, i8p, ctypes.c_int,
            ctypes.c_float, ctypes.c_float,
            ctypes.c_int, ctypes.c_int]


def _elu_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    # input, output, n, scale_in, scale_out, activation_min, activation_max, alpha
    return [i8p, i8p, ctypes.c_int,
            ctypes.c_float, ctypes.c_float,
            ctypes.c_int, ctypes.c_int,
            ctypes.c_float]


ELU_S8 = KernelSpec(
    op="elu_s8",
    signature=(
        "void kernel_elu_s8(const int8_t *input, int8_t *output, int n, "
        "float scale_in, float scale_out, "
        "int activation_min, int activation_max, float alpha)"
    ),
    semantics=(
        "Quantized elementwise ELU (Exponential Linear Unit) on a contiguous\n"
        "int8 buffer with symmetric per-tensor quantization (zero_point = 0).\n"
        "ELU(x) = x          if x > 0\n"
        "         alpha*(e^x - 1) if x <= 0\n"
        "Reference uses the exact form; an LUT-based variant can be added as\n"
        "a curated kernel — the int8 input only has 256 possible values, so\n"
        "the entire output table fits in 256 bytes for a given (scale_in,\n"
        "scale_out, alpha) tuple:\n"
        "  f = input[i] * scale_in\n"
        "  y = (f > 0) ? f : alpha * (expf(f) - 1)\n"
        "  output[i] = clamp(round(y / scale_out), activation_min, activation_max)\n"
        "alpha is typically 1.0 (PyTorch default)."
    ),
    reference_impl="""\
void kernel_elu_s8(const int8_t *input, int8_t *output, int n,
                   float scale_in, float scale_out,
                   int activation_min, int activation_max, float alpha) {
    for (int i = 0; i < n; i++) {
        float f = (float)input[i] * scale_in;
        float y = (f > 0.0f) ? f : alpha * (expf(f) - 1.0f);
        int32_t v = (int32_t)roundf(y / scale_out);
        if (v < activation_min) v = activation_min;
        if (v > activation_max) v = activation_max;
        output[i] = (int8_t)v;
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 17}, {"n": 256}],
    argtypes_factory=_elu_s8_argtypes,
)


SILU_S8 = KernelSpec(
    op="silu_s8",
    signature=(
        "void kernel_silu_s8(const int8_t *input, int8_t *output, int n, "
        "float scale_in, float scale_out, "
        "int activation_min, int activation_max)"
    ),
    semantics=(
        "Quantized elementwise SiLU (a.k.a. Swish) on a contiguous int8 "
        "buffer with symmetric per-tensor quantization (zero_point = 0):\n"
        "  f = input[i] * scale_in\n"
        "  y = f / (1.0f + expf(-f))           (SiLU = x * sigmoid(x))\n"
        "  output[i] = clamp(round(y / scale_out), activation_min, activation_max)\n"
        "activation_min / activation_max are the int8 output clamp bounds."
    ),
    reference_impl="""\
void kernel_silu_s8(const int8_t *input, int8_t *output, int n,
                    float scale_in, float scale_out,
                    int activation_min, int activation_max) {
    for (int i = 0; i < n; i++) {
        float f = (float)input[i] * scale_in;
        float y = f / (1.0f + expf(-f));
        int32_t v = (int32_t)roundf(y / scale_out);
        if (v < activation_min) v = activation_min;
        if (v > activation_max) v = activation_max;
        output[i] = (int8_t)v;
    }
}
""",
    extra_shapes=[
        {"n": 1}, {"n": 17}, {"n": 1024},
    ],
    argtypes_factory=_silu_s8_argtypes,
)


def _upsample_nearest_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    # input, output, N, C, IH, IW, scale
    return [i8p, i8p,
            ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int]


UPSAMPLE_NEAREST_S8 = KernelSpec(
    op="upsample_nearest_s8",
    signature=(
        "void kernel_upsample_nearest_s8(const int8_t *input, int8_t *output, "
        "int N, int C, int IH, int IW, int scale)"
    ),
    semantics=(
        "Quantized nearest-neighbor 2D upsampling along H and W by an "
        "integer scale factor. No requantize needed — nearest upsample just "
        "replicates int8 pixels; the output scale equals the input scale.\n"
        "Output shape is (N, C, IH*scale, IW*scale). Each output pixel\n"
        "(oh, ow) reads the input pixel (oh/scale, ow/scale).\n"
        "Buffers are NCHW-laid-out."
    ),
    reference_impl="""\
void kernel_upsample_nearest_s8(const int8_t *input, int8_t *output,
                                 int N, int C, int IH, int IW, int scale) {
    int OH = IH * scale, OW = IW * scale;
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            for (int oh = 0; oh < OH; oh++) {
                int ih = oh / scale;
                for (int ow = 0; ow < OW; ow++) {
                    int iw = ow / scale;
                    output[((n*C + c)*OH + oh)*OW + ow] =
                        input[((n*C + c)*IH + ih)*IW + iw];
                }
            }
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "C": 4,  "IH": 5,  "IW": 5,  "scale": 2},
        {"N": 1, "C": 16, "IH": 10, "IW": 10, "scale": 2},
        # yolov8n's two real upsample calls. The shapes above are C=4/C=16;
        # yolov8n runs C=256 (5x5) and C=128 (10x10), so the op that faults
        # at kernels.c:857 had NO verify coverage at the shapes it faults on.
        {"N": 1, "C": 256, "IH": 5,  "IW": 5,  "scale": 2},
        {"N": 1, "C": 128, "IH": 10, "IW": 10, "scale": 2},
    ],
    argtypes_factory=_upsample_nearest_s8_argtypes,
)


def _cat2_c1_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    # in0, c0, scale0, in1, c1, scale1,
    # output, N, H, W, scale_out, activation_min, activation_max
    return [i8p, ctypes.c_int, ctypes.c_float,
            i8p, ctypes.c_int, ctypes.c_float,
            i8p,
            ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_float, ctypes.c_int, ctypes.c_int]


def _cat3_c1_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    return [i8p, ctypes.c_int, ctypes.c_float,
            i8p, ctypes.c_int, ctypes.c_float,
            i8p, ctypes.c_int, ctypes.c_float,
            i8p,
            ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_float, ctypes.c_int, ctypes.c_int]


def _cat4_c1_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    return [i8p, ctypes.c_int, ctypes.c_float,
            i8p, ctypes.c_int, ctypes.c_float,
            i8p, ctypes.c_int, ctypes.c_float,
            i8p, ctypes.c_int, ctypes.c_float,
            i8p,
            ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_float, ctypes.c_int, ctypes.c_int]


def _cat_c1_s8_reference(n_inputs: int) -> str:
    """Generate the reference C implementation for catN_c1_s8."""
    sig_parts = ", ".join(
        f"const int8_t *in{i}, int c{i}, float scale{i}"
        for i in range(n_inputs)
    )
    return f"""\
void kernel_cat{n_inputs}_c1_s8({sig_parts},
                    int8_t *output,
                    int N, int H, int W,
                    float scale_out,
                    int activation_min, int activation_max) {{
    /* Channel-wise concatenation with per-input requantize.
     * Output[n, c_offset + c, h, w] = requantize(in_i[n, c, h, w])
     * where c_offset is the running channel offset for input i. */
    int stride = H * W;
    const int8_t *ins[{n_inputs}] = {{ {", ".join(f"in{i}" for i in range(n_inputs))} }};
    int cs[{n_inputs}] = {{ {", ".join(f"c{i}" for i in range(n_inputs))} }};
    float scales[{n_inputs}] = {{ {", ".join(f"scale{i}" for i in range(n_inputs))} }};
    for (int n = 0; n < N; n++) {{
        int out_c = 0;
        for (int i = 0; i < {n_inputs}; i++) {{
            float s_in = scales[i];
            for (int c = 0; c < cs[i]; c++) {{
                for (int hw = 0; hw < stride; hw++) {{
                    float f = (float)ins[i][((n * cs[i]) + c) * stride + hw] * s_in;
                    int32_t v = (int32_t)roundf(f / scale_out);
                    if (v < activation_min) v = activation_min;
                    if (v > activation_max) v = activation_max;
                    output[((n * ({" + ".join(f"c{j}" for j in range(n_inputs))}) + out_c + c) * stride + hw)] = (int8_t)v;
                }}
            }}
            out_c += cs[i];
        }}
    }}
}}
"""


CAT2_C1_S8 = KernelSpec(
    op="cat2_c1_s8",
    signature=(
        "void kernel_cat2_c1_s8("
        "const int8_t *in0, int c0, float scale0, "
        "const int8_t *in1, int c1, float scale1, "
        "int8_t *output, int N, int H, int W, "
        "float scale_out, int activation_min, int activation_max)"
    ),
    semantics=(
        "Concatenate 2 NCHW int8 tensors along the channel axis. Each input "
        "is dequantized by its own scale, then requantized to scale_out.\n"
        "Input i has shape (N, ci, H, W); output has shape "
        "(N, c0+c1, H, W)."
    ),
    reference_impl=_cat_c1_s8_reference(2),
    extra_shapes=[
        {"N": 1, "H": 4, "W": 4, "C_inputs": [8, 8],   "C_total": 16},
        {"N": 1, "H": 8, "W": 8, "C_inputs": [16, 32],  "C_total": 48},
    ],
    argtypes_factory=_cat2_c1_s8_argtypes,
)

CAT3_C1_S8 = KernelSpec(
    op="cat3_c1_s8",
    signature=(
        "void kernel_cat3_c1_s8("
        "const int8_t *in0, int c0, float scale0, "
        "const int8_t *in1, int c1, float scale1, "
        "const int8_t *in2, int c2, float scale2, "
        "int8_t *output, int N, int H, int W, "
        "float scale_out, int activation_min, int activation_max)"
    ),
    semantics=(
        "Concatenate 3 NCHW int8 tensors along the channel axis. Each input "
        "is dequantized by its own scale, then requantized to scale_out.\n"
        "Output shape is (N, c0+c1+c2, H, W)."
    ),
    reference_impl=_cat_c1_s8_reference(3),
    extra_shapes=[
        {"N": 1, "H": 4, "W": 4, "C_inputs": [8, 8, 8],    "C_total": 24},
        {"N": 1, "H": 8, "W": 8, "C_inputs": [16, 32, 16], "C_total": 64},
    ],
    argtypes_factory=_cat3_c1_s8_argtypes,
)

CAT4_C1_S8 = KernelSpec(
    op="cat4_c1_s8",
    signature=(
        "void kernel_cat4_c1_s8("
        "const int8_t *in0, int c0, float scale0, "
        "const int8_t *in1, int c1, float scale1, "
        "const int8_t *in2, int c2, float scale2, "
        "const int8_t *in3, int c3, float scale3, "
        "int8_t *output, int N, int H, int W, "
        "float scale_out, int activation_min, int activation_max)"
    ),
    semantics=(
        "Concatenate 4 NCHW int8 tensors along the channel axis. Each input "
        "is dequantized by its own scale, then requantized to scale_out.\n"
        "Output shape is (N, c0+c1+c2+c3, H, W)."
    ),
    reference_impl=_cat_c1_s8_reference(4),
    extra_shapes=[
        {"N": 1, "H": 4, "W": 4, "C_inputs": [8, 8, 8, 8],    "C_total": 32},
        {"N": 1, "H": 8, "W": 8, "C_inputs": [8, 16, 16, 8],   "C_total": 48},
    ],
    argtypes_factory=_cat4_c1_s8_argtypes,
)


# ---------------------------------------------------------------------------
# ViNT int8 support: mul_s8 / gelu_s8 / pad_s8 / adaptive_avg_pool2d_s8 /
# layer_norm_s8 / matmul_s8 / softmax_s8. Same float-tail pattern as the
# yolov8_nano s8 kernels above — dequantize, compute, requantize.
# ---------------------------------------------------------------------------


def _mul_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    # a, b, output, n, scale_a, scale_b, scale_out, act_min, act_max
    return [i8p, i8p, i8p, ctypes.c_int,
            ctypes.c_float, ctypes.c_float, ctypes.c_float,
            ctypes.c_int, ctypes.c_int]


MUL_S8 = KernelSpec(
    op="mul_s8",
    signature=(
        "void kernel_mul_s8(const int8_t *a, const int8_t *b, "
        "int8_t *output, int n, "
        "float scale_a, float scale_b, float scale_out, "
        "int activation_min, int activation_max)"
    ),
    semantics=(
        "Quantized elementwise multiply. The two inputs may have different\n"
        "scales — both are dequantized to float, multiplied, then\n"
        "requantized into the output's scale:\n"
        "  output[i] = clamp(\n"
        "      roundf((a[i]*scale_a) * (b[i]*scale_b) / scale_out),\n"
        "      activation_min, activation_max)\n"
        "Use roundf to match numpy.round (banker's rounding compatible).\n"
        "Common shapes in ViNT: SE gating (per-channel multiply onto an\n"
        "NCHW activation, with `b` broadcast or pre-expanded) and the\n"
        "Swish-as-x*sigmoid pattern. Both forms compile to a single\n"
        "elementwise pass once the broadcast is materialized upstream."
    ),
    reference_impl="""\
void kernel_mul_s8(const int8_t *a, const int8_t *b, int8_t *output, int n,
                   float scale_a, float scale_b, float scale_out,
                   int activation_min, int activation_max) {
    for (int i = 0; i < n; i++) {
        float fa = (float)a[i] * scale_a;
        float fb = (float)b[i] * scale_b;
        float fout = (fa * fb) / scale_out;
        int32_t v = (int32_t)roundf(fout);
        if (v < activation_min) v = activation_min;
        if (v > activation_max) v = activation_max;
        output[i] = (int8_t)v;
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 17}, {"n": 1024}, {"n": 8192}],
    argtypes_factory=_mul_s8_argtypes,
)


def _gelu_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    return [i8p, i8p, ctypes.c_int,
            ctypes.c_float, ctypes.c_float,
            ctypes.c_int, ctypes.c_int]


GELU_S8 = KernelSpec(
    op="gelu_s8",
    signature=(
        "void kernel_gelu_s8(const int8_t *input, int8_t *output, int n, "
        "float scale_in, float scale_out, "
        "int activation_min, int activation_max)"
    ),
    semantics=(
        "Quantized GELU (Gaussian Error Linear Unit) on a contiguous int8\n"
        "buffer with per-tensor symmetric quant (zero_point = 0).\n"
        "Reference uses the exact erf-based form to match torch.nn.GELU\n"
        "default; an LUT/tanh-approx variant can be added as a curated\n"
        "kernel later:\n"
        "  f = input[i] * scale_in\n"
        "  y = 0.5f * f * (1.0f + erff(f / sqrtf(2)))\n"
        "  output[i] = clamp(round(y / scale_out), activation_min, activation_max)"
    ),
    reference_impl="""\
void kernel_gelu_s8(const int8_t *input, int8_t *output, int n,
                    float scale_in, float scale_out,
                    int activation_min, int activation_max) {
    const float kInvSqrt2 = 0.70710678118f;
    for (int i = 0; i < n; i++) {
        float f = (float)input[i] * scale_in;
        float y = 0.5f * f * (1.0f + erff(f * kInvSqrt2));
        int32_t v = (int32_t)roundf(y / scale_out);
        if (v < activation_min) v = activation_min;
        if (v > activation_max) v = activation_max;
        output[i] = (int8_t)v;
    }
}
""",
    extra_shapes=[{"n": 1}, {"n": 32}, {"n": 2048}],
    argtypes_factory=_gelu_s8_argtypes,
)


def _pad_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    # input, output, N, C, IH, IW, pad_left, pad_right, pad_top, pad_bottom, pad_value
    return [i8p, i8p,
            ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int]


PAD_S8 = KernelSpec(
    op="pad_s8",
    signature=(
        "void kernel_pad_s8(const int8_t *input, int8_t *output, "
        "int N, int C, int IH, int IW, "
        "int pad_left, int pad_right, int pad_top, int pad_bottom, "
        "int pad_value)"
    ),
    semantics=(
        "Constant-value spatial pad for NCHW int8 tensors. Output shape:\n"
        "  OH = IH + pad_top + pad_bottom\n"
        "  OW = IW + pad_left + pad_right\n"
        "Copies input[n, c, ih, iw] into output[n, c, ih + pad_top,\n"
        "iw + pad_left] and fills the surrounding border with pad_value\n"
        "(cast to int8). No quant rescaling: input and output share the\n"
        "same scale (per-tensor symmetric quant; zero_point = 0 → pad with\n"
        "the int8 representation of zero, which is 0).\n"
        "Used by EfficientNet's same-padding-with-stride pattern where\n"
        "the pad is asymmetric and can't fold into a Conv2D's padding."
    ),
    reference_impl="""\
void kernel_pad_s8(const int8_t *input, int8_t *output,
                   int N, int C, int IH, int IW,
                   int pad_left, int pad_right, int pad_top, int pad_bottom,
                   int pad_value) {
    int OH = IH + pad_top + pad_bottom;
    int OW = IW + pad_left + pad_right;
    int8_t pad_v = (int8_t)pad_value;
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            for (int oh = 0; oh < OH; oh++) {
                int ih = oh - pad_top;
                for (int ow = 0; ow < OW; ow++) {
                    int iw = ow - pad_left;
                    int8_t v = pad_v;
                    if (ih >= 0 && ih < IH && iw >= 0 && iw < IW) {
                        v = input[((n*C+c)*IH+ih)*IW+iw];
                    }
                    output[((n*C+c)*OH+oh)*OW+ow] = v;
                }
            }
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "C": 16, "IH": 16, "IW": 16,
         "pad_left": 0, "pad_right": 1, "pad_top": 0, "pad_bottom": 1, "pad_value": 0},
        {"N": 1, "C": 32, "IH": 32, "IW": 32,
         "pad_left": 1, "pad_right": 1, "pad_top": 1, "pad_bottom": 1, "pad_value": 0},
    ],
    argtypes_factory=_pad_s8_argtypes,
)


def _adaptive_avg_pool2d_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    # input, output, N, C, IH, IW, OH, OW, scale_in, scale_out, act_min, act_max
    return [i8p, i8p,
            ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int,
            ctypes.c_float, ctypes.c_float,
            ctypes.c_int, ctypes.c_int]


ADAPTIVE_AVG_POOL2D_S8 = KernelSpec(
    op="adaptive_avg_pool2d_s8",
    signature=(
        "void kernel_adaptive_avg_pool2d_s8(const int8_t *input, "
        "int8_t *output, int N, int C, int IH, int IW, int OH, int OW, "
        "float scale_in, float scale_out, "
        "int activation_min, int activation_max)"
    ),
    semantics=(
        "Adaptive average-pool over an NCHW int8 tensor. For each output\n"
        "cell (oh, ow) the source window is the half-open interval\n"
        "  ih ∈ [floor(oh * IH / OH), ceil((oh+1) * IH / OH))\n"
        "  iw ∈ [floor(ow * IW / OW), ceil((ow+1) * IW / OW))\n"
        "Matches torch.nn.functional.adaptive_avg_pool2d. The mean is\n"
        "computed in float, then requantized:\n"
        "  acc = sum_{ih, iw} input[n, c, ih, iw] * scale_in\n"
        "  mean = acc / window_size\n"
        "  output[n, c, oh, ow] = clamp(\n"
        "      round(mean / scale_out), activation_min, activation_max)\n"
        "Common ViNT shape: OH=OW=1 (SE-block global average plus\n"
        "EfficientNet's pre-FC pool) where the window covers the whole\n"
        "(IH, IW)."
    ),
    reference_impl="""\
void kernel_adaptive_avg_pool2d_s8(const int8_t *input, int8_t *output,
                                   int N, int C, int IH, int IW,
                                   int OH, int OW,
                                   float scale_in, float scale_out,
                                   int activation_min, int activation_max) {
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            for (int oh = 0; oh < OH; oh++) {
                int ih0 = (oh * IH) / OH;
                int ih1 = ((oh + 1) * IH + OH - 1) / OH;
                if (ih1 > IH) ih1 = IH;
                for (int ow = 0; ow < OW; ow++) {
                    int iw0 = (ow * IW) / OW;
                    int iw1 = ((ow + 1) * IW + OW - 1) / OW;
                    if (iw1 > IW) iw1 = IW;
                    int win = (ih1 - ih0) * (iw1 - iw0);
                    if (win <= 0) win = 1;
                    int32_t acc = 0;
                    for (int ih = ih0; ih < ih1; ih++) {
                        for (int iw = iw0; iw < iw1; iw++) {
                            acc += (int32_t)input[((n*C+c)*IH+ih)*IW+iw];
                        }
                    }
                    float mean = (float)acc * scale_in / (float)win;
                    int32_t v = (int32_t)roundf(mean / scale_out);
                    if (v < activation_min) v = activation_min;
                    if (v > activation_max) v = activation_max;
                    output[((n*C+c)*OH+oh)*OW+ow] = (int8_t)v;
                }
            }
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "C": 16, "IH": 8, "IW": 8, "OH": 1, "OW": 1},
        {"N": 1, "C": 128, "IH": 4, "IW": 4, "OH": 1, "OW": 1},
        {"N": 1, "C": 1280, "IH": 2, "IW": 3, "OH": 1, "OW": 1},
    ],
    argtypes_factory=_adaptive_avg_pool2d_s8_argtypes,
)


def _layer_norm_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    # input, gamma, beta, output, M (rows), K (cols), scale_in, scale_gamma,
    # scale_beta, scale_out, eps, act_min, act_max
    return [i8p, i8p, i8p, i8p,
            ctypes.c_int, ctypes.c_int,
            ctypes.c_float, ctypes.c_float, ctypes.c_float, ctypes.c_float,
            ctypes.c_float,
            ctypes.c_int, ctypes.c_int]


LAYER_NORM_S8 = KernelSpec(
    op="layer_norm_s8",
    signature=(
        "void kernel_layer_norm_s8(const int8_t *input, const int8_t *gamma, "
        "const int8_t *beta, int8_t *output, int M, int K, "
        "float scale_in, float scale_gamma, float scale_beta, "
        "float scale_out, float eps, "
        "int activation_min, int activation_max)"
    ),
    semantics=(
        "Layer normalization over the last axis of a 2-D row-major view\n"
        "(M rows × K cols). Per-row mean and variance computed in float;\n"
        "normalized values are scaled by gamma and shifted by beta\n"
        "(per-channel parameters of length K, themselves int8-quantized):\n"
        "  mu_m  = mean_{k=0..K-1}( input[m,k] * scale_in )\n"
        "  var_m = mean_{k=0..K-1}( (input[m,k]*scale_in - mu_m)^2 )\n"
        "  inv   = 1 / sqrtf(var_m + eps)\n"
        "  y[m,k] = ((input[m,k]*scale_in - mu_m) * inv) * (gamma[k]*scale_gamma)\n"
        "           + beta[k]*scale_beta\n"
        "  output[m,k] = clamp(round(y / scale_out),\n"
        "                      activation_min, activation_max)\n"
        "Gamma/beta arrive as int8 with their own per-tensor scales (the\n"
        "extractor stores them via _record_constant). When gamma == NULL\n"
        "or beta == NULL pass 0 for the corresponding scale and treat\n"
        "the affine term as identity / zero."
    ),
    reference_impl="""\
void kernel_layer_norm_s8(const int8_t *input, const int8_t *gamma,
                          const int8_t *beta, int8_t *output,
                          int M, int K,
                          float scale_in, float scale_gamma, float scale_beta,
                          float scale_out, float eps,
                          int activation_min, int activation_max) {
    for (int m = 0; m < M; m++) {
        const int8_t *row_in  = input  + m * K;
        int8_t       *row_out = output + m * K;
        float mu = 0.0f;
        for (int k = 0; k < K; k++) mu += (float)row_in[k] * scale_in;
        mu /= (float)K;
        float var = 0.0f;
        for (int k = 0; k < K; k++) {
            float d = (float)row_in[k] * scale_in - mu;
            var += d * d;
        }
        var /= (float)K;
        float inv = 1.0f / sqrtf(var + eps);
        for (int k = 0; k < K; k++) {
            float n = ((float)row_in[k] * scale_in - mu) * inv;
            float g = (gamma ? (float)gamma[k] * scale_gamma : 1.0f);
            float b = (beta  ? (float)beta[k]  * scale_beta  : 0.0f);
            float y = n * g + b;
            int32_t v = (int32_t)roundf(y / scale_out);
            if (v < activation_min) v = activation_min;
            if (v > activation_max) v = activation_max;
            row_out[k] = (int8_t)v;
        }
    }
}
""",
    extra_shapes=[
        {"M": 1,   "K": 64},
        {"M": 7,   "K": 512},   # ViNT transformer: seq=7 tokens, embed=512
        {"M": 32,  "K": 256},
    ],
    argtypes_factory=_layer_norm_s8_argtypes,
)


def _matmul_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    # a, b, output, M, K, N, scale_a, scale_b, scale_out, transpose_b,
    # scale_div, act_min, act_max
    return [i8p, i8p, i8p,
            ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_float, ctypes.c_float, ctypes.c_float,
            ctypes.c_int,
            ctypes.c_float,
            ctypes.c_int, ctypes.c_int]


MATMUL_S8 = KernelSpec(
    op="matmul_s8",
    signature=(
        "void kernel_matmul_s8(const int8_t *a, const int8_t *b, "
        "int8_t *output, int M, int K, int N, "
        "float scale_a, float scale_b, float scale_out, "
        "int transpose_b, float scale_div, "
        "int activation_min, int activation_max)"
    ),
    semantics=(
        "Int8 matrix multiplication out[M,N] = a[M,K] @ b[K,N] (or\n"
        "a @ b.T if transpose_b is non-zero — used for Q·Kᵀ in attention).\n"
        "Accumulator is int32; the per-element output is rescaled and\n"
        "optionally divided by scale_div (e.g. 1/sqrt(d_k) for attention\n"
        "scores; pass 1.0 if unused):\n"
        "  acc[i,j] = sum_{k} a[i,k] * (transpose_b ? b[j,k] : b[k,j])\n"
        "  output[i,j] = clamp(\n"
        "      round(acc * scale_a * scale_b / (scale_out * scale_div)),\n"
        "      activation_min, activation_max)\n"
        "Float math is used for the requantize tail to match the modelblaster\n"
        "linear_s8 numerics; the curated gemmini_q31 / RVV kernels can\n"
        "implement the Q0.31 path bit-exactly."
    ),
    reference_impl="""\
void kernel_matmul_s8(const int8_t *a, const int8_t *b, int8_t *output,
                      int M, int K, int N,
                      float scale_a, float scale_b, float scale_out,
                      int transpose_b, float scale_div,
                      int activation_min, int activation_max) {
    float total = (scale_a * scale_b) / (scale_out * scale_div);
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            int32_t acc = 0;
            for (int k = 0; k < K; k++) {
                int8_t av = a[i*K + k];
                int8_t bv = transpose_b ? b[j*K + k] : b[k*N + j];
                acc += (int32_t)av * (int32_t)bv;
            }
            int32_t v = (int32_t)roundf((float)acc * total);
            if (v < activation_min) v = activation_min;
            if (v > activation_max) v = activation_max;
            output[i*N + j] = (int8_t)v;
        }
    }
}
""",
    extra_shapes=[
        {"M": 7, "K": 64, "N": 7,   "transpose_b": 1, "scale_div": 8.0},  # attention Q·Kᵀ, head_dim=64
        {"M": 7, "K": 7,  "N": 64,  "transpose_b": 0, "scale_div": 1.0},  # attention ·V
        {"M": 7, "K": 512, "N": 512, "transpose_b": 0, "scale_div": 1.0}, # FFN-style
    ],
    argtypes_factory=_matmul_s8_argtypes,
    algorithms=[
        AlgorithmCandidate(
            name="outerprod",
            target_affinity=("rvv_opu",),
            description=(
                "Saturn OPU i8 outer-product matmul (VOPACC). Ported from\n"
                "  hw/chipyard/generators/saturn/benchmarks/opu-gemm/kernel.h\n"
                "(branch origin/opu-fp8, function `i8_mm_bme_sq`). The OPU\n"
                "computes m[r,c] += vs1[r] * vs2[c] across K iterations of\n"
                "VOPACC; one tile covers M×N up to mlmax=VLEN/8 per dim.\n\n"
                "ALGORITHM:\n"
                "  transpose a [M,K] -> at [K,M] (stack scratch)\n"
                "  if transpose_b: transpose b [N,K] -> b_kn [K,N]\n"
                "  OPMVINBCAST m1 <- 0   (no bias in matmul_s8)\n"
                "  for k in [0, K) two-way unrolled:\n"
                "    vle8.v v16 <- at[k*M..k*M+M]\n"
                "    vle8.v v18 <- b[k*N..k*N+N]\n"
                "    VOPACC m1, v18, v16\n"
                "  drain rows of m1 into i32 scratch, apply matmul_s8\n"
                "  requantize tail (float scale + round + clamp + i8).\n\n"
                "Single-tile only: M,N <= 64 (OPU_MAX_TILE for V512),\n"
                "K <= 1024 (OPU_MAX_K). Larger shapes fall back to the\n"
                "embedded scalar reference; tiled OPU coverage is a\n"
                "follow-up curation."
            ),
            reference_impl="",  # the curated file supplies the impl
        ),
    ],
)


# ---------------------------------------------------------------------------
# Per-channel weight-scale (PC) variants of conv2d_s8 / linear_s8 / matmul_s8.
# Identical algebra to the per-tensor versions except output_multiplier and
# output_shift become per-OC arrays. This is the standard CMSIS-NN / TFLite
# Micro shape: weight tensors carry per-channel scales (one per output
# channel for conv/linear, one per N column for matmul); the int32 bias is
# scaled by (input_scale * weight_scale_per_oc); the requantize tail picks
# the OC-specific (mult, shift) for each output element.
# ---------------------------------------------------------------------------


def _conv2d_s8_pc_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    i32p = ctypes.POINTER(ctypes.c_int32)
    return [i8p, i8p, i32p, i8p,
            ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int, ctypes.c_int,
            i32p, i32p,    # per-OC multiplier + shift arrays
            ctypes.c_int, ctypes.c_int]


CONV2D_S8_PC = KernelSpec(
    op="conv2d_s8_pc",
    signature=(
        "void kernel_conv2d_s8_pc(const int8_t *input, const int8_t *weight, "
        "const int32_t *bias, int8_t *output, "
        "int N, int IC, int IH, int IW, int OC, "
        "int KH, int KW, int SH, int SW, int PH, int PW, "
        "int input_offset, int filter_offset, int output_offset, "
        "const int32_t *output_multiplier, const int32_t *output_shift, "
        "int activation_min, int activation_max)"
    ),
    semantics=(
        "Per-channel-weight-scale variant of conv2d_s8. Same int32-acc\n"
        "dataflow; the requantize tail picks (output_multiplier[oc],\n"
        "output_shift[oc]) for each output channel:\n"
        "  acc = SAT_ROUND_SAT_ADD(acc, output_multiplier[oc],\n"
        "                                output_shift[oc])\n"
        "  out = clamp(acc + output_offset, act_min, act_max)\n"
        "Bias is already pre-scaled by (input_scale * weight_scale_per_oc)\n"
        "at codegen time, so the kernel adds it to the accumulator before\n"
        "the per-OC requantize."
    ),
    reference_impl="""\
void kernel_conv2d_s8_pc(const int8_t *input, const int8_t *weight,
                         const int32_t *bias, int8_t *output,
                         int N, int IC, int IH, int IW, int OC,
                         int KH, int KW, int SH, int SW, int PH, int PW,
                         int input_offset, int filter_offset, int output_offset,
                         const int32_t *output_multiplier,
                         const int32_t *output_shift,
                         int activation_min, int activation_max) {
    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;
    for (int n = 0; n < N; n++) {
        for (int oc = 0; oc < OC; oc++) {
            int32_t mult = output_multiplier[oc];
            int32_t shift = output_shift[oc];
            for (int oh = 0; oh < OH; oh++) {
                for (int ow = 0; ow < OW; ow++) {
                    int32_t acc = bias ? bias[oc] : 0;
                    for (int ic = 0; ic < IC; ic++) {
                        for (int kh = 0; kh < KH; kh++) {
                            int ih = oh * SH - PH + kh;
                            if (ih < 0 || ih >= IH) continue;
                            for (int kw = 0; kw < KW; kw++) {
                                int iw = ow * SW - PW + kw;
                                if (iw < 0 || iw >= IW) continue;
                                int32_t iv = (int32_t)input[((n*IC + ic)*IH + ih)*IW + iw] + input_offset;
                                int32_t wv = (int32_t)weight[((oc*IC + ic)*KH + kh)*KW + kw] + filter_offset;
                                acc += iv * wv;
                            }
                        }
                    }
                    int64_t prod = ((int64_t)acc * (int64_t)mult + (1LL << 30)) >> 31;
                    int32_t v;
                    if (shift > 0) {
                        int32_t r = 1 << (shift - 1);
                        v = ((int32_t)prod + r) >> shift;
                    } else {
                        v = ((int32_t)prod) << (-shift);
                    }
                    v += output_offset;
                    if (v < activation_min) v = activation_min;
                    if (v > activation_max) v = activation_max;
                    output[((n*OC + oc)*OH + oh)*OW + ow] = (int8_t)v;
                }
            }
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "IC": 3, "IH": 16, "IW": 16, "OC": 8,
         "KH": 3, "KW": 3, "SH": 1, "SW": 1, "PH": 1, "PW": 1},
    ],
    argtypes_factory=_conv2d_s8_pc_argtypes,
)


def _linear_s8_pc_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    i32p = ctypes.POINTER(ctypes.c_int32)
    return [i8p, i8p, i32p, i8p,
            ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int, ctypes.c_int,
            i32p, i32p,
            ctypes.c_int, ctypes.c_int]


LINEAR_S8_PC = KernelSpec(
    op="linear_s8_pc",
    signature=(
        "void kernel_linear_s8_pc(const int8_t *input, const int8_t *weight, "
        "const int32_t *bias, int8_t *output, "
        "int M, int K, int N, "
        "int input_offset, int filter_offset, int output_offset, "
        "const int32_t *output_multiplier, const int32_t *output_shift, "
        "int activation_min, int activation_max)"
    ),
    semantics=(
        "Per-N-channel-scale linear: out[m, n] picks\n"
        "(output_multiplier[n], output_shift[n]) for the requantize.\n"
        "Same dataflow as linear_s8 otherwise. Weight is [N, K]\n"
        "row-major; bias is per-output-channel int32 pre-scaled by\n"
        "(input_scale * weight_scale_per_n)."
    ),
    reference_impl="""\
void kernel_linear_s8_pc(const int8_t *input, const int8_t *weight,
                         const int32_t *bias, int8_t *output,
                         int M, int K, int N,
                         int input_offset, int filter_offset, int output_offset,
                         const int32_t *output_multiplier,
                         const int32_t *output_shift,
                         int activation_min, int activation_max) {
    for (int m = 0; m < M; m++) {
        for (int n = 0; n < N; n++) {
            int32_t mult = output_multiplier[n];
            int32_t shift = output_shift[n];
            int32_t acc = bias ? bias[n] : 0;
            for (int k = 0; k < K; k++) {
                int32_t iv = (int32_t)input[m*K + k] + input_offset;
                int32_t wv = (int32_t)weight[n*K + k] + filter_offset;
                acc += iv * wv;
            }
            int64_t prod = ((int64_t)acc * (int64_t)mult + (1LL << 30)) >> 31;
            int32_t v;
            if (shift > 0) {
                int32_t r = 1 << (shift - 1);
                v = ((int32_t)prod + r) >> shift;
            } else {
                v = ((int32_t)prod) << (-shift);
            }
            v += output_offset;
            if (v < activation_min) v = activation_min;
            if (v > activation_max) v = activation_max;
            output[m*N + n] = (int8_t)v;
        }
    }
}
""",
    extra_shapes=[
        {"M": 1, "K": 16, "N": 8},
        {"M": 7, "K": 512, "N": 256},
    ],
    argtypes_factory=_linear_s8_pc_argtypes,
)


def _matmul_s8_pc_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    i32p = ctypes.POINTER(ctypes.c_int32)
    return [i8p, i8p, i8p,
            ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int,
            ctypes.c_float,
            i32p, i32p,
            ctypes.c_int, ctypes.c_int]


MATMUL_S8_PC = KernelSpec(
    op="matmul_s8_pc",
    signature=(
        "void kernel_matmul_s8_pc(const int8_t *a, const int8_t *b, "
        "int8_t *output, int M, int K, int N, "
        "int transpose_b, float scale_div, "
        "const int32_t *output_multiplier, const int32_t *output_shift, "
        "int activation_min, int activation_max)"
    ),
    semantics=(
        "Per-N-channel-scale matmul. Same int32-acc / transpose_b /\n"
        "scale_div behavior as matmul_s8; the requantize tail uses\n"
        "(output_multiplier[n], output_shift[n]) per output column.\n"
        "scale_div folds 1/sqrt(d_k) for attention scores into the\n"
        "Q0.31 multiplier at codegen time (or stays as a fp factor\n"
        "applied to acc before the per-N requantize, depending on\n"
        "what the codegen baked in)."
    ),
    reference_impl="""\
void kernel_matmul_s8_pc(const int8_t *a, const int8_t *b, int8_t *output,
                         int M, int K, int N,
                         int transpose_b, float scale_div,
                         const int32_t *output_multiplier,
                         const int32_t *output_shift,
                         int activation_min, int activation_max) {
    float inv_div = 1.0f / scale_div;
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            int32_t mult = output_multiplier[j];
            int32_t shift = output_shift[j];
            int32_t acc = 0;
            for (int k = 0; k < K; k++) {
                int8_t av = a[i*K + k];
                int8_t bv = transpose_b ? b[j*K + k] : b[k*N + j];
                acc += (int32_t)av * (int32_t)bv;
            }
            /* scale_div folded into the requantize as a float scale
             * applied to the int32 accumulator before the Q0.31 mult.
             * For the common attention case scale_div = sqrt(d_k); the
             * fp32 fold is acceptable since the matmul is the dominant
             * cost (this multiply happens once per output element). */
            int32_t acc_div = (int32_t)roundf((float)acc * inv_div);
            int64_t prod = ((int64_t)acc_div * (int64_t)mult + (1LL << 30)) >> 31;
            int32_t v;
            if (shift > 0) {
                int32_t r = 1 << (shift - 1);
                v = ((int32_t)prod + r) >> shift;
            } else {
                v = ((int32_t)prod) << (-shift);
            }
            if (v < activation_min) v = activation_min;
            if (v > activation_max) v = activation_max;
            output[i*N + j] = (int8_t)v;
        }
    }
}
""",
    extra_shapes=[
        {"M": 7, "K": 128, "N": 7, "transpose_b": 1, "scale_div": 11.3},
        {"M": 7, "K": 7,   "N": 128, "transpose_b": 0, "scale_div": 1.0},
    ],
    argtypes_factory=_matmul_s8_pc_argtypes,
)


def _depthwise_conv2d_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    i32p = ctypes.POINTER(ctypes.c_int32)
    # input, weight, bias, output, N, C, IH, IW, KH, KW, SH, SW, PH, PW,
    # input_offset, filter_offset, output_offset, output_multiplier,
    # output_shift, activation_min, activation_max
    return [i8p, i8p, i32p, i8p,
            ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int]


DEPTHWISE_CONV2D_S8 = KernelSpec(
    op="depthwise_conv2d_s8",
    signature=(
        "void kernel_depthwise_conv2d_s8(const int8_t *input, "
        "const int8_t *weight, const int32_t *bias, int8_t *output, "
        "int N, int C, int IH, int IW, "
        "int KH, int KW, int SH, int SW, int PH, int PW, "
        "int input_offset, int filter_offset, int output_offset, "
        "int output_multiplier, int output_shift, "
        "int activation_min, int activation_max)"
    ),
    semantics=(
        "Quantized depthwise 2D convolution — each input channel has\n"
        "its own KH×KW filter, applied independently (groups=C).\n"
        "Layout:\n"
        "  input:  int8  [N, C, IH, IW]\n"
        "  weight: int8  [C, 1, KH, KW]  (or [C, KH, KW] flat)\n"
        "  bias:   int32 [C] (may be NULL)\n"
        "  output: int8  [N, C, OH, OW]\n"
        "Compute (per output element, per channel c):\n"
        "  acc = bias[c] (or 0)\n"
        "  for kh, kw with ih = oh*SH-PH+kh, iw = ow*SW-PW+kw:\n"
        "    if (ih, iw) in bounds:\n"
        "      acc += (input[n,c,ih,iw] + input_offset)\n"
        "           * (weight[c, kh, kw] + filter_offset)\n"
        "Q0.31 requantize tail identical to conv2d_s8:\n"
        "  acc = SAT_ROUND_SAT_ADD(acc, output_multiplier, output_shift)\n"
        "  out = clamp(acc + output_offset, act_min, act_max)\n"
        "Used heavily by EfficientNet's MBConv blocks (~32 of them in\n"
        "ViNT's obs/goal encoders)."
    ),
    reference_impl="""\
void kernel_depthwise_conv2d_s8(const int8_t *input, const int8_t *weight,
                                const int32_t *bias, int8_t *output,
                                int N, int C, int IH, int IW,
                                int KH, int KW, int SH, int SW, int PH, int PW,
                                int input_offset, int filter_offset, int output_offset,
                                int output_multiplier, int output_shift,
                                int activation_min, int activation_max) {
    int OH = (IH + 2*PH - KH) / SH + 1;
    int OW = (IW + 2*PW - KW) / SW + 1;
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < C; c++) {
            for (int oh = 0; oh < OH; oh++) {
                for (int ow = 0; ow < OW; ow++) {
                    int32_t acc = bias ? bias[c] : 0;
                    for (int kh = 0; kh < KH; kh++) {
                        int ih = oh * SH - PH + kh;
                        if (ih < 0 || ih >= IH) continue;
                        for (int kw = 0; kw < KW; kw++) {
                            int iw = ow * SW - PW + kw;
                            if (iw < 0 || iw >= IW) continue;
                            int32_t iv = (int32_t)input[((n*C + c)*IH + ih)*IW + iw] + input_offset;
                            int32_t wv = (int32_t)weight[(c*KH + kh)*KW + kw] + filter_offset;
                            acc += iv * wv;
                        }
                    }
                    int64_t prod = ((int64_t)acc * (int64_t)output_multiplier + (1LL << 30)) >> 31;
                    int32_t v;
                    if (output_shift > 0) {
                        int32_t r = 1 << (output_shift - 1);
                        v = ((int32_t)prod + r) >> output_shift;
                    } else {
                        v = ((int32_t)prod) << (-output_shift);
                    }
                    v += output_offset;
                    if (v < activation_min) v = activation_min;
                    if (v > activation_max) v = activation_max;
                    output[((n*C + c)*OH + oh)*OW + ow] = (int8_t)v;
                }
            }
        }
    }
}
""",
    extra_shapes=[
        # MBConv-style depthwise (EfficientNet pattern)
        {"N": 1, "C": 32, "IH": 32, "IW": 32,
         "KH": 3, "KW": 3, "SH": 1, "SW": 1, "PH": 1, "PW": 1},
        {"N": 1, "C": 16, "IH": 16, "IW": 16,
         "KH": 3, "KW": 3, "SH": 2, "SW": 2, "PH": 0, "PW": 0},
    ],
    argtypes_factory=_depthwise_conv2d_s8_argtypes,
)


def _slice_c_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    # input, output, N, IC, C_start, C_end, H, W,
    # scale_in, scale_out, act_min, act_max
    return [i8p, i8p,
            ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int,
            ctypes.c_float, ctypes.c_float,
            ctypes.c_int, ctypes.c_int]


SLICE_C_S8 = KernelSpec(
    op="slice_c_s8",
    signature=(
        "void kernel_slice_c_s8(const int8_t *input, int8_t *output, "
        "int N, int IC, int C_start, int C_end, int H, int W, "
        "float scale_in, float scale_out, "
        "int activation_min, int activation_max)"
    ),
    semantics=(
        "Contiguous channel-axis slice of an NCHW int8 tensor:\n"
        "  output[n, c-C_start, h, w] = round(\n"
        "      input[n, c, h, w] * scale_in / scale_out)\n"
        "for c in [C_start, C_end), result shape (N, C_end-C_start, H, W).\n"
        "When scale_in == scale_out the body reduces to a memcpy of\n"
        "(C_end - C_start) * H * W bytes per batch — the requantize tail\n"
        "is structurally a no-op (round((x*s)/s) = x). Used by ViNT's\n"
        "goal-encoder path: obs_img[:, 3*context_size:3*(context_size+1)]."
    ),
    reference_impl="""\
void kernel_slice_c_s8(const int8_t *input, int8_t *output,
                       int N, int IC, int C_start, int C_end, int H, int W,
                       float scale_in, float scale_out,
                       int activation_min, int activation_max) {
    int OC = C_end - C_start;
    for (int n = 0; n < N; n++) {
        for (int c = 0; c < OC; c++) {
            const int8_t *src = input  + ((n * IC + (c + C_start)) * H) * W;
            int8_t       *dst = output + ((n * OC +  c)            * H) * W;
            if (scale_in == scale_out) {
                for (int i = 0; i < H * W; i++) dst[i] = src[i];
            } else {
                for (int i = 0; i < H * W; i++) {
                    int32_t v = (int32_t)roundf(
                        (float)src[i] * scale_in / scale_out);
                    if (v < activation_min) v = activation_min;
                    if (v > activation_max) v = activation_max;
                    dst[i] = (int8_t)v;
                }
            }
        }
    }
}
""",
    extra_shapes=[
        {"N": 1, "IC": 18, "C_start": 15, "C_end": 18, "H": 64, "W": 85},
        {"N": 1, "IC": 32, "C_start": 0,  "C_end": 16, "H": 32, "W": 32},
    ],
    argtypes_factory=_slice_c_s8_argtypes,
)


def _softmax_s8_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    # input, output, M (rows), K (cols), scale_in, scale_out
    return [i8p, i8p,
            ctypes.c_int, ctypes.c_int,
            ctypes.c_float, ctypes.c_float]


SOFTMAX_S8 = KernelSpec(
    op="softmax_s8",
    signature=(
        "void kernel_softmax_s8(const int8_t *input, int8_t *output, "
        "int M, int K, float scale_in, float scale_out)"
    ),
    semantics=(
        "Row-wise softmax over a 2-D row-major view (M rows × K cols).\n"
        "Numerically stable: subtract the row max before exponentiating.\n"
        "  shift = max_k(input[m,k])\n"
        "  num[k] = expf((input[m,k] - shift) * scale_in)\n"
        "  denom  = sum_k num[k]\n"
        "  output[m,k] = clamp(round(num[k] / denom / scale_out), -128, 127)\n"
        "Output activations sum to ~1.0 per row in float space. Caller\n"
        "should set scale_out so the dynamic range covers [0, 1]\n"
        "(typically 1/127 — every value fits in [0, 127] with one bit\n"
        "of headroom)."
    ),
    reference_impl="""\
void kernel_softmax_s8(const int8_t *input, int8_t *output, int M, int K,
                       float scale_in, float scale_out) {
    for (int m = 0; m < M; m++) {
        const int8_t *row_in  = input  + m * K;
        int8_t       *row_out = output + m * K;
        int8_t shift = row_in[0];
        for (int k = 1; k < K; k++) {
            if (row_in[k] > shift) shift = row_in[k];
        }
        /* Two-pass over the row: first accumulate the denominator,
         * then quantize. Curated kernels can elide the second pass by
         * caching exp values in a scratch buffer (LUT or fp16 store). */
        float sum = 0.0f;
        for (int k = 0; k < K; k++) {
            sum += expf(((float)row_in[k] - (float)shift) * scale_in);
        }
        for (int k = 0; k < K; k++) {
            float e = expf(((float)row_in[k] - (float)shift) * scale_in);
            float p = e / sum;
            int32_t v = (int32_t)roundf(p / scale_out);
            if (v < -128) v = -128;
            if (v >  127) v =  127;
            row_out[k] = (int8_t)v;
        }
    }
}
""",
    extra_shapes=[
        {"M": 1,   "K": 7},     # ViNT attention head: 7 tokens
        {"M": 4,   "K": 7},     # 4 heads × 7 keys
        {"M": 16,  "K": 64},    # broader test
    ],
    argtypes_factory=_softmax_s8_argtypes,
)


# ---------------------------------------------------------------------------
# Application-specific composite ops. These sit at the model/application
# boundary and absorb the open-ended pre/post-process code that's
# specific to each model. Same KernelSpec contract as everything else
# (signature + semantics + reference_impl + argtypes), so the existing
# kernel-pick / verify / cache / LLM-gen pipeline works without changes.
# ---------------------------------------------------------------------------


def _vint_action_post_argtypes():
    import ctypes
    i8p = ctypes.POINTER(ctypes.c_int8)
    f32p = ctypes.POINTER(ctypes.c_float)
    # dist_int8, scale_dist, deltas_int8, scale_deltas, output_fp32
    return [i8p, ctypes.c_float, i8p, ctypes.c_float, f32p]


VINT_ACTION_POST = KernelSpec(
    op="vint_action_post",
    signature=(
        "void kernel_vint_action_post("
        "const int8_t *dist_int8, float scale_dist, "
        "const int8_t *deltas_int8, float scale_deltas, "
        "float *output)"
    ),
    semantics=(
        "Composite ViNT post-process: absorbs every tail op the int8\n"
        "model graph elided (dequant + cumsum + L2-normalize + tuple\n"
        "pack) so the binary's surface output is a single fp32 buffer\n"
        "the application (pilot / IsaacLab adapter) can consume\n"
        "directly.\n"
        "\n"
        "Inputs:\n"
        "  dist_int8[1]    — int8 temporal-distance estimate\n"
        "  deltas_int8[20] — int8 (5,4) (dx, dy, sin, cos) per-step\n"
        "                    deltas\n"
        "Output (21 fp32 values):\n"
        "  out[0]          — dequantized fp32 temporal distance\n"
        "  out[1..20]      — (5,4) fp32 waypoints:\n"
        "                      [wp][0] = cumulative x (m)\n"
        "                      [wp][1] = cumulative y (m)\n"
        "                      [wp][2] = sin θ (unit vector)\n"
        "                      [wp][3] = cos θ (unit vector)\n"
        "\n"
        "Reference algebra (matches PyTorch ViNT.forward tail):\n"
        "  out[0] = dist_int8[0] * scale_dist\n"
        "  f[wp][i] = deltas_int8[wp*4 + i] * scale_deltas  for i in 0..3\n"
        "  cum_x = cumsum(f[:, 0]); out[1 + wp*4 + 0] = cum_x[wp]\n"
        "  cum_y = cumsum(f[:, 1]); out[1 + wp*4 + 1] = cum_y[wp]\n"
        "  n = max(sqrt(f[wp][2]^2 + f[wp][3]^2), 1e-12)\n"
        "  out[1 + wp*4 + 2] = f[wp][2] / n\n"
        "  out[1 + wp*4 + 3] = f[wp][3] / n\n"
    ),
    reference_impl="""\
void kernel_vint_action_post(const int8_t *dist_int8, float scale_dist,
                             const int8_t *deltas_int8, float scale_deltas,
                             float *output) {
    const int N_WP = 5;
    /* Slot 0: dequant the dist scalar. */
    output[0] = (float)dist_int8[0] * scale_dist;
    /* Slots [1..10]: cumsum the (dx, dy) cols of the action_pred (5,4). */
    float cum_x = 0.0f, cum_y = 0.0f;
    for (int wp = 0; wp < N_WP; wp++) {
        cum_x += (float)deltas_int8[wp*4 + 0] * scale_deltas;
        cum_y += (float)deltas_int8[wp*4 + 1] * scale_deltas;
        output[1 + wp*4 + 0] = cum_x;
        output[1 + wp*4 + 1] = cum_y;
    }
    /* Slots [3..20] mixed in above; L2-normalize the (sin, cos) cols. */
    for (int wp = 0; wp < N_WP; wp++) {
        float s = (float)deltas_int8[wp*4 + 2] * scale_deltas;
        float c = (float)deltas_int8[wp*4 + 3] * scale_deltas;
        float n = sqrtf(s*s + c*c);
        if (n < 1e-12f) n = 1e-12f;
        output[1 + wp*4 + 2] = s / n;
        output[1 + wp*4 + 3] = c / n;
    }
}
""",
    extra_shapes=[{}],  # composite op, no shape parametrization
    argtypes_factory=_vint_action_post_argtypes,
)


def _lstm_f16_argtypes():
    import ctypes
    h = ctypes.POINTER(ctypes.c_uint16)   # _Float16 opaque
    # x, w_ih, w_hh, bias, h, c, out, in_size, H
    return [h, h, h, h, h, h, h, ctypes.c_int, ctypes.c_int]


LSTM_F16 = KernelSpec(
    op="lstm_f16",
    signature=(
        "void kernel_lstm_f16(const _Float16 *x, const _Float16 *w_ih, "
        "const _Float16 *w_hh, const _Float16 *bias, "
        "_Float16 *h, _Float16 *c, _Float16 *out, int in_size, int H)"
    ),
    semantics=(
        "Half-precision single-layer, single-timestep LSTM cell (PyTorch gate\n"
        "order i,f,g,o). Mirrors kernel_lstm but all tensors are _Float16 and\n"
        "the gate-GEMM reduction ACCUMULATES IN _Float16 (storage + accumulate\n"
        "fp16); the sigmoid/tanh/cell update are evaluated in float then stored\n"
        "back to _Float16. h/c persist across calls (seq-len-1 unroll); out must\n"
        "not alias h (the w_hh GEMM reads the previous h)."
    ),
    reference_impl="""\
#include <math.h>
void kernel_lstm_f16(const _Float16 *x, const _Float16 *w_ih, const _Float16 *w_hh,
                     const _Float16 *bias, _Float16 *h, _Float16 *c, _Float16 *out,
                     int in_size, int H) {
    for (int j = 0; j < H; j++) {
        float pre[4];
        for (int g = 0; g < 4; g++) {
            int row = g * H + j;
            const _Float16 *wih_row = w_ih + (long)row * in_size;
            const _Float16 *whh_row = w_hh + (long)row * H;
            _Float16 ax = (_Float16)0.0f, ah = (_Float16)0.0f;
            for (int k = 0; k < in_size; k++)      /* fp16 product + fp16 accumulate */
                ax = (_Float16)(ax + (_Float16)(x[k] * wih_row[k]));
            for (int k = 0; k < H; k++)
                ah = (_Float16)(ah + (_Float16)(h[k] * whh_row[k]));
            pre[g] = (float)ax + (float)ah + (float)bias[row];
        }
        float ig = 1.0f / (1.0f + expf(-pre[0]));
        float fg = 1.0f / (1.0f + expf(-pre[1]));
        float cg = tanhf(pre[2]);
        float og = 1.0f / (1.0f + expf(-pre[3]));
        float c_new = fg * (float)c[j] + ig * cg;
        c[j]   = (_Float16)c_new;
        out[j] = (_Float16)(og * tanhf(c_new));
    }
    for (int j = 0; j < H; j++) h[j] = out[j];
}
""",
    extra_shapes=[
        {"in_size": 8, "H": 4},
        {"in_size": 16, "H": 8},
        # Production shapes (fused_full's 3-layer LSTM, kernel_opt_log 1000+):
        # both prior shapes have in_size,H <= 16, well under a single LMUL4
        # register group (vlmax_e16m4 = 64 @ VLEN=256) -- neither exercised
        # multi-chunk K reduction, which is what the gate-blocked kernel's
        # hoisted-load loop actually runs at production scale.
        {"in_size": 597, "H": 128},   # layer 0: fused (1,597) -> hidden 128
        {"in_size": 128, "H": 128},   # layers 1,2: hidden 128 -> hidden 128
    ],
    argtypes_factory=_lstm_f16_argtypes,
)


KERNEL_SPECS: dict[str, KernelSpec] = {
    "linear": LINEAR,
    "matmul": MATMUL,
    "matmul_ta": MATMUL_TA,
    "matmul_tb": MATMUL_TB,
    "matmul_tatb": MATMUL_TATB,
    "bmm": BMM,
    "relu": RELU,
    "relu6": RELU6,
    "elu": ELU,
    # KernelBench Phase 2 activations.
    "leaky_relu": LEAKY_RELU,
    "tanh": TANH,
    "swish": SWISH,
    "gelu": GELU,
    "gelu_exact": GELU_EXACT,
    "selu": SELU,
    "hardsigmoid": HARDSIGMOID,
    "softplus": SOFTPLUS,
    "softsign": SOFTSIGN,
    "hardtanh": HARDTANH,
    # KernelBench Phase 2 reductions over a dim.
    "sum_dim": SUM_DIM,
    "mean_dim": MEAN_DIM,
    "max_dim": MAX_DIM,
    "min_dim": MIN_DIM,
    "prod_dim": PROD_DIM,
    "argmax_dim": ARGMAX_DIM,
    "argmin_dim": ARGMIN_DIM,
    # KernelBench Phase 2 norms (subset — see Tier 3 follow-on for the
    # affine-bearing nn.Module ones).
    "l1_norm": L1_NORM,
    "l2_norm": L2_NORM,
    "frobenius_norm": FROBENIUS_NORM,
    "conv2d": CONV2D,
    "conv2d_dw": CONV2D_DW,
    "maxpool2d": MAXPOOL2D,
    "adaptive_avg_pool2d": ADAPTIVE_AVG_POOL2D,
    "add": ADD,
    "batchnorm2d": BATCHNORM2D,
    "sigmoid": SIGMOID,
    "lstm": LSTM,
    "linear_s8": LINEAR_S8,
    "relu_s8": RELU_S8,
    "conv2d_s8": CONV2D_S8,
    "conv2d_silu_s8": CONV2D_SILU_S8,
    "maxpool2d_s8": MAXPOOL2D_S8,
    "add_s8": ADD_S8,
    "batchnorm2d_s8": BATCHNORM2D_S8,
    "sigmoid_s8": SIGMOID_S8,
    "lstm_s8": LSTM_S8,
    "relu_f16": RELU_F16,
    "sigmoid_f16": SIGMOID_F16,
    "elu_f16": ELU_F16,
    "batchnorm2d_f16": BATCHNORM2D_F16,
    "maxpool2d_f16": MAXPOOL2D_F16,
    "conv2d_f16": CONV2D_F16,
    "matmul_f16": MATMUL_F16,
    "matmul_ta_f16": MATMUL_TA_F16,
    "matmul_tb_f16": MATMUL_TB_F16,
    "matmul_tatb_f16": MATMUL_TATB_F16,
    "bmm_f16": BMM_F16,
    # Mixed-precision i8↔f16 cast kernels (auto-cast pass output).
    "cast_i8_to_f16": CAST_I8_TO_F16,
    "cast_f16_to_i8": CAST_F16_TO_I8,
    # ViNT fp16 op set.
    "linear_f16": LINEAR_F16,
    "lstm_f16": LSTM_F16,
    "depthwise_conv2d_f16": DEPTHWISE_CONV2D_F16,
    "layer_norm_f16": LAYER_NORM_F16,
    "gelu_f16": GELU_F16,
    "softmax_f16": SOFTMAX_F16,
    "add_f16": ADD_F16,
    "mul_f16": MUL_F16,
    "mul_c1_f16": MUL_C1_F16,
    "mul_c1_s8": MUL_C1_S8,
    "adaptive_avg_pool2d_f16": ADAPTIVE_AVG_POOL2D_F16,
    "slice_c_f16": SLICE_C_F16,
    "cat2_c1_f16": CAT2_C1_F16,
    "cat3_c1_f16": CAT3_C1_F16,
    "cat4_c1_f16": CAT4_C1_F16,
    "pad_f16": PAD_F16,
    "silu_f16": SILU_F16,
    "upsample_nearest_f16": UPSAMPLE_NEAREST_F16,
    # YOLOv8-nano fp32 support.
    "silu": SILU,
    "upsample_nearest": UPSAMPLE_NEAREST,
    "cat2_c1": CAT2_C1,
    "cat3_c1": CAT3_C1,
    "cat4_c1": CAT4_C1,
    # YOLOv8-nano int8 support.
    "silu_s8": SILU_S8,
    # mlp_control int8 support (PPO actor uses nn.ELU).
    "elu_s8": ELU_S8,
    "upsample_nearest_s8": UPSAMPLE_NEAREST_S8,
    "cat2_c1_s8": CAT2_C1_S8,
    "cat3_c1_s8": CAT3_C1_S8,
    "cat4_c1_s8": CAT4_C1_S8,
    # ViNT int8 support.
    "mul_s8": MUL_S8,
    "gelu_s8": GELU_S8,
    "pad_s8": PAD_S8,
    "adaptive_avg_pool2d_s8": ADAPTIVE_AVG_POOL2D_S8,
    "layer_norm_s8": LAYER_NORM_S8,
    "matmul_s8": MATMUL_S8,
    "softmax_s8": SOFTMAX_S8,
    "depthwise_conv2d_s8": DEPTHWISE_CONV2D_S8,
    "slice_c_s8": SLICE_C_S8,
    # Per-channel-weight-scale variants (Phase B.2).
    "conv2d_s8_pc": CONV2D_S8_PC,
    "linear_s8_pc": LINEAR_S8_PC,
    "matmul_s8_pc": MATMUL_S8_PC,
    # Application-specific composite ops. The op-kind family
    # "app_op_<name>" is reserved for these — codegen looks up the
    # implementation either in modelblaster/kernels/<backend>/<op>.c (curated)
    # or generates it via the LLM path using the semantics block in
    # the IR record. Stock impls below cover the common patterns; a
    # model-specific spec can override by registering with the same
    # name.
    "vint_action_post": VINT_ACTION_POST,
}


def shapes_from_ir(ir: dict, op: str) -> list[dict[str, int]]:
    """Pull every distinct shape combo for `op` out of an IR graph.

    Shape values are usually ints, but some ops carry lists (e.g.
    catN_c1's C_inputs=[16, 16, 16]). Lists aren't hashable so we
    coerce to tuples before building the dedup key.
    """
    seen: set[tuple] = set()
    out: list[dict[str, int]] = []
    for node in ir.get("ops", []):
        if node["op"] != op:
            continue
        shape = node.get("shape", {})
        key = tuple(sorted(
            (k, tuple(v) if isinstance(v, list) else v)
            for k, v in shape.items()
        ))
        if key in seen:
            continue
        seen.add(key)
        out.append(dict(shape))
    return out
